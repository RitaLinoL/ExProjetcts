window.onload = function() {
  //createMyLine1()
  createMyLine2()
  createMyLine3()
  createMyLine4()
  createMyLine5()
  createMyLine6()
  createMyLine7()
  createMyLine8()

};
