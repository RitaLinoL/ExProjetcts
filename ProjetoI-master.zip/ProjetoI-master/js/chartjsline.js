var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
//configuracao do grafico 1
var config = {
  type: 'line',
  data: {
    //dados iniciais equivalentes ao eixo X
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
    datasets: [{
      label: 'My First dataset',
      backgroundColor: window.chartColors.red,
      borderColor: window.chartColors.red,
      ////dados iniciais equivalentes ao eixo Y da linha 1
      data: [
        randomScalingFactor(),
        randomScalingFactor(),
        randomScalingFactor(),
        randomScalingFactor(),
        randomScalingFactor(),
        randomScalingFactor(),
        randomScalingFactor()
      ],
      fill: false,
    }, {
      label: 'My Second dataset',
      fill: false,
      backgroundColor: window.chartColors.blue,
      borderColor: window.chartColors.blue,
      ////dados iniciais equivalentes ao eixo Y da linha 2
      data: [
        randomScalingFactor(),
        randomScalingFactor(),
        randomScalingFactor(),
        randomScalingFactor(),
        randomScalingFactor(),
        randomScalingFactor(),
        randomScalingFactor()
      ],
    }]
  },
  options: {
    responsive: true,
    title: {
      display: true,
      text: 'Chart.js Line Chart'
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
    hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: 'Month'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: 'Value'
        }
      }]
    }
  }
};

//cria o grafico 1
/*
function createMyLine1() {
  var ctx = document.getElementById('canvas').getContext('2d');
  window.myLine = new Chart(ctx, config);
  
  //avisa ao motor javascript que a funcao randomUpdateData deve
  //ser chamada daqui a 2000 ms 
  setTimeout(randomUpdateData, 2000);
};*/

function randomUpdateData() {    
  if (config.data.datasets.length > 0) {
    var month = MONTHS[config.data.labels.length % MONTHS.length];
    //variavel config.data.labels equivale ao eixo X
    config.data.labels.push(month);

    //usa um foreach para interar em todos os elementos da
    //variavel config.data.datasets (nesse caso sao 2)
    config.data.datasets.forEach(function(dataset) {
      //variavel dataset.data equivale ao eixo Y
      dataset.data.push(randomScalingFactor());
    });

    window.myLine.update();
  }
  //avisa ao motor javascript que a funcao randomUpdateData deve
  //ser chamada daqui a 2000 ms 
  setTimeout(randomUpdateData, 2000);
}