<h1>1º Projeto de Introdução a Internet das Coisas</h1>
<h2>Grupo:</h2>
<p>Francisco Vicente de França Júnior <br/>
Rita de Cássia Lino Lopes</p>

<br/>
<br/>
<br/>

<a href="url">Site Hospedado neste endereço: http://projetoi.000webhostapp.com/</a>
