#include "file_to_structs.h"

/*Classes de transferência do arquivo txt para a struct*/

//transfere do arquivo do SGBD para uma struct os dados de id, name e src dos bancos individualmente.

int share_SGBD(Mitra * mitra){

  FILE * b;
  b = fopen("database.txt","a+");

    if (b == NULL)  // Se houveR erro na abertura
    {
     printf("Problemas na abertura do arquivo\n");
     return 0;
   }else{

        //contando quantas linhas há no arquivo (linhas - 1 =  quantidade de bancos no SGBD) 
    char ch;
    
    while((ch=fgetc(b))!= EOF){
      if(ch == '\n'){
       mitra -> quantBases++;
     }
   }
   mitra -> quantBases --;

        rewind(b);//reposiciona o ponteiro para o inicio do arquivo
        
        
        char linha[1000], * aux;

        mitra -> bases_in_mitra = malloc((mitra -> quantBases) * sizeof(db_s));
        int posicao =0;


        while( (fgets(linha, 1000, b))!= NULL ){

          if (posicao == 0)
          {
            posicao++;
                //não processa o cabeçalho: primeira linha do arquivo
          }else{

            char aux[1000];
                sscanf(linha,"%u?%s",&(mitra -> bases_in_mitra[posicao - 1].id),aux);//separa o id(int) do nome e src(string)

                char  * token;
                const char s[2] = "?";//define o caractere de separação do nome e do srcs
                /* get the first token */
               token = strtok(aux, s); // uso de funçao strtok para quebrar 

               mitra -> bases_in_mitra[posicao - 1].name = malloc(sizeof(char) * 300);

               strcpy(mitra -> bases_in_mitra[posicao - 1].name, token);

               token = strtok(NULL, s);
               mitra -> bases_in_mitra[posicao - 1].src = malloc(sizeof(char) * 300);
               strcpy(mitra -> bases_in_mitra[posicao - 1].src, token);

               posicao ++;

             }       
           } 
           
           fclose(b);
           return 1; 
         }
         
       }






       db_s share_base(db_s database){

        FILE * b;

        b = fopen(database.src,"a+");

    if (b == NULL)  // Se houve erro na abertura
    {
     printf("Problemas na abertura do arquivo\n");
     return database;
   }else{

        //contando quantas linhas há no arquivo (linhas - 1 =  quantidade de bancos no SGBD) 
    char ch;
    database.quantTables = 0;
    while((ch=fgetc(b))!= EOF){
      if(ch == '\n'){
       database.quantTables++;
     }
   }

   database.quantTables--;
        rewind(b);//reposiciona o ponteiro para o inicio do arquivo
        char linha[1000], * aux;
        database.tables = malloc((database.quantTables) * sizeof(tb_s));
        int posicao =0;
        while( (fgets(linha, 1000, b))!= NULL ){

          if (posicao == 0)
          {
            posicao++;

                //não processa o cabeçalho: primeira linha do arquivo
          }else{

            char aux[1000];
                sscanf(linha,"%u?%s",&(database.tables[posicao - 1].id),aux);//separa o id(int) do nome e src(string)

                char  * token;
                const char s[2] = "?";//define o caractere de separação do nome e do srcs
                /* get the first token */
               token = strtok(aux, s); // uso de funçao strtok para quebrar 
               database.tables[posicao - 1].name = malloc(sizeof(char) * 300);

               strcpy(database.tables[posicao - 1].name, token);

               token = strtok(NULL, s);
               database.tables[posicao - 1].src = malloc(sizeof(char) * 600);
               strcpy(database.tables[posicao - 1].src, token);

               posicao ++;

             }       
           } 

           fclose(b);

           return database; 
         }
         
       }





       tf_e configTypeField(char * string){
        tf_e tp;
        tp = (tf_e) string;
      }




      tb_s share_table(tb_s table){
  //apagar linha abaixo
 // printf("_____In share_table________\n");


        FILE * b;
        b = fopen(table.src,"a+");
    if (b == NULL)  // Se houve erro na abertura
    {
     printf("Problemas na abertura do arquivo\n");
   }else{
        //contando quantas colunas há na tabela


    char ch;
    table.quantFields = 0;
    while((ch=fgetc(b))!= EOF){
      if (ch == '?')
      {
        table.quantFields++;
      }
      if(ch == '\n'){
       break;
     }
   }

        rewind(b);//reposiciona o ponteiro para o inicio do arquivo

        table.fields = malloc(sizeof(fd_s) * table.quantFields);
        int i =0, count =0, pos =0;
        char * auxName, * auxType;

        for (i = 0; i < table.quantFields; ++i)
        {
          auxName = malloc(sizeof(char) * 300);
          auxType = malloc(sizeof(char) * 300);

          while((ch=fgetc(b))!= EOF){
                //pegando tipo do campo
            if (ch == '(')
            {
              count =0;
              while((ch=fgetc(b))!= EOF){
                if(ch == ')'){
                  count++;
                  break;
                }else{
                  auxType[count] = ch;
                  count++;
                }
              }
            }else if(ch != '?'){
              auxName[count]=ch;
              count ++;
            }

            if(ch == '?'){
              pos++;
              count = 0;
              table.fields[i].position = pos;
              table.fields[i].name=malloc(sizeof(auxName));
              table.fields[i].typeField=malloc(sizeof(auxType));

              strcpy(table.fields[i].name,auxName);
              strcpy(table.fields[i].typeField,auxType);
              
                    //configTypeField(auxType,  table.fields[i].typeField);
                   //dando erro ^
                   //alocando espaço do ponteiro void de acordo com o tipo
              if(!(strcmp(table.fields[i].typeField,"int_"))){
                table.fields[i].values = malloc(sizeof(int*));
              }else if(!(strcmp(table.fields[i].typeField,"float_"))){
                table.fields[i].values = malloc(sizeof(float*));                  
              }else if(!(strcmp(table.fields[i].typeField,"double_"))){
                table.fields[i].values = malloc(sizeof(char*));
              }else if(!(strcmp(table.fields[i].typeField,"string_"))){
                table.fields[i].values = malloc(sizeof(string*));
              }else if(!(strcmp(table.fields[i].typeField,"char_"))){
                table.fields[i].values = malloc(sizeof(char*));
              }

              
                    //resetando as strings auxiliares
              int j;
              for(j = strlen(auxName);  j >=0; j--)
              {
                auxName[j] = '\0';
              }
              
              for(j = strlen(auxType);  j >=0; j--)
              {
                auxType[j] = '\0';
              }

              break;
            }
          }

        }
        fclose(b);

      }

      return table;
    }









    void * configValues(char * value_string, fd_s field){
      
      if(!(strcmp(field.typeField,"int_"))){
        int x =0;
        sscanf(value_string,"%i",&x);
        int * vetor_int = malloc(sizeof(int) * field.quantValues);
        vetor_int = field.values;
        vetor_int[field.quantValues -1] = x;
        void * aux = vetor_int;
        return aux;
      }else if(!(strcmp(field.typeField,"float_"))){
        float x =0;
        sscanf(value_string,"%f",&x);     
        float * vetor_float = malloc(sizeof(float) * field.quantValues);
        vetor_float = field.values;
        vetor_float[field.quantValues -1] = x;
        void * aux = vetor_float;
        return aux;
      }else if(!(strcmp(field.typeField,"double_"))){
        double x =0;
        sscanf(value_string,"%lf",&x);
        double * vetor_double = malloc(sizeof(double) * field.quantValues);
        vetor_double = field.values;
        vetor_double[field.quantValues -1] = x;
        void * aux = vetor_double;
        return aux;
      }else if(!(strcmp(field.typeField,"string_"))){
        string * vetor_string = malloc(sizeof(string) * field.quantValues);
        vetor_string= field.values;  
      //alocação aparentemente apagar o primeiro valor :(
        strcpy( vetor_string[field.quantValues -1].str, value_string);     
        void * aux = vetor_string;
        return aux;     
      }else if(!(strcmp(field.typeField,"char_"))){
        char x;
        sscanf(value_string,"%c",&x);
      char * vetor_char = malloc(sizeof(char));//add um antes
      vetor_char = field.values;
      vetor_char[field.quantValues -1] = x;
      void * aux = vetor_char;
      return aux;
    }
  }


  tb_s share_value(tb_s table){
  FILE *b = fopen(table.src,"a+");//abre o arquivo da tabela selecionada
  int posicao =0;//conta as linhas
  char linha[50000];//variavel para armazenar linha a linha
  while( (fgets(linha, sizeof(linha), b))!= NULL ){
    int count = 0;//contar os caracteres da linha, serve para indicar a posição na string 'linha'
    if (posicao == 0)//não processa o cabeçalho: primeira linha do arquivo
    {
      posicao++;

      int i =0;
      for (i = 0; i <table.quantFields ; ++i)//configura as quantidades iniciais de valores de cada campo para zero.
      {
        table.fields[i].quantValues =0;
      }
    }else{

      int countField = 0;//separa os campos de cada linha, reiniciando a contagem a cada linha
      char auxValue[5000];//Variavel para armazenar a string com o valor lido do arquivo

      while(countField < table.quantFields){//quando chega ao fim da linha ler a próxima no arquivo
        int countAuxValue = 0;//Conta a posição de caracter da string de valor
        while(linha[count]!= '?'){//adiciona em uma string o valor, caracter a caracter 
          auxValue[countAuxValue] = linha[count];
          countAuxValue++;
          count++;
        }
        
        table.fields[countField].quantValues++;//soma mais um valor ao campo
        table.fields[countField].values = configValues(auxValue,table.fields[countField]);                  

        //linhas abaixo reiniciam a string auxiliar
        int i=0;
        for (i = count-1; i >=0; --i)
        {
          auxValue[i]='\0';
        }
        countField++;
        count++;
      }

      posicao ++;
    }
  }
}












