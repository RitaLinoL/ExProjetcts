 #include "asud.h"


/*função para gerar ids únicos para os bancos*/


/*OS ADDs*/



/*Adição de bancos em mitra*/


int genIDs(Mitra * mitra){
	unsigned int id;
	id = rand() % (mitra -> quantBases + 2);
	int i= 0;

	for (i =0 ; i < (mitra -> quantBases) ; ++i)
	{
		if ((mitra -> bases_in_mitra[i].id) == id)
		{
			genIDs(mitra);
		}
	}
	return id;
}


void addBase(Mitra * mitra){
	//Adiciona na struct
	db_s * aux = mitra -> bases_in_mitra;
	mitra -> bases_in_mitra = malloc(sizeof(aux) + 1);
	int i;

	mitra -> bases_in_mitra = aux;
	
	i = mitra -> quantBases;//posição do banco que será trabalhado.
	mitra -> quantBases++;
	mitra -> bases_in_mitra[i].name =  malloc(sizeof(char) * 300);
	mitra -> bases_in_mitra[i].src =  malloc(sizeof(char) * 600);

	mitra -> bases_in_mitra[mitra -> quantBases - 1].id = genIDs(mitra); 
	
	printf("Nome do banco:\t");
	scanf("%s", (mitra -> bases_in_mitra[i].name));

	strcpy((mitra -> bases_in_mitra[i].src), (mitra -> bases_in_mitra[i].name));
	strcat((mitra -> bases_in_mitra[i].src), "/");
	strcat((mitra -> bases_in_mitra[i].src), (mitra -> bases_in_mitra[i].name));
	strcat((mitra -> bases_in_mitra[i].src), ".txt" );


	//Adiciona no arquivo
	FILE * base;
	base = fopen(mitra -> src,"a+");
	addDataBase(base, mitra -> bases_in_mitra[i]);
	fclose(base);
}





/*Adição de tabelas em database*/

/*função para gerar ids únicos para as tabelas*/
int genIDsTables(db_s database){
	unsigned int id;
	id = rand() % (database.quantTables + 2);
	int i= 0;

	for (i =0 ; i < (database.quantTables) ; ++i)
	{
		if ((database.tables[i].id) == id)
		{
			genIDsTables(database);
		}
	}
	return id;
}


db_s addTable(db_s database){
	//Adiciona na struct

	tb_s * aux = database.tables;
	(database.tables) = malloc(sizeof(aux) + 1);
	database.tables = aux;

	int i;
	i = database.quantTables;//posição da tabela que será trabalhado.
	database.quantTables++;

	database.tables[i].name =  malloc(sizeof(char) * 300);//erro por ausencia de conteudo?

	database.tables[i].src =  malloc(sizeof(char) * 600);

	database.tables[database.quantTables - 1].id = genIDsTables(database); 

	printf("Nome da tabela:\t");//desenvolver função para verificar nome único
	scanf("%s", (database.tables[i].name));

	strcpy((database.tables[i].src), (database.name));
	strcat((database.tables[i].src), "/");
	strcat((database.tables[i].src), (database.tables[i].name));
	strcat((database.tables[i].src), ".txt" );


	//Adiciona no arquivo
	FILE * base;
	base = fopen(database.src,"a+");
	createTable(base, database.tables[i]);
	fclose(base);
	return database;
}







/*Adição de campos nas structs e no arquivo*/

tb_s addField(tb_s table){
	//Adiciona na struct
	fd_s * aux = table.fields;
	(table.fields) = malloc(sizeof(aux) + 1);
	table.fields = aux;

	int i;
	i = table.quantFields;//posição da tabela que será trabalhado.
	table.quantFields++;

	table.fields[i].name =  malloc(sizeof(char) * 300);
	table.fields[i].typeField =  malloc(sizeof(char) * 300);

	printf("Nome do campo:\t");
	scanf("%s", (table.fields[i].name));
	printf("Tipo do Campo: ");
	printf("\n ______________\n");
	printf("|1 : Int      |\n|2 : Float    |\n|3 : Double    |\n|4 : Char   \n|5 : String   \t    |"); 
	printf("\n ‾‾‾‾‾‾‾‾‾‾‾‾‾‾\n");
	int type;
	scanf("%i",&type);

	switch(type){
		case (1):
		strcpy(table.fields[i].typeField,"int_") ;
		break;
		case (2):
		strcpy(table.fields[i].typeField,"float_") ;
		break;
		case (3):
		strcpy(table.fields[i].typeField,"double_") ;
		break;
		case (4):
		strcpy(table.fields[i].typeField,"char_") ;
		break;
		case (5):
		strcpy(table.fields[i].typeField,"string_") ;
		break;
		default:
		printf("Opção Inválida!\n");
		break;

	}
	//Adiciona no arquivo
	createField(table, i);//parametros, table e posição do campo	

	return table;
}


tb_s addValues(tb_s table){
	int i = 0, j=0;
	FILE * t =fopen(table.src,"a+");
	printf("Digite os valores dos campos:\n");
	for (i = 0; i < table.quantFields; ++i)
	{
		printf("%i -> %s (%s):   ",i+1,table.fields[i].name, table.fields[i].typeField);
		if(!(strcmp(table.fields[i].typeField,"int_"))){
			int v;
			scanf("%i", &v);
			fprintf(t, "%i?",v);
		}else if(!(strcmp(table.fields[i].typeField,"float_"))){
			float v;
			scanf("%f", &v);
			fprintf(t, "%f?",v);
		}else if(!(strcmp(table.fields[i].typeField,"double_"))){
			double v;
			scanf("%lf", &v);
			fprintf(t, "%lf?",v);
		}else if(!(strcmp(table.fields[i].typeField,"string_"))){
			string v;
			scanf("%s", v.str);
			fflush(stdin); 
			fprintf(t, "%s?",v.str );
		}else if(!(strcmp(table.fields[i].typeField,"char_"))){
			char v;
			scanf("%c", &v);
			fprintf(t, "%c?",v );
		}
		table.fields[i].quantValues++;
		printf("\n");
	}
	fprintf(t, "\n");

	fclose(t);

	table = share_table(table);
	return table;
}




/*OS SELECTS*/

/*Listagem dos bancos de mitra*/

void selectBases(Mitra * mitra){
	int i = 0;

	printf("________________________________________\n");
	printf("|Posição|  ID \t| Nome\n");
	printf("|-------|-------|-----------------------\n");
	
	
	for (i = 0; i < mitra -> quantBases; ++i)
	{
		printf("|   %iª  |   %i   | %s\n",i+1, mitra -> bases_in_mitra[i].id, mitra -> bases_in_mitra[i].name);
	}
}

/*Listagem das tabelas de database*/

void selectTables(db_s database){
	int i = 0;

	printf("________________________________________\n");
	printf("|Posição|  ID \t| Nome\n");
	printf("|-------|-------|-----------------------\n");
	
	
	for (i = 0; i < database.quantTables; ++i)
	{
		printf("|   %iª  |   %i   | %s\n",i+1, database.tables[i].id, database.tables[i].name);
	}
}



//troca de valores de ponteiro void para tipos básicos
int * returnTypeInt(void * ptr_void, int quant){
	int * vect = malloc(sizeof(int)*quant);
	vect = ptr_void; 
	return vect;
}

float * returnTypeFloat(void * ptr_void, int quant){
	float * vect = malloc(sizeof(float)*quant);
	vect = ptr_void; 
	return vect;
}

double * returnTypeDouble(void * ptr_void, int quant){
	double * vect = malloc(sizeof(double)*quant);
	vect = ptr_void; 
	
	return vect;
}

char * returnTypeChar(void * ptr_void, int quant){
	char * vect = malloc(sizeof(char)*quant);
	vect = ptr_void; 
	return vect;
}

string * returnTypeString(void * ptr_void, int quant){
	string * vect = malloc(sizeof(string)*quant);
	vect = ptr_void;
	return vect;
}


/*Listagem dos campos de uma tabela*/

void selectFields(tb_s table){
	int i = 0;
	for (i = 0; i < table.quantFields; ++i)
	{
		printf("%s(%s)\t",table.fields[i].name, table.fields[i].typeField);
	}
	printf("\n");

}


void selectFieldsEnum(tb_s table){
	int i = 0,j=0;
	for (i = 0; i < table.quantFields; ++i)
	{
		printf("%iº ->   Name: %s | Tipo: %s\n",i+1,table.fields[i].name, table.fields[i].typeField);
	}
	printf("\n");
}



//Funções para mostrar um dado em uma posição pos de um ponteiro void
void printTypeInt(void * ptr_void, int pos){
	int * vect;
	vect =  ptr_void; 
	printf("%i\t",vect[pos]);
}

void printTypeFloat(void * ptr_void, int pos){
	float * vect;
	vect = ptr_void; 
	printf("\t%f",vect[pos]);
}

void printTypeDouble(void * ptr_void, int pos){
	double * vect;
	vect= ptr_void; 
	printf("\t%lf",vect[pos]);
}

void printTypeChar(void * ptr_void, int pos){
	char * vect;
	vect = ptr_void; 
	printf("  %c  ",vect[pos]);
}

void printTypeString(void * ptr_void, int pos){
	string * vect_string;
	vect_string = ptr_void;
	printf("%s\t",vect_string[pos].str);
}






void intComp(tb_s table, double x, int mode, int pos){
	int i =0, j =0;//variaveis auxiliares
	int * vect;
	vect=returnTypeInt(table.fields[pos].values, table.fields[pos].quantValues);

	for (i = 0; i < table.fields[0].quantValues; ++i)
	{	
		switch(mode){
			case(1):
			if(vect[i]>x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}					
			}
			break;

			case(2):
			if(vect[i]>=x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(3):
			if(vect[i]==x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(4):
			if(vect[i]<x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(5):
			if(vect[i]<=x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;
		}
		printf("\n");
	}

}



void floatComp(tb_s table, double x, int mode, int pos){
	int i =0, j =0 ,c=0;//variaveis auxiliares
	float * vect;
	vect=returnTypeFloat(table.fields[pos].values, table.fields[pos].quantValues);

	for (i = 0; i < table.fields[0].quantValues; ++i)
	{	
		c=0;
		switch(mode){
			case(1):
			if(vect[i]>x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}					
			}
			break;

			case(2):
			if(vect[i]>=x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(3):
			if(vect[i]==x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(4):
			if(vect[i]<x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(5):
			if(vect[i]<=x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;
		}
		printf("\n");
	}
}



void doubleComp(tb_s table, double x, int mode, int pos){
	int i =0, j =0;//variaveis auxiliares
	double * vect;
	vect=returnTypeDouble(table.fields[pos].values, table.fields[pos].quantValues);

	for (i = 0; i < table.fields[0].quantValues; ++i)
	{	
		switch(mode){
			case(1):
			if(vect[i]>x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}					
			}
			break;

			case(2):
			if(vect[i]>=x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(3):
			if(vect[i]==x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(4):
			if(vect[i]<x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(5):
			if(vect[i]<=x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;
		}
		printf("\n");
	}
}




void stringComp(tb_s table, string x, int mode, int pos){
	string * vect = returnTypeString(table.fields[pos].values, table.fields[pos].quantValues);
	int i =0,j =0;
	for (i = 0; i < table.fields[pos].quantValues; ++i)
	{
		switch(mode){
			case(1):
			if(!strcmp(vect[i].str,x.str)){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(2):
			if(strstr(vect[i].str,x.str) != NULL){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;
		}
		printf("\n");
	}
}

void charComp(tb_s table, char x, int mode, int pos){
	char * vect = returnTypeChar(table.fields[pos].values, table.fields[pos].quantValues);
	int i =0, j =0 ;
	for (i = 0; i < table.fields[0].quantValues; ++i)
	{	
		switch(mode){
			case(1):
			if(vect[i]>x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}					
			}
			break;

			case(2):
			if(vect[i]>=x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(3):
			if(vect[i]==x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(4):
			if(vect[i]<x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;

			case(5):
			if(vect[i]<=x){
				for (j = 0; j < table.quantFields; ++j)
				{
					if(!(strcmp(table.fields[j].typeField,"int_"))){
						printTypeInt(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"float_"))){
						printTypeFloat(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"double_"))){
						printTypeDouble(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"string_"))){
						printTypeString(table.fields[j].values,i);
					}else if(!(strcmp(table.fields[j].typeField,"char_"))){
						printTypeChar(table.fields[j].values,i);	        
					}
				}	
			}
			break;
		}
		printf("\n");
	}
}


void selectFilter(tb_s table, int pos, int mode){
	if(!(strcmp(table.fields[pos].typeField,"int_"))){
		int v;
		printf("Digite o número para comparação\n");
		scanf("%i", &v);
		intComp(table, v, mode, pos);
	}else if(!(strcmp(table.fields[pos].typeField,"float_"))){
		float v;
		printf("Digite o número para comparação\n");
		scanf("%f", &v);
		floatComp(table, v, mode, pos);
	}else if(!(strcmp(table.fields[pos].typeField,"double_"))){
		double v;
		printf("Digite o número para comparação\n");
		scanf("%lf", &v);
		doubleComp(table, v, mode, pos);
	}else if(!(strcmp(table.fields[pos].typeField,"string_"))){
		string v;
		printf("Digite a palavra para comparação\n");
		scanf("%s", v.str);
		fflush(stdin);
		stringComp(table, v, mode, pos); 
	}else if(!(strcmp(table.fields[pos].typeField,"char_"))){
		char v;
		printf("Digite a letra para comparação\n");
		scanf("%c", &v);
		charComp(table, v, mode, pos);
	}

}


/*Listagem dos valores de um campo*/
void selectValues(tb_s table){
	printf("Posição:\t");
	selectFields(table);//Mostra cabeçalho 
	int i = 0;
	int j = 0;

	for (j = 0; j < table.fields[0].quantValues; ++j)
	{
		printf("%i :\t",j+1);
		for (i = 0; i < table.quantFields; ++i)
		{
			//imprime o valor do campo fields[i] na posição j de acordo com o tipo do campo
			if(!(strcmp(table.fields[i].typeField,"int_"))){
				printTypeInt(table.fields[i].values,j);
			}else if(!(strcmp(table.fields[i].typeField,"float_"))){
				printTypeFloat(table.fields[i].values,j);
			}else if(!(strcmp(table.fields[i].typeField,"double_"))){
				printTypeDouble(table.fields[i].values,j);
			}else if(!(strcmp(table.fields[i].typeField,"string_"))){
				printTypeString(table.fields[i].values,j);
			}else if(!(strcmp(table.fields[i].typeField,"char_"))){
				printTypeChar(table.fields[i].values,j);	        
			}
		}
		printf("\n");
	}
}



/*OS UPDATES*/
/*Atualiza os valores de uma linha de table*/
tb_s updateValues(tb_s table, int pos){
	//apagar do arquivo e atualizar a struct da tabela
	char line[5000], newLine[7000];
	int posLine = 0, i =0, countField = 0, j=0;
	char nameTemp[500];

	//ṕegar o nome do banco  e configurar o nome do arquivo temporário
	while(table.src[i] != '/'){
		nameTemp[i] = table.src[i];
		i++;
	} 
	i=0;
	strcat(nameTemp,"/temp.txt");

	//abrindo arquivos original e temporário
	FILE * t = fopen(table.src,"r+");
	FILE * t1 = fopen(nameTemp, "a+");
	while( (fgets(line, sizeof(line), t))!= NULL ){
		if (posLine == 0)
		{
			fprintf(t1, "%s",line);	   	
		}else if(pos == posLine){
			printf("Digite os novos campos: \n");	
			for (i = 0; i < table.quantFields; ++i)
			{
				printf("%i -> %s (%s):   ",i+1,table.fields[i].name, table.fields[i].typeField);

				if(!(strcmp(table.fields[i].typeField,"int_"))){
					int v;
					scanf(" %i", &v);
					fprintf(t1, "%i?",v);
				}else if(!(strcmp(table.fields[i].typeField,"float_"))){
					float v;
					scanf(" %f", &v);
					fprintf(t1, "%f?",v);
				}else if(!(strcmp(table.fields[i].typeField,"double_"))){
					double v;
					scanf(" %lf", &v);
					fprintf(t1, "%lf?",v);
				}else if(!(strcmp(table.fields[i].typeField,"string_"))){
					string v;
					scanf(" %s", v.str);
					fflush(stdin); 
					fprintf(t1, "%s?",v.str );
				}else if(!(strcmp(table.fields[i].typeField,"char_"))){
					
					char v;
					scanf(" %c", &v);
					fprintf(t1, "%c?",v );
				}
			}
			fprintf(t1, "\n");

			
		}else{
			fprintf(t1, "%s",line);	
		}
		posLine++;
	}

	fclose(t1);
	fclose(t);

   remove(table.src);//apaga o arquivo original
   rename(nameTemp,table.src);//substitui

   table = share_table(table);//atualiza a struct pegando diretamente do arquivo

   return table;
}





/*OS DELETES*/

/*Apagar um banco e realocar struct mitra*/
void deleteBase(Mitra * mitra, char * name){
	/*Apaga da struct mitra o banco*/

	//variaveis auxiliares
	Mitra aux;
	int i= 0;
	int pos =-1;

	//verifica se existe a tabela e, se sim, guarda a posição no banco
	for (i = 0; i < mitra -> quantBases; ++i)
	{
		if (!(strcmp(name, mitra -> bases_in_mitra[i].name)))
		{
			pos = i;
		}
	}



	if (pos != (-1))//verifica se foi encontrada 
	{
		if (remove(mitra -> bases_in_mitra[pos].src) == 0)
		{
			mitra -> quantBases--;
			aux.bases_in_mitra = malloc(sizeof(db_s)*mitra -> quantBases);
			

			/*for's adicionam os bancos à struct aux ignorando o que deve ser deletado*/
			//adiciona todos os bancos das posições anteriores na mitra aux
			for (i =0; i <pos; ++i)
			{
				aux.bases_in_mitra[i] = mitra -> bases_in_mitra[i];
			}

			//adiciona os bancos das posições posteriores na mitra aux
			for (i =pos; i <mitra -> quantBases; ++i)
			{
				aux.bases_in_mitra[i] = mitra -> bases_in_mitra[i+1];
			}

			free(mitra -> bases_in_mitra);

			//Copia os dados da struct mitra para a auxiliar
			aux.src = malloc(sizeof(char)*20);
			strcpy(aux.src, mitra -> src);

			//Copia os bancos novamente para mitra
			mitra -> bases_in_mitra = malloc(sizeof(db_s)*mitra->quantBases);
			mitra -> bases_in_mitra = aux.bases_in_mitra;
			

			/*Manipulação dos arquivos e pastas*/
			rmdir(name);//remove a pasta do banco deletado
			FILE * b = fopen(mitra -> src,"w+");//substituindo o antigo arquivo de banco 
			addHead(mitra -> src);//adicionando cabeçalho do banco
			fclose(b);

			FILE * b1 = fopen(mitra -> src,"a+");//abrindo o arquivo de mitra para escrita
			for (i = 0; i < mitra -> quantBases; ++i)//preenche o arquivo com as novas tabelas
			{
				fprintf(b1, "%i?%s?%s?\n", mitra->bases_in_mitra[i].id, mitra->bases_in_mitra[i].name, mitra->bases_in_mitra[i].src);//adiciona dados da tabela no arquivo do banco
			}
			fclose(b1);

			printf("Banco de dados %s excluido com sucesso.\n",name );	
		}else{
			printf("Erro ao apagar banco %s. Tente novamente.\n",name);
		}		
		
	}else{
		printf("Banco de dados %s inexistente.\n",name);
	}

}



/*Apaga uma tabela e realoca struct database*/
db_s deleteTable(db_s database, char * name){
	/*Deleta da struct*/
	db_s aux;
	int i= 0;
	int pos =-1;

	for (i = 0; i < database.quantTables; ++i)//verifica se existe a tabela e se sim guarda a posição
	{
		if (!(strcmp(name, database.tables[i].name)))
		{
			pos = i;
		}
	}

	if (pos != (-1))//verifica se há tabela com o nome digitado
	{
		if (remove(database.tables[pos].src) == 0)
		{
			database.quantTables--;
			aux.tables = malloc(sizeof(tb_s)*database.quantTables);
			for (i =0; i <pos; ++i)
			{
				aux.tables[i] = database.tables[i];
			}
			for (i =pos; i <database.quantTables; ++i)
			{
				aux.tables[i] = database.tables[i+1];
			}

			free(database.tables);
			database.tables = malloc(sizeof(tb_s)*database.quantTables);
			database.tables = aux.tables;
			FILE * b = fopen(database.src,"w+");//substituindo o antigo arquivo de banco 
			addHead(database.src);//adicionando cabeçalho do banco
			fclose(b);
			FILE * b1 = fopen(database.src,"a+");//abrindo para escrita	

			for (i = 0; i < database.quantTables; ++i)//preencher com as novas tabelas
			{
				createTable(b1,database.tables[i]);
			}
			fclose(b1);
			printf("Tabela %s excluida com sucesso.\n",name );
		}else{
			printf("Erro ao apagar tabela %s.\n",name);
		}
		
	}else{
		printf("Tabela %s inexistente.\n",name);
	}
	

	return database;	
}


/*Apaga um campo e realoca struct table*/
tb_s deleteField(tb_s table, int pos){

	//apaga do arquivo e atualiza a struct da tabela
	char line[5000], newLine[7000];
	int posLine = 0, i =0, countField = 0, j=0;
	char nameTemp[500];

	//ṕegar o nome do banco  e configurar o nome do arquivo temporário
	while(table.src[i] != '/'){
		nameTemp[i] = table.src[i];
		i++;
	} 
	i=0;
	strcat(nameTemp,"/temp.txt");


	table.quantFields--; //diminuindo a quantidade de campos

	//abrindo arquivos original e temporário
	FILE * t = fopen(table.src,"r+");
	FILE * t1 = fopen(nameTemp, "a+");
	while( (fgets(line, sizeof(line), t))!= NULL ){
		j = 0;
		countField = 0;
		if (posLine == 0)
		{	 
			for (i = 0; i < strlen(line) -1 ; ++i)
			{
				if (line[i] =='?')
				{
					countField++;
				}
				if (countField == pos)
				{
		   			//ignora enquanto estive no campo que deve ser excluido
					
				}else{
					newLine[j] = line[i];
					++j;
				}
			}
			fprintf(t1, "%s\n",newLine);	   	
		}else{
			for (i = 0; i < strlen(line) -1 ; i++)
			{
				if (line[i] =='?')
				{
					countField++;
				}
				if (countField == pos)
				{
		   			//ignora enquanto estive no campo que deve ser excluido

				}else{
					newLine[j] = line[i];
					j++;
				}
			}
			fprintf(t1, "%s\n",newLine);
		}

		for(j = strlen(newLine);  j >=0; j--)
		{
			newLine[j] = '\0';
		}
		posLine++;
	}

	fclose(t1);
	fclose(t);

   remove(table.src);//apaga o arquivo original
   rename(nameTemp,table.src);//substitui

   table = share_table(table);//atualiza a struct pegando diretamente do arquivo

}





//retorna a posição de id igual ao digitado
int returnPosition(tb_s table, void * id){
	int pos =-1;
	if(!(strcmp(table.fields[0].typeField,"int_"))){
		int  id_;
		id_ = (*(int*)id);

		int * vect = returnTypeInt(table.fields[0].values, table.fields[0].quantValues);
		int i=0;
		for (i = 0; i <table.fields[0].quantValues ; ++i)
		{
			if(vect[i]== id_){
				pos = i;
			}
		}
	}else if(!(strcmp(table.fields[0].typeField,"float_"))){
		float  id_;
		id_ = (*(float*)id);

		float * vect = returnTypeFloat(table.fields[0].values, table.fields[0].quantValues);
		int i=0;
		for (i = 0; i <table.fields[0].quantValues ; ++i)
		{
			if(vect[i]== id_){
				pos = i;
			}
		}
	}else if(!(strcmp(table.fields[0].typeField,"double_"))){
		double  id_ ;
		id_ = (*(double*)id);

		double * vect = returnTypeDouble(table.fields[0].values, table.fields[0].quantValues);
		int i=0;
		for (i = 0; i <table.fields[0].quantValues ; ++i)
		{
			if(vect[i]== id_){
				pos = i;
			}
		}
	}else if(!(strcmp(table.fields[0].typeField,"string_"))){
		string id_ ;
		id_ = (*(string*)id);

		string * vect = returnTypeString(table.fields[0].values, table.fields[0].quantValues);
		int i=0;
		for (i = 0; i <table.fields[0].quantValues ; ++i)
		{
			if(!strcmp(vect[i].str,id_.str)){
				pos = i;
			}
		}
	}else if(!(strcmp(table.fields[0].typeField,"char_"))){
		char id_;
		id_ = (*(char*)id);

		char * vect = returnTypeChar(table.fields[0].values, table.fields[0].quantValues);
		int i=0;
		for (i = 0; i <table.fields[0].quantValues ; ++i)
		{
			if(vect[i]== id_){
				pos = i;
			}
		}
	}
	return pos;
	
}


/*Apaga um valor de um campo especifico*/
tb_s deleteValueLine(tb_s table, void * id){
  int pos = returnPosition(table, id)+1;//pega posição de linha que deve ser excluída
  int count =0,i=0;
  char linha [5000];
  char aux[5000];
  while(table.src[i] != '/'){
  	aux[i] = table.src[i];
  	i++;
  } 
  i=0;
  strcat(aux,"/temp.txt");
  

  FILE * b1 = fopen(aux, "w+");
  FILE * b = fopen(table.src, "r+");

  while( (fgets(linha, sizeof(linha), b))!= NULL ){
  	if (count == pos)
  	{
  	}else{
  		fprintf(b1,"%s",linha);
  	}
  	count++;
  }
  fclose(b1);
  fclose(b);
  
   remove(table.src);//apaga o arquivo original
   rename(aux,table.src);//substitui

   table = share_table(table);

   return table;
}
