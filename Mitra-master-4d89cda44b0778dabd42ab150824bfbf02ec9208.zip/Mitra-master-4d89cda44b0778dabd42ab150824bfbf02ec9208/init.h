#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "asud.h"

int init();

void optionMitra(Mitra * mitra);

int optionDatabase(db_s database);

int optionTable(tb_s table);