#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>
#include "structs_mitra.h"


int share_SGBD(Mitra * mitra);

db_s share_base(db_s database);

tb_s share_table(tb_s table);


void * configValues(char * value_string, fd_s field);


tb_s share_value(tb_s table);
