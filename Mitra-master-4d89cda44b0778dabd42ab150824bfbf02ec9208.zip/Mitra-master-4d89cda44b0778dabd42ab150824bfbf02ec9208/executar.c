#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

void main(){
    system("gcc file_to_structs.c structs_to_file.c init.c  asud.c main.c -lm");
}


