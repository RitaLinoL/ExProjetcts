
//arquivo para modularização das structs

//ATENÇÂO: PRECISA USAR ALOCAÇÂO DINÂMICA;



typedef enum typeField_enum
{
  int_ =1,
  float_ =2,
  double_=3,
  char_ = 4,
  string_=5
}tf_e;


typedef struct
{
  char str[50000];
}string;

//struct para os campos de cada tabela
typedef struct field_struct
{
  char * name;
  char * typeField;
  int position;
  // vetores de valores
  void * values;
  int quantValues;
}fd_s;

//struct das tabelas
typedef struct table_struct
{
  unsigned int id;
  char * name;
  char * src;
  fd_s * fields;
  int quantFields;
}tb_s;

//struct dos bancos de dados
typedef struct database_struct
{
  unsigned int id;
  char * name;
  char * src;
  tb_s * tables;
  int quantTables;
}db_s;

//struct do SGBD
typedef struct mitra{
  db_s * bases_in_mitra;
  int quantBases;
  char *src;
}Mitra;


