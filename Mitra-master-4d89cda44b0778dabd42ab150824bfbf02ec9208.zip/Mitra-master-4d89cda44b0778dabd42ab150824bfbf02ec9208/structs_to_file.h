//arquivo para modularização de funções de manipulação de arquivos
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
 #include <unistd.h>
#include "file_to_structs.h"


FILE * startDatabases(char * src);

void addHead(char * src);

void createDir(char * name);

void addDataBase(FILE * base, db_s db_add);

void listFile(FILE * b);

int startTablesFile(char * src);

int addTablesInFile(char * src, char * string);

int verifyTypeCampos(fd_s * f);

void addFields(tb_s * tab);

void addInfoTable(char * b_name, tb_s * tab, int p);

void addTables(db_s banco);

void createBase(FILE * base,db_s database);

void createTable(FILE * base,tb_s table);

void createField(tb_s table, int pos);

