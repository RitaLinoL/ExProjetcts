#include "init.h"

void main()
{
	int i =0;
    while(!(i)){
        i = init();
        printf("\n\n\n");
    }
}
