#include "structs_to_file.h"

int genIDs(Mitra * mitra);

void addBase(Mitra * mitra);


int genIDsTables(db_s database);

db_s addTable(db_s database);

tb_s addField(tb_s table);

tb_s addValues(tb_s table);


void selectBases(Mitra * mitra);

void selectTables(db_s database);

void selectFields(tb_s table);

void selectFieldsEnum(tb_s table);

int * returnTypeInt(void * ptr_void, int quant);

float * returnTypeFloat(void * ptr_void, int quant);

double * returnTypeDouble(void * ptr_void, int quant);

char * returnTypeChar(void * ptr_void, int quant);

string * returnTypeString(void * ptr_void, int quant);



void printTypeInt(void * ptr_void, int pos);

void printTypeFloat(void * ptr_void, int pos);

void printTypeDouble(void * ptr_void, int pos);

void printTypeChar(void * ptr_void, int pos);

void printTypeString(void * ptr_void, int pos);


void intComp(tb_s table, double x, int mode, int pos);

void floatComp(tb_s table, double x, int mode, int pos);

void doubleComp(tb_s table, double x, int mode, int pos);

void  stringComp(tb_s table, string x, int mode, int pos);

void charComp(tb_s table, char x, int mode, int pos); 

void selectFilter(tb_s table,int pos, int mode);





void selectValues(tb_s table);


tb_s updateValues(tb_s table, int pos);


void deleteBase(Mitra * mitra, char * name);

db_s deleteTable(db_s database, char * name);

tb_s deleteField(tb_s table, int pos);

tb_s deleteValueLine(tb_s table, void * id);