/*Classes de transferência da struct para os arquivos*/

#include "structs_to_file.h"

/*ATENÇÃO: Os comentários contém a descrição das funções, sugestões e outros aspectos. */

/*Abre um arquivo para para gravação e leitura(a+).
Caso o arquivo não exista ele cria, caso exista ele somente abre.
 Recebe como parâmetro o endereço do arquivo que deve ser aberto.*/
FILE * startDatabases(char * src){
	FILE * base;
	base = fopen(src,"a+");
	if(!base)
	{
		printf("Erro na abertura do arquivo\n");
		fclose(base);

		return NULL;
	}else{
		return base;
	}
}

/*Abre um arquivo para para gravação e leitura(a+) e 
insere o cabeçalho padrão dos arquivos database.txt e dos bancos individuais (com tabelas)*/

void addHead(char * src){
	FILE * base;
	base = fopen(src,"a+");

	if(!base)
	{
		printf("Erro ao criar arquivo. Tente novamente.\n");
	}else{
		fprintf(base, "ID(unsigned int)?NAME(string)?SRC(string)?\n");
	}
	fclose(base);

}


/*Cria um diretório/pasta com o nome enviado como parâmetro.
Ele usa shell script :(*/
void createDir(char * name){
	char * comand;
	comand = malloc(sizeof(name) + sizeof(char) * 6);
	sprintf(comand, "mkdir %s", name);
	system(comand);
}

/*Adicionar banco - Recebe uma struct de um banco especifico
e adicionar ao arquivo base*/
void addDataBase(FILE * base, db_s db_add){
	fprintf(base, "%i?%s?%s?\n", db_add.id, db_add.name, db_add.src);//ok
	createDir(db_add.name);
	addHead(db_add.src);
}

 /*Recebe um arquivo como parâmetro
 e imprime seu conteúdo substituindo as interrogações por traço.
 Dessa forma, a listagem acontece diretamente do arquivo
 sem qualquer interação com o banco propriamente dito*/

/*Modularizar arquivos para */
void listFile(FILE * b){
	char c;
	while((c = getc(b) ) != EOF){
		if (c=='?')
		{
			printf(" | ");
		}else{
			printf("%c", c);
		}
	}
}


/*Adiciona o id, o nome e o endereço das tabelas na última linha do arquivo do banco selecionado*/
int addTablesInFile(char * src, char * string){
	FILE * table;
	table = fopen(src,"a+");
	//fechar arquivos.
	fprintf(table,"%s\n",string);

	if(!table)
	{
		printf("Erro ao criar arquivo de banco");
		return 0;
	}else{
		return 1;
	}
}



/*Adiciona campo a campo na tabela recebida por parâmetro*/
void addFields(tb_s * tab){
	printf("Quantos campos haverá na tabela?\n");
	scanf("%u",&(tab -> quantFields));
	int i;
	char string[700];
	printf("Digite um nome para a chave primária:\n");
	scanf("%s",(tab -> fields[0].name));
	//strcpy(tab -> fields[0].typeField, "unsigned int");
	strcpy(string,tab -> fields[0].name);
	strcat(string,"(");
	//strcat(string,tab -> fields[0].typeField);
	strcat(string,")");
	strcat(string,"?");

	for( i = 1; i < (tab -> quantFields); i++)
	{
		printf("Nome do campo %i\n",i+1);
		scanf("%s", (tab -> fields[i].name));

		//verifyTypeCampos(&(tab->fields[i]));

		strcat(string,tab -> fields[i].name);
		strcat(string,"(");
		//strcat(string,tab -> fields[i].typeField);
		strcat(string,")");
		strcat(string,"?");
	}

	addTablesInFile(tab -> src,string);

}

/*Recebe o id, o nome e o endereço da tabela, envia para uma função que cria o arquivo e 
recebe os campos que deverão ser adicionados.

Ver alternativa e dell
*/
void addInfoTable(char * b_name, tb_s * tab, int p){
	printf("Digite o ID(inteiro) da %i ª tabela?\n",p+1);
	scanf("%u", &(tab -> id));
	printf("Digite o nome da %i ª tabela?\n",p+1);
	scanf("%s", &(*tab -> name));
	strcpy((tab -> src),b_name);
	strcat((tab -> src), "/");
	strcat((tab -> src), (tab -> name));
	strcat((tab -> src),".txt");
	
	startDatabases(tab -> src);
	addFields(tab);
}


/*ver utilidade e apagar*/
void addTables(db_s banco){
	FILE * base;
	base = startDatabases(banco.src);//inicia arquivo do banco
	fclose(base);

	printf("Quantas tabelas deseja adicionar no banco?\n");
	scanf("%u", &(banco.quantTables));
	int i;
	char string[500];
	for (i = 0; i < (banco.quantTables); ++i)
	{
		addInfoTable(banco.name,&banco.tables[i],i);
		sprintf(string,"%i?%s?%s?", (banco.tables[i].id),(banco.tables[i].name),(banco.tables[i].src));
		addTablesInFile(banco.src,string);
	}

}


/*Nova função para adicionar uma tabela em arquivo*/
void createBase(FILE * base,db_s database){
	startDatabases(database.src);
}



/*Nova função para adicionar uma tabela em arquivo*/
void createTable(FILE * base,tb_s table){
	fprintf(base, "%i?%s?%s?\n", table.id, table.name, table.src);//adiciona dados da tabela no arquivo do banco
	startDatabases(table.src);
}


/*Funções de tratamento dos campos da tabela*/

/**/
/**/

/*Função para adicionar campo da tabela*/
void createField(tb_s table, int pos){
	char line[5000], newLine[7000];
	int posLine = 0, i =0, aux = 0, j=0;
	char nameTemp[500],c;

	while(table.src[i] != '/'){
		nameTemp[i] = table.src[i];
		i++;
	} 
	i=0;

	strcat(nameTemp,"/temp.txt");

	FILE * t = fopen(table.src,"a+");
	FILE * t1 = fopen(nameTemp, "w+");
	if((c = getc(t) ) == EOF){
		fprintf(t1, "%s(%s)?\n",table.fields[pos].name,table.fields[pos].typeField);
	}

	while( (fgets(line, sizeof(line), t))!= NULL ){
		if (posLine == 0)
		{	 

			for (i = 0; i < strlen(line) -1 ; ++i)
			{
				newLine[i] = line[i];
			}
			strcat(newLine, table.fields[pos].name);
			strcat(newLine, "(");
			strcat(newLine, table.fields[pos].typeField);
			strcat(newLine, ")");
			strcat(newLine, "?\n");
			fprintf(t1, "%s",newLine);


		}else{
			for (i = 0; i < strlen(line) - 1 ; ++i)
			{
				newLine[i] = line[i];
			}
			strcat(newLine, "NULL?\n");
			fprintf(t1, "%s",newLine);
			printf("%s\n",newLine);
		}
		for(j = strlen(newLine);  j >=0; j--)
		{
			newLine[j] = '\0';
		}
		posLine++;
	}
	fclose(t1);
	fclose(t);

   remove(table.src);//apaga o arquivo original
   rename(nameTemp,table.src);//substitui
}

