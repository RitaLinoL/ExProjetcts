#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "init.h"

/*Funções de init.c.*/
int end;
/*Inicialização das opções do SGBD -  struct mitra - OBRIGATÓRIA -
Atividades: Leitura do arquivo dos bancos com adição de todos na struct;
*/
int init(){
	end =0;
	Mitra * mitra = malloc(sizeof(Mitra));

	mitra -> src = malloc(sizeof(char) * 20);

	strcpy(mitra -> src, "database.txt");
	mitra -> quantBases = 0;
	//chamar funções de transferencia do arquivo para as structs
	share_SGBD(mitra);
	int i =0;
	int j=0;
	int c =0;
	//carrega os bancos		

	for ( i = 0; i < mitra -> quantBases; ++i)
	{	
		mitra -> bases_in_mitra[i] = share_base(mitra -> bases_in_mitra[i]);
	}
	//carrega as tabelas de cada banco
	db_s database;
	for ( i = 0; i < mitra -> quantBases; ++i)
	{
		

		database = mitra -> bases_in_mitra[i];
		for ( j = 0; j < database.quantTables; ++j)
		{
			database.tables[j] = share_table(database.tables[j]);
		}
	}

	//carrega os campos de cada tabela
	tb_s table;
	for ( i = 0; i < mitra -> quantBases; ++i)
	{
		database = mitra -> bases_in_mitra[i];
		for ( j = 0; j < database.quantTables; ++j)
		{
			table = database.tables[j];
			for ( c = 0; c < table.quantFields; ++c)
			{
				table = share_value(table);
			}	


		}
	}
	

	optionMitra(mitra);

	free(mitra);
	return end;

}

/*Abaixo a função responsavel pelo redirecionamento de ações solicitadas pelo usuário
para as funções de processamento dos bancos de mitra
*/


svoid optionMitra(Mitra * mitra){
	int opBd = 0;
	printf("\n _____________________");
	printf("\n|        Mitra        |");
	printf("\n ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾");
	printf("\n _____________________\n");
	printf("|1 : Criar novo banco |\n|2 : Acessar banco    |\n|3 : Deletar banco    |\n|0 : Fechar\t      |"); 
	printf("\n ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\n");
	printf("\n _______________");
	printf("\n|    Entrada    |");
	printf("\n ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\n");

	printf("\t");
	scanf("%i", &opBd);
	//redirecionamento de acordo com a opção escolhida
	
	switch(opBd)
	{
		case (1):
		;	
		addBase(mitra);
		break;
		
		case (2):
		;
		int op = 0;

		do{
			selectBases(mitra);	
				printf("\n Qual a posição do banco a ser acessado?\n"); //opções oferecidas para mitra
				scanf("%i", &op);
			}while(op > (mitra -> quantBases));

			if(!optionDatabase(mitra -> bases_in_mitra[op - 1])){//caso a opção voltar seja selecionada, ele apresenta novamente as opçao do
				opBd = -4;
			}
			
			break;

			case (3):
			;
			char op3[300];
			
			selectBases(mitra);	
			printf("\n Qual o nome do banco a ser apagado?\n"); //opções oferecidas para mitra
			scanf("%s", op3);
			
			deleteBase(mitra,  op3);

			
			break;
			case (0):

			end = 1;
			break;

			default:
			printf("\t\tOpção inválida!\n");
			printf("\t_\t_\t_\t_\t_\t_\t_\t_\t_\t_\t_\t_\t_\t_\n");
			optionMitra(mitra);
			break;
		}
	}


/*Inicialização das opções do banco selecionado - struct db_s
Atividades: Leitura do arquivo do banco selecionado com adição das tabelas junto com o cabeçalho de campos;*/

	int optionDatabase(db_s database){

		int opBd = 0;
		printf("\n _____________________");
		printf("\n|      DataBase       |");
		printf("\n ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾");
		printf("\n _____________________\n");
		printf("|1 : Criar nova tabela|\n|2 : Acessar tabela   |\n|3 : Deletar tabela   |\n|4 : Voltar\t      |\n|0 : Fechar\t      |"); 
		printf("\n ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\n");	
		printf("\n _______________");
		printf("\n|    Entrada    |");
		printf("\n ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\n");

		printf("\t");
		scanf("%i", &opBd);


		
		switch(opBd)
		{
			case (1):
			;	
			database = addTable(database);
			return 0;
			break;
			
			case (2):
			;
			int op = 0;
			do{
				selectTables(database);	
				printf("\n Qual a posição da tabela a ser acessada?\n"); //opções oferecidas para mitra
				scanf("%i", &op);
			}while(op > (database.quantTables));

			if(optionTable(database.tables[op -1])){//caso a opção voltar seja selecionada, ele apresenta novamente as opçao do banco
				opBd = -4;
			}
			
			return 0;
			break;

			case (3):
			;
			char name[500];
			selectTables(database);	
			printf("\n Qual o nome da tabela a ser apagada?\n"); //opções oferecidas para mitra
			scanf("%s", name);

			database = deleteTable(database,name);

			return 0; 
			break;
			case (4):

			return 1;
			break;
			case (0):

			end = 1;
			return 0;
			break;

			default:
			printf("\t\tOpção inválida!\n");
			printf("\t_\t_\t_\t_\t_\t_\t_\t_\t_\t_\t_\t_\t_\t_\n");
			optionDatabase(database);//recursividade para caso nenhuma opção das citadas;
			break;
		}
	}


/*Inicialização das opções da tabela selecionada
Atividades: Leitura do arquivo da tabela com a adição dos valores na struct de campos.
*/

	int optionTable(tb_s table){
		int opBd = 0;

		printf("\n _____________________");
		printf("\n|       Tables        |");
		printf("\n ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾");
		printf("\n _____________________\n");
		printf("|1 : Criar Campo      |\n|2 : Ver Campos\t      |\n|3 : Deletar Campo    |\n|4 : Adicionar Valores|\n|5 : Deletar Valores  |\n|6 : Atualizar Valores|\n|7 : Ver Valores      |\n|8 : Filtrar Valores  |\n|9 : Voltar\t      |\n|0 : Fechar\t      |"); 
		printf("\n ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\n");	
		printf("\n _______________");
		printf("\n|    Entrada    |");
		printf("\n ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\n");
		scanf("%i", &opBd);
		switch(opBd)
		{
			case (1):
			addField(table);
			return 0;
			break;
			
			case (2):
			selectFields(table);
			return 0;
			break;

			case (3):
			selectFieldsEnum(table);
			int pos1 = -1;
			printf("Digite a posição do campo para ser deletado:\n");
			scanf("%i",&pos1);
			pos1--;
			table =deleteField(table,pos1);
			return 0; 
			break;
			case (4):
			table =addValues(table);
			return 0; 
			break;

			case (5):
			selectValues(table);
			void * id;
			printf("\n Qual o id da linha a ser apagada?\n"); 

			if(!(strcmp(table.fields[0].typeField,"int_"))){
				int * id_ = malloc(sizeof(int*));
				scanf("%i", id_);
				id = malloc(sizeof(int*));
				id = id_;
			}else if(!(strcmp(table.fields[0].typeField,"float_"))){
				float * id_ =malloc(sizeof(float*));
				scanf("%f", id_);
				id = malloc(sizeof(float*));
				id = id_;
			}else if(!(strcmp(table.fields[0].typeField,"double_"))){
				double * id_ =malloc(sizeof(double*));
				scanf("%lf", id_);
				id = malloc(sizeof(double*));
				id = id_;
			}else if(!(strcmp(table.fields[0].typeField,"string_"))){
				string * id_ = malloc(sizeof(string*));
				scanf("%s", id_ -> str);
				id = malloc(sizeof(string*));
				id = id_;
			}else if(!(strcmp(table.fields[0].typeField,"char_"))){
				char * id_ = malloc(sizeof(char*));
				scanf("%c", id_);
				id = malloc(sizeof(char*));
				id = id_;
			}
			table = deleteValueLine(table,id);

			return 0;
			break;

			case (6):
			selectValues(table);
			int pos =(-1);
			printf("Digite a posição a ser atualizada.\n");
			scanf("%i",&pos);

			table = updateValues(table,pos);

			return 0;
			break;
			case (7):
			selectValues(table);
			return 0;
			break;
			case (8):
			selectFieldsEnum(table);
			int pos2 = (-1), op =0;
			printf("Digite a posição do campo para filtrar os valores.\n");
			scanf("%i",&pos2);
			pos2--;
			if (!(strcmp(table.fields[pos2].typeField,"string_")))
			{
				printf("1) Strings iguais a --\n2) Strings que contém a palavra --\n ");
				scanf("%i",&op);
			}else{
				printf("1) Valores maiores que --\n2) Valores maiores ou iguais a--\n3) Valores iguais a --\n4) Valores menores que --\n5) Valores menores ou iguais a -- \n");
				scanf("%i",&op);
			}
			selectFilter(table,pos2,op);
			return 0;
			break;
			case (9):

			return 1;
			break;
			case (0):

			end = 1;
			return 0;
			break;

			default:
		printf("\n ____________________");
		printf("\n|   Opção Invalida   |");
		printf("\n ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\n");
			optionTable(table);//recursividade para caso nenhuma opção das citadas;
			break;
		}
	}

	



