//configuracao do grafico 1
var config_line2 = {
  type: 'line',
  data: {
    labels: [],
    datasets: [{
      label: 'Envios da temperatura',
      backgroundColor: window.chartColors.red,
      borderColor: window.chartColors.red,
      data: [],
      fill: false,
    }]
  },
  options: {
    responsive: true,
    title: {
      display: true,
      text: 'Temperatura'
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
    hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        type: 'time',
        ticks: {
          minRotation: 5485,
          source: 'data'  
        },
        distribution: 'series',
        display: false,
        scaleLabel: {
          display: true,
          labelString: 'Tempo'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: 'Cº'
        }
      }]
    }
  }
};

/*cria o grafico myline2 com os ultimos valores enviados#
* para o thingspeak
*/
function createMyLine2() {
  ctx = document.getElementById('canvasTemperatura').getContext('2d');
  console.log(config_line2.data);
  window.myLine2 = new Chart(ctx, config_line2);
  getLastThingSpeakData();
};

/*
* requisita os ultimos dados enviados para o thingspeak
* e atualiza os valores no grafico
*/
function getLastThingSpeakData(){
  
  channel_id = 727458; //id do canal
  field_number = 1 ;//numero do field
  num_results = 5485; //numero de resultados requisitados
  $.getJSON('https://api.thingspeak.com/channels/' + channel_id + '/fields/' + field_number + '.json?results='+num_results, function(data) {
    // get the data point
    feeds = data.feeds;
    // imprime os feeds recebidos
     console.log(data.feeds)
    // intera em todos os feeds recebidos e os adiciona no grafico
    for (d in feeds)
    {
      //variavel config_line2.data.datasets[0].data eh equivalente ao eixo y
      config_line2.data.datasets[0].data.push(feeds[d].field1);
      //variavel config_line2.labels eh equivalente ao eixo x
      x_date = new Date(feeds[d].created_at);
      config_line2.data.labels.push(x_date);
    }
    window.myLine2.update();
  });
}
  













//configuracao do grafico 2
var config_line3 = {
  type: 'line',
  data: {
    labels: [],
    datasets: [{
      label: 'Envios da Umidade',
      backgroundColor: window.chartColors.blue,
      borderColor: window.chartColors.blue,
      data: [],
      fill: false,
    }]
  },
  options: {
    responsive: true,
    title: {
      display: true,
      text: 'Umidade'
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
    hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        type: 'time',
        ticks: {
          minRotation: 5485,
          source: 'data'  
        },
        distribution: 'series',
        display: false,
        scaleLabel: {
          display: true,
          labelString: 'Tempo'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: '%'
        }
      }]
    }
  }
};

/*cria o grafico myline2 com os ultimos valores enviados#
* para o thingspeak
*/
function createMyLine3() {
  ctx = document.getElementById('canvasUmidade').getContext('2d');
  console.log(config_line3.data);
  window.myLine3 = new Chart(ctx, config_line3);
  getLastThingSpeakData3();
};

/*
* requisita os ultimos dados enviados para o thingspeak
* e atualiza os valores no grafico
*/
function getLastThingSpeakData3(){
  
  channel_id = 727458; //id do canal
  field_number = 2 ;//numero do field
  num_results = 5485; //numero de resultados requisitados
  $.getJSON('https://api.thingspeak.com/channels/' + channel_id + '/fields/' + field_number + '.json?results='+num_results, function(data2) {
    // get the data point
    feeds = data2.feeds;
    // imprime os feeds recebidos
    console.log(data2.feeds)
    // intera em todos os feeds recebidos e os adiciona no grafico
    for (d in feeds)
    {
      //variavel config_line2.data.datasets[0].data eh equivalente ao eixo y
      config_line3.data.datasets[0].data.push(feeds[d].field2);
      //variavel config_line2.labels eh equivalente ao eixo x
      x_date = new Date(feeds[d].created_at);
      config_line3.data.labels.push(x_date);
    }
    window.myLine3.update();
  });
}
  








//configuracao do grafico 3
var config_line4 = {
  type: 'line',
  data: {
    labels: [],
    datasets: [{
      label: 'Envios da Luminosidade',
      backgroundColor: window.chartColors.green,
      borderColor: window.chartColors.green,
      data: [],
      fill: false,
    }]
  },
  options: {
    responsive: true,
    title: {
      display: true,
      text: 'Luminosidade'
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
    hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        type: 'time',
        ticks: {
          minRotation: 5485,
          source: 'data'  
        },
        distribution: 'series',
        display: false,
        scaleLabel: {
          display: true,
          labelString: 'Tempo'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: ''
        }
      }]
    }
  }
};

/*cria o grafico myline2 com os ultimos valores enviados#
* para o thingspeak
*/
function createMyLine4() {
  ctx = document.getElementById('canvasLuminosidade').getContext('2d');
  console.log(config_line4.data);
  window.myLine4 = new Chart(ctx, config_line4);
  getLastThingSpeakData4();
};

/*
* requisita os ultimos dados enviados para o thingspeak
* e atualiza os valores no grafico
*/
function getLastThingSpeakData4(){

  channel_id = 727458; //id do canal
  field_number = 3; //numero do field
  num_results = 5485; //numero de resultados requisitados
  $.getJSON('https://api.thingspeak.com/channels/' + channel_id + '/fields/' + field_number + '.json?results='+num_results, function(data3) {
    // get the data point
    feeds = data3.feeds;
    // imprime os feeds recebidos
    console.log(data3.feeds)
    // intera em todos os feeds recebidos e os adiciona no grafico
    for (d in feeds)
    {
      //variavel config_line2.data.datasets[0].data eh equivalente ao eixo y
      config_line4.data.datasets[0].data.push(feeds[d].field3);
      //variavel config_line2.labels eh equivalente ao eixo x
      x_date = new Date(feeds[d].created_at);
      config_line4.data.labels.push(x_date);
    }
    window.myLine4.update();
  });
}
  




//configuracao do grafico 4
var config_line5 = {
  type: 'line',
  data: {
    labels: [],
    datasets: [{
      label: 'Envios de Som',
      backgroundColor: window.chartColors.red,
      borderColor: window.chartColors.red,
      data: [],
      fill: false,
    }]
  },
  options: {
    responsive: true,
    title: {
      display: true,
      text: 'Som'
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
    hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        type: 'time',
        ticks: {
          minRotation: 5485,
          source: 'data'  
        },
        distribution: 'series',
        display: false,
        scaleLabel: {
          display: true,
          labelString: 'Tempo'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: ''
        }
      }]
    }
  }
};

/*cria o grafico myline2 com os ultimos valores enviados#
* para o thingspeak
*/
function createMyLine5() {
  ctx = document.getElementById('canvasSonoridade').getContext('2d');
  console.log(config_line5.data);
  window.myLine5 = new Chart(ctx, config_line5);
  getLastThingSpeakData5();
};

/*
* requisita os ultimos dados enviados para o thingspeak
* e atualiza os valores no grafico
*/
function getLastThingSpeakData5(){

  channel_id = 727458; //id do canal
  field_number = 4; //numero do field
  num_results = 5485; //numero de resultados requisitados
  $.getJSON('https://api.thingspeak.com/channels/' + channel_id + '/fields/' + field_number + '.json?results='+num_results, function(data4) {
    // get the data point
    feeds = data4.feeds;
    // imprime os feeds recebidos
    console.log(data4.feeds)
    // intera em todos os feeds recebidos e os adiciona no grafico
    for (d in feeds)
    {
      //variavel config_line2.data.datasets[0].data eh equivalente ao eixo y
      config_line5.data.datasets[0].data.push(feeds[d].field4);
      //variavel config_line2.labels eh equivalente ao eixo x
      x_date = new Date(feeds[d].created_at);
      config_line5.data.labels.push(x_date);
    }
    window.myLine5.update();
  });
}
  



//configuracao do grafico 6
var config_line6 = {
  type: 'line',
  data: {
    labels: [],
    datasets: [{
      label: 'Função do consumo',
      backgroundColor: window.chartColors.green,
      borderColor: window.chartColors.green,
      data: [],
      fill: false,
    }]
  },
  options: {
    responsive: true,
    title: {
      display: true,
      text: 'Consumo'
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
    hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        type: 'time',
        ticks: {
          minRotation: 5485,
          source: 'data'  
        },
        distribution: 'series',
        display: false,
        scaleLabel: {
          display: true,
          labelString: 'Tempo'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: 'kW/h'
        }
      }]
    }
  }
};

/*cria o grafico myline2 com os ultimos valores enviados#
* para o thingspeak
*/
function createMyLine6() {
  ctx = document.getElementById('canvasConsumo').getContext('2d');
  console.log(config_line6.data);
  window.myLine6 = new Chart(ctx, config_line6);
  getLastThingSpeakData6();
};

/*
* requisita os ultimos dados enviados para o thingspeak
* e atualiza os valores no grafico
*/
function getLastThingSpeakData6(){

  channel_id = 727458; //id do canal
  field_number = 5; //numero do field
  num_results = 5485; //numero de resultados requisitados
  $.getJSON('https://api.thingspeak.com/channels/' + channel_id + '/fields/' + field_number + '.json?results='+num_results, function(data5) {
    // get the data point
    feeds = data5.feeds;
    // imprime os feeds recebidos
    console.log(data5.feeds)
    // intera em todos os feeds recebidos e os adiciona no grafico
    for (d in feeds)
    {
      //variavel config_line2.data.datasets[0].data eh equivalente ao eixo y
      config_line6.data.datasets[0].data.push(feeds[d].field5);
      //variavel config_line2.labels eh equivalente ao eixo x
      x_date = new Date(feeds[d].created_at);
      config_line6.data.labels.push(x_date);
    }
    window.myLine6.update();
  });
}







//configuracao do grafico 5
var config_line7 = {
  type: 'line',
  data: {
    labels: [],
    datasets: [{
      label: 'Média de som por minuto',
      backgroundColor: window.chartColors.blue,
      borderColor: window.chartColors.blue,
      data: [],
      fill: false,
    }]
  },
  options: {
    responsive: true,
    title: {
      display: true,
      text: 'Ruídos'
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
    hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        type: 'time',
        ticks: {
          minRotation: 5485,
          source: 'data'  
        },
        distribution: 'series',
        display: false,
        scaleLabel: {
          display: true,
          labelString: 'Tempo'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: ''
        }
      }]
    }
  }
};

/*cria o grafico myline2 com os ultimos valores enviados#
* para o thingspeak
*/
function createMyLine7() {
  ctx = document.getElementById('canvasRuidos').getContext('2d');
  console.log(config_line7.data);
  window.myLine7 = new Chart(ctx, config_line7);
  getLastThingSpeakData7();
};

/*
* requisita os ultimos dados enviados para o thingspeak
* e atualiza os valores no grafico
*/
function getLastThingSpeakData7(){

  channel_id = 727458; //id do canal
  field_number = 6; //numero do field
  num_results = 5485; //numero de resultados requisitados
  $.getJSON('https://api.thingspeak.com/channels/' + channel_id + '/fields/' + field_number + '.json?results='+num_results, function(data6) {
    // get the data point
    feeds = data6.feeds;
    // imprime os feeds recebidos
    console.log(data6.feeds)
    // intera em todos os feeds recebidos e os adiciona no grafico
    for (d in feeds)
    {
      //variavel config_line2.data.datasets[0].data eh equivalente ao eixo y
      config_line7.data.datasets[0].data.push(feeds[d].field6);
      //variavel config_line2.labels eh equivalente ao eixo x
      x_date = new Date(feeds[d].created_at);
      config_line7.data.labels.push(x_date);
    }
    window.myLine7.update();
  });
}
 




//configuracao do grafico 7
var config_line8 = {
  type: 'bar',
  data: {
    labels: [],
    datasets: [{
      label: 'Atividade na sala',
      backgroundColor: window.chartColors.red,
      borderColor: window.chartColors.red,
      data: [],
      fill: false,
    }]
  },
  options: {
    responsive: true,
    title: {
      display: true,
      text: 'Atividade'
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
    hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        type: 'time',
        time: {
          unit: 'minute'
        },
        ticks: {
          minRotation: 300,
          source: 'data'  
        },
        distribution: 'series',
        display: false,
        scaleLabel: {
          display: true,
          labelString: 'Tempo'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: ''
        }
      }]
    }
  }
};

/*cria o grafico myline2 com os ultimos valores enviados#
* para o thingspeak
*/
function createMyLine8() {
  ctx = document.getElementById('canvasAtividade').getContext('2d');
  console.log(config_line8.data);
  window.myLine8 = new Chart(ctx, config_line8);
  getLastThingSpeakData8();
};

/*
* requisita os ultimos dados enviados para o thingspeak
* e atualiza os valores no grafico
*/
function getLastThingSpeakData8(){

  channel_id = 727458; //id do canal
  field_number = 7; //numero do field
  num_results =300; //numero de resultados requisitados
  $.getJSON('https://api.thingspeak.com/channels/' + channel_id + '/fields/' + field_number + '.json?results='+num_results, function(data7) {
    // get the data point
    feeds = data7.feeds;
    // imprime os feeds recebidos
    console.log(data7.feeds)
    // intera em todos os feeds recebidos e os adiciona no grafico
    for (d in feeds)
    {
      //variavel config_line2.data.datasets[0].data eh equivalente ao eixo y
      config_line8.data.datasets[0].data.push(feeds[d].field7);
      //variavel config_line2.labels eh equivalente ao eixo x
      x_date = new Date(feeds[d].created_at);
      config_line8.data.labels.push(x_date);
    }
    window.myLine8.update();
  });
}
 