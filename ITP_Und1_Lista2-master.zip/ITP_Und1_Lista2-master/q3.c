#include <stdio.h>

void main(){
    int n, maior, menor, segundomenor, segundomaior, num, soma;
    float media;
    scanf("%i", &n);
  
    for(int i=0; i<n; i++){
        scanf("%i",&num);
        soma += num;
        if(i == 0){
           maior = num;
           menor = num;
        }
        
        if(i == 1){
            segundomenor = num;
           segundomaior = num;
        }

        if(num < menor){
            segundomenor = menor;
            menor = num;
        }else if(num < segundomenor ){
            segundomenor = num;
        }

        if(num > maior){
            segundomaior = maior;
            maior = num;
        }else if(num >segundomaior){
            segundomaior = num;
        }
    
    }

    media = soma/n;
    printf("Maior : %i \n", maior);
    printf("Menor : %i \n", menor);
    printf("Dois maiores : %i %i \n", segundomaior, maior);
    printf("Dois menores : %i %i \n", segundomenor, menor);
    printf("Média : %f", media);
   
}