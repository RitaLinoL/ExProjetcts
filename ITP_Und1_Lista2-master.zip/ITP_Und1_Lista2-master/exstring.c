#include <stdio.h>
#include <string.h>

void main(){
	char str[10] ="Aula", stg[10] ="ITP";
	
	printf("%s", strncat(str,stg));
}