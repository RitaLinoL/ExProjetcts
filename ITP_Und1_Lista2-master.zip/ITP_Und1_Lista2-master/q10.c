#include <stdio.h>

void main(){

    float sal, R;
    char op;

    do
    {
        printf("\nEntre com seu salário:");
        scanf("%f", &sal);

        printf("Deseja calcular a renda anual?");
        scanf(" %c", &op);

        
        if (op == 's') {
            R = sal * 13;
            printf("%.2f", R);
        }

        printf("Deseja continuar a operação?");
        scanf(" %c", &op);

    } while (op == 's');
    printf("Operação Finalizada"); 
    
}