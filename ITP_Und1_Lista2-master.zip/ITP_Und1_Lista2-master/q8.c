#include <stdio.h>

void main()
{
    int n, fat=1;
    scanf("%i", &n);

    for(int i = 1; i<=n;i++){
       fat *= i;
    }
    printf("%i\n", fat);
}
