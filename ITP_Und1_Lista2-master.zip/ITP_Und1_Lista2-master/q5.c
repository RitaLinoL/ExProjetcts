#include <stdio.h>

void main(){

    char op;
    int l;

    scanf("%c ", &op);
    
    
    switch (op)
    {
        case 'c':
            scanf("%i", &l);

            for (int i = 0; i<l; i++){
                for(int j = 0; j<l; j++){
                    printf("*");
                }
                printf("\n");
            }
             
            break;
        case 'o':
            scanf("%i", &l);
            for(int j = 0; j<l; j++){
                printf("*");
            }
            printf("\n");
            for (int j = 2; j<l; j++){
                printf("*"); 
                for (int j = 2; j<l; j++){
                    printf(" ");  
                }   
                printf("*\n");             
            }
            for(int j = 0; j<l; j++){
                printf("*");
            } 
            printf("\n");          
            break;
        case 't':
            scanf("%i", &l);
            for(int i =0; i<l; i++){

               for(int l  = 0; l<=i; l++){
                    printf("*");
                }
                printf("\n");
            }
        
            break;
    
        default:
            printf("Opção inválida!");
            break;
    }

    
}