#include <stdio.h>

void main(){

    int n1, n2;

    scanf("%i %i", &n1, &n2);

    if (n1 == n2){
        printf("Números Iguais!");
    }else if(n1<n2){
        for(int i  = (n1+1); i<n2; i++){
            printf("%i \n",i);
        }
    }else{
        for(int i  = (n2+1); i<n1; i++){
            printf("%i \n",i);
        }
    }
}