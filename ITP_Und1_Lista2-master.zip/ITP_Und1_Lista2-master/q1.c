#include <stdio.h>

void main()
{
    //a
    while ( c <= 5 ) {
        product *= c;
        ++c; 
    }
    //b
   // scanf( "%4f", &value );

    //c
    if ( gender == 1 ){
        puts( "Mulher" );
    }else{
        puts( "Homem" );
    }

    //d
    if ( age >= 65 ){
        puts( "Idade é maior ou igual que 65" );
    }else{
        puts( "Idade é menor que 65" );
    }

    //e
    int x = 1, total =0;
    while ( x <= 10 ) {
        total += x;
        ++x;
    }  
    
    //f
    while ( x <= 100 ){
        total += x;
        ++x;
    }

    //g
    while ( y < 0 ) {
        printf( "%d\n", y );
        ++y;
    }

    //h
    x = 1;
    while ( x <= 10 ){
        ++x;
    }

    //i
    for( x = 100; x >= 1; --x )
        printf( "%d\n", x );
}
