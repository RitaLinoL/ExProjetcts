#include <stdio.h>
#include <math.h>


int fatorial(int m){
	int fat = 1;
	for (int i = 0; i <= m; ++i)
	{
		fat*= i;
	}
	return fat;
}



