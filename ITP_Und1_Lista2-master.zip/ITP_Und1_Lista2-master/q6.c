#include <stdio.h>

void main(){

    int n1, n2, u , p, max;

    scanf("%i", &n1);
    scanf("%i", &n2);
    
    if (n1 <= n2){
        p = n1;
        u = n2;
    }else{
        u = n1;
        p = n2;
    }

    for(int i = p+1; i < u; i++)
    {
        if(i%2==0){
            printf("%i\n",i);
        }
    }

    
    for(int i = 1; i <= p; i++)
    {      
        if ((p%i ==0) && (u%i==0)) {
            max = i;
        }      
    }
    printf("MDC: %i\n", max);
    
    
}