#include <stdio.h>
#include <math.h>

void main()
{
    int i = 0, pos = 0;
    double pi = 4, den =3.00, aux,c1=0,c2=0,c3=0,c4=0;

    while(i == 0){      
        if (pos%2==0) {
            aux = (4/den) * (-1);
        }
        else {
            aux = (4/den) ;
        }

        pi += aux;

        if (((floor(pi*100) /100) == 3.14) && (c1==0)){
            printf("%lf - %i\n", pi, pos);
            c1 = 1;
        } 
        if(((floor(pi*1000) /1000) == 3.141)&& (c2==0)){
            printf("%lf - %i\n", pi, pos);
            c2 = 1;
        }
        if(((floor(pi*10000) /10000) == 3.1414)&& (c3==0)){
            printf("%lf - %i\n", pi, pos);
            c3 = 1;
        }
        if(((floor(pi*1000000)/1000000) == 3.14159) && (c4==0)){
            printf("%lf - %i\n", pi, pos);
            c4 = 1;
        }
        if (c1 && c2 && c3 && c4){
            i = 1;
        }
        pos++;
        den+=2;
    }
    
    
    
}
