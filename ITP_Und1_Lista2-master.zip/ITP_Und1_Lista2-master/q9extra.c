#include <stdio.h>
#include <math.h>


int fatorial(int n){
    int fat=1;
    for(int i = 1; i<=n;i++){
       fat *= i;
    }
    return fat;
}


void main(){
    long double e = 1.0, fat,x, pot;
    scanf("%Lf",&x);

    for(int i = 1; i <=2; i++)
    {
        fat = fatorial(i);
        pot = pow(x,i);
        e += pot/fat;
    }
    printf("%Lf", e);
    
}