#include <stdio.h>

void main(){
    printf("N\t10*N\t100*N\t1000*N\n");
    for(int n = 1; n<=10; n++){
        printf("%i\t%i\t%i\t%i\n",n,n*10,n*100,n*1000);
    }
}