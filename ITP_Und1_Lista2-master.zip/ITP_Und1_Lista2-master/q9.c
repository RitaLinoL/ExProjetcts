#include <stdio.h>


int fatorial(int n){
    int fat=1;
    for(int i = 1; i<=n;i++){
       fat *= i;
    }
    return fat;
}


void main(){
    long double e = 1.0, fat;

    for(int i = 1; i <=1000; i++)
    {
        fat = fatorial(i);
        e += 1.0/fat;
    }
    printf("%Lf", e);
    
}