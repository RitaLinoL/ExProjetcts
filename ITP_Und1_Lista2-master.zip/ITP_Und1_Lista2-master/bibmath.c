#include <stdio.h>
#include <math.h>


int fibonnaci(int m){

}


void main(){

	long int x, exp = 1;

	for (int i = 0; i <= 10; ++i)
	{
		printf("%li\n", pow(x,exp));

	}

}