<h1 style="text-align: center;">Dupla:</h1>
<h2>José Lúcio da Silva Júnior</h2> 
<h2>Rita de Cássia Lino Lopes</h2>

<br/>


<h1>Compilar e rodar</h1>
<h2>main</h2>
<p>Executar o makefile e, em seguida, executar o arquivo executável "./Laboratorio2".</p>
<h2>a</h2>
<p>Verificável no arquivo Funcionario.h e Funcionario.cpp</p>
<h2>b</h2>
<p>Arquivo Empresa.h e Empresa.cpp</p>
<h2>c</h2>
<p>A opção 1 do menu oferece a criação de uma emprea por meio da função createEmpresa() no arquivo main.cpp. É preciso digitar o nome e o CNPJ da empresa, os funcionários precisam ser adicionados posteriormente.</p>
<h2>d</h2>
<p>A opção 2 adiciona um funcionário na empresa selecionada por meio da função addFunc_na_lista() no arquivo Empresa.h e Empresa.cpp. É preciso digitar o nome, o CPF, o salário e a data de admissão do funcionário.</p>
<h2>e</h2>
<p>No arquivo main.cpp, a opção 3 chama a função listarFuncionarios() por meio da  sobrecarga do operador de inserção e mostra os funcionários de uma empresa.</p>
<h2>f</h2>
<p>A função aumentarSalario() no arquivo main.cpp, aumenta em X% o salário de todos os funcionários da empresa passada por parâmetro.</p>
<h2>g</h2>
<p>Usamos a biblioteca ctime para pegar a data atual e a sobrecarga do operador de subtração calculamos a diferença.</p>
<h2>h</h2>
<p>Com atributos estáticos a função da 6 opção mostra a média de Funcionários.</p>

<br/>
<h1>Limitações e dificuldades</h1>
<<p>A principal dificuldade esteve relacionada com a alternativa g, pois precisavámos usar uma biblioteca. Tentamos a chrono e usar _DATE_. Porém, ao fim, encontramos a funcionalidade ideal na ctime.</p>
