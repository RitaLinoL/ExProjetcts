#ifndef DATA_H
#define DATA_H
#include <iostream>
using namespace std;

//Classe Data, seus atributos e métodos
class Data
{
private:
      int dia;
      int mes;
      int ano;
public:
     
      Data();
      Data(int d, int m, int a);
      ~Data();
      void setData(int d, int m, int a);
      Data getData();
      int getDia();
      int getMes();
      int getAno();
      void setDia(int d);
      void setMes(int m);
      void setAno(int a);
      Data operator-(Data &p);
      friend std::ostream& operator<<(std::ostream &o, Data const d);
      friend bool operator==(Data const d1, Data const d2);

};

#endif
