#ifndef EMPRESA_H
#define EMPRESA_H

#include <iostream>
#include "Funcionario.h"
#include "Data.h"
#include <vector>

/*Classe Empresa, seus atributos e métodos.*/
class Empresa
{
	private:
		string nome;
		string CNPJ;
		vector <Funcionario> lista_func; 
		static int quantEmpresas;
	public:
		Empresa();
		Empresa(string n, string cnpj, vector <Funcionario> f);
		~Empresa();
		string getNome();
		string getCNPJ();
		vector <Funcionario> getLista_func();
		static int getQuantEmpresas();
		void setNome(string n);
		void setCNPJ(string cnpj);
		void setLista_func(vector <Funcionario> l);
		void addFunc_na_lista(Funcionario f);
		friend std::ostream& operator<<(std::ostream &o, Empresa const e);
		friend std::vector<Funcionario> operator+(std::vector<Funcionario> funcionarios, Funcionario const f);
};

#endif
