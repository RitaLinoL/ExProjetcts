#include <iostream>
#include <cstring> 
#include "Data.h"
#include <ostream>

using namespace std;


//Sobrecarga do operador de inserção para imprimir a data na tela.
std::ostream& operator<<(std::ostream &o, Data const d){
    o << d.dia << "/" << d.mes << "/" << d.ano;
    return o;
}


//Sobrecarga do operador de igualdade para comparar datas
bool operator==(Data const d1, Data const d2){
      if ((d1.dia == d2.dia) && (d1.mes == d2.mes) && (d1.ano  == d2.ano)){
            return true;
      }
      return false;
}

//sobrecarga de operador de subtração
Data Data::operator-(Data &p){
	int d = dia - p.dia;
	int m = mes - p.mes;
	int a = ano - p.ano;

	return Data(d, m, a);
}

//Construtor padrão. 
Data::Data(){
      mes = 1;
      dia = 1;
      ano = 1900;
}

//Construtor parametrizado. 
Data::Data(int d, int m, int a){
      if(m >= 1 && m <= 12)//verifica se o mês é válido.
            mes = m;
      else
            mes = 1;
      if(d >= 1 && d <= 31)//verifica se o dia é válido.
            dia = d;
      else
            dia = 1;
      if(a >= 1900 && a <= 2019)//verifica se o ano é válido.
            ano = a;
      else
            ano = 1900;
}

//Destrutor.
Data::~Data(){
	
}

//Insere uma data que seja válida.
void Data::setData(int d, int m, int a){
      if(m >= 1 && m <= 12)
            mes = m;
      else
            mes = 1;
      if(d >= 1 && d <= 31)
            dia = d;
      else
            dia = 1;
      if(a >= 1900 && a <= 2019)
            ano = a;
      else
            ano = 1900;
}

//Função que retorna uma classe Data.
Data Data::getData(){
    	return Data(dia, mes, ano);
}

//Funções que retornam dia, mês e ano, respectivamente.
int Data::getDia(){
	return dia;
}

int Data::getMes(){
	return mes;
}

int Data::getAno(){
	return ano;
}

//Funções que inserem o dia, mês e o ano, respectivamente.
void Data::setDia(int d){
	dia = d;
}

void Data::setMes(int m){
	mes = m;
}

void Data::setAno(int a){
	ano = a;
}

