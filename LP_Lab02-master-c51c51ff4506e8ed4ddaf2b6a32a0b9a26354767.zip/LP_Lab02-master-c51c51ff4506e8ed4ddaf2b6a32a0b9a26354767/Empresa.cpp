#include "Empresa.h"
#include "Funcionario.h"
#include <iostream>
#include "Data.h"


/*sobrecarga de operador de inserção para dados básicos */
std::ostream& operator<<(std::ostream &o, Empresa const e){
	o << "Nome: " << e.nome << endl << "CNPJ: " << e.CNPJ <<endl;
	return o;
}

/*sobrecarga de operador de soma de funcionario em lista de funcionarios de uma empresa*/
vector <Funcionario> operator+( vector <Funcionario> funcionarios, Funcionario const f){
	//comparar os funcionarios
	for (unsigned int i = 0; i < funcionarios.size(); ++i)
	{
		if (funcionarios[i] == f)
		{
			return funcionarios;	
		}
	}

	funcionarios.push_back(f);

	return funcionarios;
}

/*Construtor padrão.*/
Empresa::Empresa(){
	nome = "fantasma";
	CNPJ = "";
	lista_func.clear();
	quantEmpresas++;
}

/*Construtor parametrizado*/
Empresa::Empresa(string n, string cnpj, vector <Funcionario> f){
	nome = n;
	CNPJ = cnpj;
	lista_func = f;
	quantEmpresas++;
}

/*Destrutor*/
Empresa::~Empresa(){

}

/*Retornam o nome, o CNPJ e a lista de funcionários, respectivamente, da empresa.*/
string Empresa::getNome(){
	return nome;
}

string Empresa::getCNPJ(){
	return CNPJ;
}

vector <Funcionario> Empresa::getLista_func(){
	return lista_func;
}

int Empresa::getQuantEmpresas(){
	return quantEmpresas;
}

/*Inserem o nome, o CNPJ e a lista de funcionarios respectivamente, da empresa */
void Empresa::setNome(string n){
	nome = n;
}

void Empresa::setCNPJ(string cnpj){
	CNPJ = cnpj;
}

void Empresa::setLista_func(vector <Funcionario> l){
	lista_func = l;
}

/*Insere um funcionário na lista da empresa.*/
void Empresa::addFunc_na_lista(Funcionario f){
	vector <Funcionario> funcs;
	funcs = Empresa::getLista_func();
	bool unico = true;
	for (unsigned int i = 0; i < funcs.size(); ++i)
	{
		if (funcs[i] == f)
		{
			unico = false;
		}
	}


	if (unico)
	{
		lista_func = lista_func + f;
	}
	
}

