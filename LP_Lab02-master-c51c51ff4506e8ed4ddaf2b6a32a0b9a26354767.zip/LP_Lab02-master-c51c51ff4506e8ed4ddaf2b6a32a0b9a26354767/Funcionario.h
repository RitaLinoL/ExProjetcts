#ifndef FUNCIONARIO_H
#define FUNCIONARIO_H
#include <iostream>
#include "Data.h"
using namespace std;

/*Classe Funcionário, seus atributos e métodos. PS: possui um classe do tipo Data em seus atributos.*/
class Funcionario
{
	private:
		string nome;
		string CPF;
		float salario;
		Data data_admissao;
		static int quantFuncionarios;
	public:
		Funcionario(); 
		Funcionario(string n, string cpf, float s, int d, int m, int a);
		~Funcionario();
		string getNome();
		string getCPF();
		float getSalario();
		Data getData();
		void setNome(string n);
		void setCPF(string cpf);
		void setSalario(float s);
		void setData(int d, int m, int a);
		static int getQuantFuncionarios();
		static void setQuantFuncionariosMenos();
		friend std::ostream& operator<<(std::ostream &o, Funcionario const f);
		friend bool operator==(Funcionario const f1, Funcionario const f2);

};

#endif
