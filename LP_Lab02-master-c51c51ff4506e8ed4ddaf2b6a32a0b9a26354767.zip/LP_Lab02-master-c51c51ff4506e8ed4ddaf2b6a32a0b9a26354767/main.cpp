#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include "Funcionario.h"
#include "Empresa.h"

using namespace std;

int Empresa::quantEmpresas = 0;
int Funcionario::quantFuncionarios = 0;

Empresa createEmpresa(string n, string cnpj, vector<Funcionario> funcionarios);
Empresa & aumentarSalario(Empresa&  empresa, float X);
float mediaFunc_por_Empresa();
void listarFuncionarios(Empresa empresa);
void listarTodosFuncionarios(Empresa empresa);

/*c)Funcao para criacao de empresa.*/
Empresa createEmpresa(string n, string cnpj, vector<Funcionario> funcionarios){
	Empresa empresa;
	empresa.setNome(n);
	empresa.setCNPJ(cnpj);
    	empresa.setLista_func(funcionarios);
    	return empresa;	
}

/*f)Funcao para aumento de salario*/
Empresa& aumentarSalario(Empresa & empresa, float X){
    vector <Funcionario> funcs = empresa.getLista_func();
    for (unsigned int i = 0; i < funcs.size(); ++i)
    {
        funcs[i].setSalario((funcs[i].getSalario() * (X/100) )+funcs[i].getSalario());
    }
    empresa.setLista_func(funcs);
    return empresa;
}


/*h)Funcao para calcular média de funcionarios por empresa*/
float mediaFunc_por_Empresa(){
    float media = 0;
    media = Funcionario::getQuantFuncionarios() / Empresa::getQuantEmpresas();
    return media;
}

/*e) Função para listar todos os funcionarios de uma empresa*/
void listarTodosFuncionarios(Empresa empresa){
	vector <Funcionario> funcs;
	funcs = empresa.getLista_func();
	for(unsigned int i = 0; i < funcs.size(); i++){
		cout << funcs[i] << endl;
	}
}

/*g) Funcao para listar funcionarios com menos de 90 dias de contrato*/
void listarFuncionarios(Empresa empresa){
    time_t t = time(NULL);
    tm* timePtr = localtime(&t);

    int d, m, a, dias;
    d =  timePtr->tm_mday;
    m =  timePtr->tm_mon + 1;
    a =  timePtr->tm_year + 1900;

    vector <Funcionario> funcs;
    funcs = empresa.getLista_func();
    Data data_;

    for (unsigned int i = 0; i < funcs.size(); ++i)
    {
        data_ = funcs[i].getData();
        dias = (((a-data_.getAno())*365)+((m - data_.getMes()) * 30)+(d - data_.getDia()));

        if (dias <= 90)
        {
            cout << funcs[i];
        }

    }

}


int main(int argc, char * argv[]){

    vector <Empresa> empresas;
    empresas.clear();
    bool cont = true;
    
    do{
    
        int op = 0;
        cout << "Digite a oção desejada:" << endl;
        cout << "1 - Adicionar empresa" << endl;
        cout << "2 - Adicionar Funcionários em Empresa" << endl;
        cout << "3 - Listar Funcionários em Empresa" << endl;
        cout << "4 - Aumentar salários de Funcionários de uma empresa" << endl;
        cout << "5 - Listar dados de Funcionarios com menos de 90 dias de contrato" << endl;
        cout << "6 - Listar média de Funcionários" << endl << endl;
        cin >> op;     
               
        if(op == 1){
            string nome;
            cout << "Digite o nome da Empresa:" << endl;
            cin >> nome;

            string cnpj;
            cout << "Digite o CNPJ da Empresa:" << endl;
            cin >> cnpj;

            vector <Funcionario> listafunc;
            listafunc.clear();

            empresas.push_back(createEmpresa(nome, cnpj, listafunc));
                        
        }else{
            string nome, cpf, cnpj;
            int dia, mes, ano;
            float s, aum;
            int indEmp = 0;
            Funcionario f;
        
            cout << "Escolha a empresa:" << endl;
            for(unsigned int i = 0; i < empresas.size(); i++){
                cout << i << " - " << empresas[i] << endl;
            }
            cin >> indEmp;
            switch(op){
                case 2:   		    
                    //f.setQuantFuncionarios--();
		    cout << "Digite o nome:" << endl;
                    cin >> nome;
                    f.setNome(nome);

                    cout << "Digite o CPF:" << endl;
                    cin >> cpf;
                    f.setCPF(cpf);

                    cout << "Digite o salario:" << endl;
                    cin >> s;
                    f.setSalario(s);

                    cout << "Digite o dia de admissão:" << endl;
                    cin >> dia;
                    cout << "Digite o mes de admissão:" << endl;
                    cin >> mes; 
                    cout << "Digite o ano de admissão:" << endl;
                    cin >> ano;
                   
                    f.setData(dia, mes, ano);                    

                    empresas[indEmp].addFunc_na_lista(f);
                    break;
                
		case 3:
		    f.setQuantFuncionariosMenos();
		    listarTodosFuncionarios(empresas[indEmp]);
                    break;
                
		case 4:
		    f.setQuantFuncionariosMenos();
		    cout << "Aumento de quanto (X%)" << endl;
                    cin >> aum;
                    empresas[indEmp] = aumentarSalario(empresas[indEmp], aum);
                    break;
 
 		case 5:
		    f.setQuantFuncionariosMenos();
		    listarFuncionarios(empresas[indEmp]); 
                    break;

		case 6:
		    f.setQuantFuncionariosMenos();
		    cout << mediaFunc_por_Empresa() <<endl;
                    break;

		default:
                    break;
            }
        }
        
        cout << "Quer continuar? 0 = não ou 1 = sim" << endl;
        cin >> cont;
        
        
   } while(cont);


    return 0;
}
