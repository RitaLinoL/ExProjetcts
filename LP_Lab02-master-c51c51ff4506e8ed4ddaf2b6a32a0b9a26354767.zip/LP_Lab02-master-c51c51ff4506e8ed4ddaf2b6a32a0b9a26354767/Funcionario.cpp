#include "Funcionario.h"
#include <iostream>
#include "Data.h"
#include <ostream>
using namespace std;

//Sobrecarga do operador de inserção para imprimir os dados do funcionário na tela.
std::ostream& operator<<(std::ostream &o, Funcionario const f){
    o << "Nome: " << f.nome << endl << "CPF: " << f.CPF << endl << "Salario: " << f.salario << endl << "Data de admissao: " << f.data_admissao << endl;
    return o;
}


//Sobrecarga do operador de igualdade para comparar funcionarios
bool operator==(Funcionario const f1, Funcionario const f2){
	if ((f1.nome == f2.nome) && (f1.CPF == f2.CPF) && (f1.salario == f2.salario) && (f1.data_admissao == f2.data_admissao))
	{
		return true;
	}
	return false;
}

/*Construtor padrão*/
Funcionario::Funcionario(){
	nome = "Sem Nome";
	CPF = "Sem CPF";
	salario = 0.0;
	data_admissao.setDia(1);
	data_admissao.setMes(1);
	data_admissao.setAno(1900);
	quantFuncionarios++;
} 

/*Construtor Parametrizado*/
Funcionario::Funcionario(string n, string cpf, float s, int d, int m, int a){
	nome = n;
	CPF = cpf;
	salario = s;
	data_admissao.setDia(d);
	data_admissao.setMes(m);
	data_admissao.setAno(a);
	quantFuncionarios++;
}

/*Destrutor*/
Funcionario::~Funcionario(){
	
}

/*Retornam nome, cpf e salario, respectivamente, do funcionário.*/
string Funcionario::getNome(){
	return nome;
}

string Funcionario::getCPF(){
	return CPF;
}

float Funcionario::getSalario(){
	return salario;
}

/*Retorna a data completa de admissao do funcionário*/
Data Funcionario::getData(){
	return data_admissao.getData();	
}

int Funcionario::getQuantFuncionarios(){
	return quantFuncionarios;	
}

void Funcionario::setQuantFuncionariosMenos(){
	quantFuncionarios--;
}

/*Inserem nome, cpf e salario, respectivamente, ao funcionário.*/
void Funcionario::setNome(string n){
	nome = n;
}

void Funcionario::setCPF(string cpf){
	CPF = cpf;
}

void Funcionario::setSalario(float s){
	salario = s;
}

/*Insere dia, mês e ano, respectivamente, como data de admissao.*/
void Funcionario::setData(int d, int m, int a){
	data_admissao.setDia(d);
	data_admissao.setMes(m);
	data_admissao.setAno(a);
}
