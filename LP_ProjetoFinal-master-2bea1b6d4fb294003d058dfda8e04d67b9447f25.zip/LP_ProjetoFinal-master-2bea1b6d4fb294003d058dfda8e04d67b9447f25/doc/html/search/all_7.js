var searchData=
[
  ['leitura_5fescrita_2eh',['leitura_escrita.h',['../leitura__escrita_8h.html',1,'']]]
];
