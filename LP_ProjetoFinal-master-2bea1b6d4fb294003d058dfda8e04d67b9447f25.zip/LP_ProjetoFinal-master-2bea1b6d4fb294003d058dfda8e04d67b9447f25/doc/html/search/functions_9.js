var searchData=
[
  ['tratador',['Tratador',['../class_tratador.html#a4339bfc1e32968609401440338eeba20',1,'Tratador::Tratador()'],['../class_tratador.html#a50547fad79f360e1d2f8d01406c2d484',1,'Tratador::Tratador(int id_p, string nome_p, string funcao_p, string CPF_p, int idade_p, string tipo_sanguineo_p, char fator_RH_p, string especialidade_p, int nivel_seguranca_p)']]]
];
