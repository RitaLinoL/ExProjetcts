var searchData=
[
  ['operator_2d',['operator-',['../class_data.html#ae680eb6602dbb809c67cb4592975fb59',1,'Data']]]
];
