var searchData=
[
  ['tratador_5fh',['TRATADOR_H',['../_tratador_8h.html#a64ad3fa9abab37d521e7d3ec83a321e9',1,'Tratador.h']]]
];
