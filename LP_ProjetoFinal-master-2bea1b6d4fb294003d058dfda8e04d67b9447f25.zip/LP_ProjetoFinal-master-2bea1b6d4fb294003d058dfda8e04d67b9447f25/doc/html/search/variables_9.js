var searchData=
[
  ['tamanho',['tamanho',['../class_animal.html#abdbc6c152134067dfa020a75c30ee638',1,'Animal']]],
  ['tamanho_5fbico_5fcm',['tamanho_bico_cm',['../class_ave.html#a9b0012acaa6ecf1d22b7beebf819c6d3',1,'Ave']]],
  ['tipo_5fsanguineo',['tipo_sanguineo',['../class_funcionario.html#ad7dea9685013fc36869b30fd25cece8f',1,'Funcionario']]],
  ['tipo_5fveneno',['tipo_veneno',['../class_reptil.html#a231d711a23c8b52ffafc135eca7a080c',1,'Reptil']]],
  ['total_5fmudas',['total_mudas',['../class_anfibio.html#a46768866ac5b9ab108219631ea4cbfc6',1,'Anfibio']]]
];
