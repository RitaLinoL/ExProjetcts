var searchData=
[
  ['id',['id',['../class_animal.html#a0e1e797aa638af5d8276bcf12fad9a1f',1,'Animal::id()'],['../class_funcionario.html#a56039516079bcb2181c224c0ffd906ca',1,'Funcionario::id()']]],
  ['id_5ftratador',['id_tratador',['../class_animal.html#ab01d87d427c9962a66fca626ca8c123f',1,'Animal']]],
  ['id_5fveterinario',['id_veterinario',['../class_animal.html#ac694e2d61feb8727da66eb861c79e3b2',1,'Animal']]],
  ['idade',['idade',['../class_funcionario.html#a0eaf37eeefa2701b5e0894b11b691216',1,'Funcionario']]]
];
