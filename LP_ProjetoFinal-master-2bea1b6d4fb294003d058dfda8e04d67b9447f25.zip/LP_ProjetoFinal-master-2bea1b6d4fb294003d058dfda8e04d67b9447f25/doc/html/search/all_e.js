var searchData=
[
  ['tamanho',['tamanho',['../class_animal.html#abdbc6c152134067dfa020a75c30ee638',1,'Animal']]],
  ['tamanho_5fbico_5fcm',['tamanho_bico_cm',['../class_ave.html#a9b0012acaa6ecf1d22b7beebf819c6d3',1,'Ave']]],
  ['tipo_5fsanguineo',['tipo_sanguineo',['../class_funcionario.html#ad7dea9685013fc36869b30fd25cece8f',1,'Funcionario']]],
  ['tipo_5fveneno',['tipo_veneno',['../class_reptil.html#a231d711a23c8b52ffafc135eca7a080c',1,'Reptil']]],
  ['total_5fmudas',['total_mudas',['../class_anfibio.html#a46768866ac5b9ab108219631ea4cbfc6',1,'Anfibio']]],
  ['tratador',['Tratador',['../class_tratador.html',1,'Tratador'],['../class_tratador.html#a4339bfc1e32968609401440338eeba20',1,'Tratador::Tratador()'],['../class_tratador.html#a50547fad79f360e1d2f8d01406c2d484',1,'Tratador::Tratador(int id_p, string nome_p, string funcao_p, string CPF_p, int idade_p, string tipo_sanguineo_p, char fator_RH_p, string especialidade_p, int nivel_seguranca_p)']]],
  ['tratador_2eh',['Tratador.h',['../_tratador_8h.html',1,'']]],
  ['tratador_5fh',['TRATADOR_H',['../_tratador_8h.html#a64ad3fa9abab37d521e7d3ec83a321e9',1,'Tratador.h']]]
];
