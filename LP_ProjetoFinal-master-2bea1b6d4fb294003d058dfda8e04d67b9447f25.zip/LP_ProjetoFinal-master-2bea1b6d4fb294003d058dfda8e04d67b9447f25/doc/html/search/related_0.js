var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../class_animal.html#ad94390f50eaf46d5d702a79e4df6370c',1,'Animal::operator&lt;&lt;()'],['../class_animal.html#ad2e32ffce95f5cc09984dad5dfbc1233',1,'Animal::operator&lt;&lt;()'],['../class_data.html#a47b8e92b7e2d9e05178bb30e6459da7e',1,'Data::operator&lt;&lt;()'],['../class_tratador.html#aae9f415531a004cbc76269575b412193',1,'Tratador::operator&lt;&lt;()'],['../class_tratador.html#a01021ef040422052e07bb8e42613f7c0',1,'Tratador::operator&lt;&lt;()'],['../class_veterinario.html#a42221f438c184f37065b9175e6588138',1,'Veterinario::operator&lt;&lt;()'],['../class_veterinario.html#a8259a12980e88b37e64bef942e6c9b15',1,'Veterinario::operator&lt;&lt;()']]],
  ['operator_3d_3d',['operator==',['../class_data.html#a50342ec164405520ed135b0d2e4d7eaa',1,'Data']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../class_animal.html#aa0100d10d516e736d80dc61b2cca7942',1,'Animal::operator&gt;&gt;()'],['../class_tratador.html#a81c1b6015c55bf2b9e07c61c33072558',1,'Tratador::operator&gt;&gt;()'],['../class_veterinario.html#ad1c66e55443821b10f4c974b1e9ce09c',1,'Veterinario::operator&gt;&gt;()']]]
];
