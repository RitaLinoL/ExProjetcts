var searchData=
[
  ['dieta',['dieta',['../class_animal.html#a1d9c10e256acf2b2dfdf5b57c135af54',1,'Animal']]]
];
