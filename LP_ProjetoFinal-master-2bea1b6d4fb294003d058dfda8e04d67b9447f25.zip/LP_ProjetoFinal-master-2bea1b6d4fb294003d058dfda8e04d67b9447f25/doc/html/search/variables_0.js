var searchData=
[
  ['autorizacao',['autorizacao',['../class_animal_nativo.html#a8f331d76f85240aed4010830d5dcee28',1,'AnimalNativo']]],
  ['autorizacao_5fibama',['autorizacao_ibama',['../class_animal_silvestre.html#ae11c2a65cd77ef8de1104555900ba2c4',1,'AnimalSilvestre']]]
];
