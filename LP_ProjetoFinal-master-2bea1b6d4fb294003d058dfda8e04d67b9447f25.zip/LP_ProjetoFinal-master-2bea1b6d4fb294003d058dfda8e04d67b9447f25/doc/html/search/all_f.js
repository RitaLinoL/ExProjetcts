var searchData=
[
  ['uf_5forigem',['uf_origem',['../class_animal_nativo.html#a4bb5e576998f6c43d019d65bca09da80',1,'AnimalNativo']]],
  ['ultima_5fmuda',['ultima_muda',['../class_anfibio.html#adad7059a5007f3440cfb6b2b643820b7',1,'Anfibio']]]
];
