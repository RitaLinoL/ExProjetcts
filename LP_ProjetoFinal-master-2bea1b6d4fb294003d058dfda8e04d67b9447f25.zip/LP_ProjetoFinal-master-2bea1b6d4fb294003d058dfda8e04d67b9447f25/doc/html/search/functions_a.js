var searchData=
[
  ['veterinario',['Veterinario',['../class_veterinario.html#af8dc5f6f77bf8c70dd94d54766764134',1,'Veterinario::Veterinario()'],['../class_veterinario.html#af21e3615cf183956614c6ebbeae49780',1,'Veterinario::Veterinario(int id_p, string nome_p, string funcao_p, string CPF_p, int idade_p, string tipo_sanguineo_p, char fator_RH_p, string especialidade_p, string CRMV_p)']]]
];
