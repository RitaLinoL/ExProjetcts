var searchData=
[
  ['tratador',['Tratador',['../class_tratador.html',1,'']]]
];
