<h1>PETFERA</h1>

<h3>Projeto Final - Unidade II & III</h3>

<p>Projeto solicitado pelo professor Renan Cipriano Moioli da disciplina de Linguagem de Programação I para análise aprendizado dos assuntos ministrados. </p>


<h2>Autores:</h2>
<h3>José Lúcio da Silva Júnior & Rita de Cássia Lino Lopes</h3>

<h5>Repositório no gitlab com projeto :</h5>  
<a>https://projetos.imd.ufrn.br/RitaLopes/LP_ProjetoFinal</a>

<br/>
<hr>
<br/>

<h4>Estrutura de pastas do projeto</h4>
<pre> LP_ProjetoFinal<br/>
        |<br/>
        bin/  : Diretório com todos os arquivos binários<br/>
        |<br/>
        data/  : Diretório com todos os arquivos de dados (.csv)<br/>
        |<br/>
        doc/  : Diretório com toda a documentação do doxygen<br/>
        |<br/>
        includes/  : Diretório com todos os cabeçalhos (.h)<br/>
        |<br/>
        src/  : Diretório com fontes de produção (.cpp)<br/>
        |<br/>
        Makefile: Arquivo de make<br/>
        |<br/>
        PetFera: Arquivo executável<br/>
        |<br/>
        README.md : Arquivo com detalhes de autoria e organização do projeto
</pre><br/>

<br/>
<br/>

<h4>Instrução de Compilação e Execução</h4>
<p>No terminal - dentro da pasta LP_ProjetoFinal</p>
<pre>$ make clean</pre>
<pre>$ make</pre>
<pre>$ ./PetFera</pre>
<br/>
<h5>Opção com utilização de biblioteca</h5>
<pre>$ g++ -o Petfera_main -std=c++11 src/main.cpp -L. -lpetfera</pre>
<pre>$ ./Petfera_main</pre>
<p>De acordo com as instruções exibitas no terminal digite as opções desejadas</p>

<br/>
<br/>

<h4>Instrução de criação da biblioteca para programa auxiliar de exportação</h4>
<p>No terminal - dentro da pasta LP_ProjetoFinal</p>
<pre>$ g++ -o Petfera_exportar -std=c++11 programaAuxiliar.cpp -L. -lpetfera</pre>
<pre>$ ./Petfera_exportar  -c classe -v veterinario -t tratador arquivo_saida </pre>
<br/><br/><br/>

<h2>OBSERVAÇÃO IMPORTANTE SOBRE A BIBLIOTECA: </h2>
<h3>é possível que ao se executar o programa Petfera_exportar um erro de referência indefinida ocorra. Nesse caso,
execute os seguintes comandos no terminal, dentro da pasta LP_ProjetoFinal: </h3>
<pre>$ sudo find / -name libpetfera.so (Um endereço será retornado)</pre>
<pre>$ echo LD_LIBRARY_PATH</pre>
<pre>$ LD_LIBRARY_PATH=LD_LIBRARY_PATH:/endereço_retornado</pre>
<pre>$ export LD_LIBRARY_PATH</pre>

<h4>Problema resolvido e agora pode-se executar o comando ./Petfera_exportar normalmente</h4>

<pre>$ ./Petfera_exportar  -c classe -v veterinario -t tratador arquivo_saida </pre>






   