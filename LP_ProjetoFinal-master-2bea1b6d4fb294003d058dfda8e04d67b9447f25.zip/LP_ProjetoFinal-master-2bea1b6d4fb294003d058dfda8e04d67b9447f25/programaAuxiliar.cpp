#include <iostream>
#include <vector>
#include <fstream> /*Inclui a biblioteca fstream para manipulação de arquivos*/
#include "includes/Animal.h"
#include "includes/Tratador.h"
#include "includes/Veterinario.h"
#include "includes/leitura_escrita.h"

using namespace std;


int main(int argc, char const *argv[])
{
    string classe = "";
    string veterinario = "";
    string tratador = "";
    string arquivo_saida = "";
    
    if(argc > 3){

        /*transferência para da entrada do terminal para variaveis
        */
        vector <string> entrada;//vetor auxiliar de tratamento de entrada
        for (int i = 1; i < argc; i++)
        {
            entrada.push_back(argv[i]);
        }
        
        //identificação de parametros: classe, veterinario e tratador
        for (unsigned i = 0; i < entrada.size(); i++)
        {
            if(entrada[i][0] == '-'){
                switch (entrada[i][1])
                {
                case 'c':
                    classe = entrada[i+1];
                    break;
                case 'v':
                    veterinario = entrada[i+1];
                break;
                case 't':
                    tratador = entrada[i+1];
                    break;
                default:
                    cout <<"Sem parametros de entradas válidos"<<endl;
                    break;
                }
            }        
        }
        arquivo_saida = argv[argc-1];	
        entrada.clear();		


        /*leitura dos arquivos com animais cadastrados
        */
  
         //BLOCO DE LEITURA DOS ARQUIVOS
        map <int, Tratador>  tratadores;/*!< Todos os tratadores cadastrados */
        map <int, Veterinario>  veterinarios;/*!< Todos os veterinarios cadastrados */
        carregar_funcionarios(&tratadores, &veterinarios);
        map <int, Animal> animais;/*!< Todos os animais cadastrados */
        carregar_animais(&animais);
        map <int, Animal> aux_animais;/*!< Todos os animais cadastrados */


        //BLOCO DE FILTRAGEM DOS CRITÉRIOS
        /*Apaga animais que não são da classe selecionada*/
        if (classe != "")
        {
            for (auto it = (animais).begin(); it != (animais).end(); ++it){
            
                if (it->second.getClasse() != classe)
                {
                    animais.erase(it->first);
                }
            }
        }
       
       

       /*Apaga animais que não possuem tratador selecionado*/
        if (tratador != "")
        {
            for (auto it = (tratadores).begin(); it != (tratadores).end(); ++it){
            
                if (it->second.getNome() == tratador)
                {
                    for (auto ita = (animais).begin(); ita != (animais).end(); ++ita){
                        if (ita ->second.getId_tratador() != it->second.getId())
                        {
                            animais.erase(ita->first);
                        }  
                    }
                }
            }
        }


        
        /*Apaga animais que não possuem veterinario selecionado*/

        if (veterinario != "")
        {
            for (auto it = (veterinarios).begin(); it != (veterinarios).end(); ++it){
            
                if (it->second.getNome() == veterinario)
                {

                    for (auto ita = (animais).begin(); ita != (animais).end(); ++ita){
                        if (ita ->second.getId_veterinario() != it->second.getId())
                        {
                            animais.erase(ita->first);
                        }  
                    }
                }
            }
        }

        //BLOCO DE ESCRITA NO ARQUIVO
        cout << arquivo_saida << endl;
        descarregar_animais(animais, arquivo_saida);
        
    }else{
        cout << "Adicione os parametros para filtragem dos animais" << endl;
    }

    return 0;
}