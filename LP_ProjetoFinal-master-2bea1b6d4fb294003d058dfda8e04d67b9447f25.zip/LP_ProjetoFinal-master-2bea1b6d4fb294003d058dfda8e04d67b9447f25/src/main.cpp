/**
 * @file  main.cpp
 * @brief Descrição do arquivo
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#include <iostream> /*Inclui a biblioteca padrão do C++*/
#include <vector> /*Inclui o TAD vector*/
#include <map> /*Inclui o TAD map*/

#include "../includes/Animal.h" /*Inclui o arquivo Animal.h*/
#include "../includes/Anfibio.h" /*Inclui o arquivo Anfibio.h*/
#include "../includes/Ave.h" /*Inclui o arquivo Ave.h*/
#include "../includes/Mamifero.h" /*Inclui o arquivo Mamifero.h*/
#include "../includes/Reptil.h" /*Inclui o arquivo Reptil.h*/
#include "../includes/Tratador.h" /*Inclui o arquivo Funcionario.h*/
#include "../includes/Veterinario.h"
#include "../includes/leitura_escrita.h" /*Inclui o arquivo leitura_escrita.h*/
#include "../includes/crud.h" /*Inclui o arquivo crud.h*/

///HEADERS
int exibirMenu();
int main(int argc, char const *argv[]);
///END HEADERS

/**
 * @brief Método para exibir o menu de opções do usuário
 * @return operacao(o comando escolhido pelo usuário)
*/

enum classes{
	Amphibia,
	Aves,
	Mammalia,
	Reptilia
};


/**
 * @brief Imprime as opções para o usuário
 * @return valor inteiro correspondente a operação escolhida.
*/

int exibirMenu(){
	int operacao;
	std::cout << "\nDIGITE O NUMERO CORRESPONDENTE A OPCAO DESEJADA\n\n" << std::endl;
	
	std::cout << "     ANIMAIS    " << std::endl;
	std::cout << " 1 - Adicionar" << std::endl;
	std::cout << " 2 - Atualizar" << std::endl;
	std::cout << " 3 - Remover" << std::endl;
	std::cout << " 4 - Consultar por animal" << std::endl;
	std::cout << " 5 - Consultar por classe" << std::endl;
	
	std::cout << "\n\n     FUNCIONARIOS    " << std::endl;
	std::cout << " 6 - Adicionar" << std::endl;
	std::cout << " 7 - Atualizar Veterinario" << std::endl;
	std::cout << " 8 - Atualizar Tratador" << std::endl;
	std::cout << " 9 - Remover Veterinario" << std::endl;
	std::cout << " 10 - Remover Tratador" << std::endl;
	std::cout << " 11 - Consultar Veterinarios" << std::endl;
	std::cout << " 12 - Consultar Tratadores" << std::endl;
	std::cout << "\n 13 - Consultar animais relacionados a determinado Veterinario" << std::endl;
	std::cout << " 14 - Consultar animais relacionados a determinado Tratador" << std::endl;
	
	std::cout << "\n\n\n\n 0 - Sair" << std::endl;
	std::cin >> operacao;
	
	return operacao;	
}

int main(int argc, char const *argv[])
{
	
	//BLOCO DE LEITURA DOS ARQUIVOS
	map <int, Tratador>  tratadores;/*!< Todos os tratadores cadastrados */
	map <int, Veterinario>  veterinarios;/*!< Todos os veterinarios cadastrados */

	carregar_funcionarios(&tratadores, &veterinarios);
	
	map <int, Animal> animais;/*!< Todos os animais cadastrados */
	
	carregar_animais(&animais);	

	
	/*--------------------------------------------------------------------------------------------------------------------------------------------*/
	
	//INTRODUCAO
	
	std::cout << "-----------------------------------------------------------" << "\n PETFERA (o_o)\n" << "-----------------------------------------------------------" << std::endl;  	
  	
  	//MENU PARA O USUARIO
	int operacao = 0 , aux=0;
	string aux2;

  	do{

		operacao = exibirMenu();
		
		switch(operacao)
		{
			case 1:
				system("clear");
				adicionar_animal(&animais);
				break;
			case 2:
				system("clear");
				remover <Animal>(&animais);
				adicionar_animal(&animais);
				break;
			case 3:
				system("clear");
				remover <Animal>(&animais);
				break;

			case 4:
				system("clear");
				cout << "Digite o nome do animal."<<endl;
				cin >> aux2;
				consultar <Animal> (animais , aux2);
				break;

			case 5:
				system("clear");
				aux =0;
				cout << "Qual a classe?" << endl;
				cin >> aux2;
				consultar_classe( animais, aux2);
				break; 

			case 6:
				system("clear");
				adicionar_funcionario(&tratadores, &veterinarios);
				break;

			case 7:
				remover <Veterinario> (&veterinarios);
				adicionar_funcionario(&tratadores, &veterinarios);
				system("clear");
				break;
			case 8:
				remover <Veterinario> (&veterinarios);
				adicionar_funcionario(&tratadores, &veterinarios);
				system("clear");
				break;
			case 9:
				system("clear");
				remover <Veterinario> (&veterinarios);
				break;

			case 10:
				system("clear");
				remover <Tratador> (&tratadores);
				break;

			case 11:
				system("clear");
				cout << "Digite o nome do veterinario."<<endl;
				cin >> aux2;
				consultar <Veterinario> (veterinarios, aux2);
				break;

			case 12:
				system("clear");
				cout << "Digite o nome do tratador."<<endl;
				cin >> aux2;
				consultar <Tratador> (tratadores, aux2);
				break;

			case 13:
				system("clear");
				aux =0;
				consultar <Veterinario> (veterinarios);
				cout << "Digite o id do Veterinário que deseja consultar"<<endl;
				cin >> aux;
				consultar(aux, animais);
				break;

			case 14:
				system("clear");
				aux = 0 ;
				consultar <Tratador> (tratadores);
				cout << "Digite o id do Tratador que deseja consultar"<<endl;
				cin >> aux;
				consultar(aux, animais);
				break;

			default:
				
				break;
		}
		
  	} while(operacao !=0);
  	std::cout << "\nGood bye, my friend!" << std::endl;	
			
	/*--------------------------------------------------------------------------------------------------------------------------------------------*/			
			
	//BLOCO DE ESCRITA NOS ARQUIVOS
	
	descarregar_funcionarios(tratadores, veterinarios);
	descarregar_animais(animais, "data/animal.csv");
	
	return 0;
}
