/**
 * @file  leitura_escrita.cpp
 * @brief Arquivo com as funções de leitura e escrita em streams 
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versao: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/
#include "../includes/leitura_escrita.h" /*Inclui o arquivo leitura_escrita.h*/

using namespace std; /*Usa o espaço de nomes padrão*/

/**
 * @brief Faz o carregamento dos dados em stream dos tratadores e veterinarios
 * @param[*tratadores] ponteiro para mapa de tratadores
 * @param[*veterinarios] ponteiro para mapa de veterinarios
 * @return valores booleanos para indicar se a operação deu certo ou não
*/
bool carregar_funcionarios(map <int,Tratador> * tratadores, map <int,Veterinario> * veterinarios){
	try
	{
		ifstream arquivo;/*!< Arquivo a ser lido */
		arquivo.open("data/funcionario.csv");/*!< Abertura de arquivo*/
		string linha;
		string quebralinha;
		vector <string> campo;
		if(arquivo.is_open()){
			while(getline(arquivo, linha)){
				campo.clear();
				istringstream iss(linha);
				while(getline(iss, quebralinha, ';')){
					campo.push_back(quebralinha);
				}				
				
				if(campo[1] =="Tratador" || campo[8]==""){
					Tratador tratador;
					tratador.setId(stoi(campo[0]));
					tratador.setNome(campo[2]);
					tratador.setCPF(campo[3]);
					tratador.setIdade(stoi(campo[4]));
					tratador.setTipo_sanguineo(campo[5]);
					tratador.setFator_RH(campo[6][0]);
					tratador.setEspecialidade(campo[7]);
					tratador.setNivel_seguranca(stoi(campo[9]));
					try{					
						(*tratadores).insert(pair<int, Tratador>(tratador.getId(), tratador) );
					}catch (int e)
					{
						cout << "Erro ao armazenar o tratador acessado no arquivo" << '\n';
						return 0;
					}
				}else if(campo[1] =="Veterinario" ||campo[9]=="")
				{	
					Veterinario veterinario;
					veterinario.setId(stoi(campo[0]));
					veterinario.setNome(campo[2]);
					veterinario.setCPF(campo[3]);
					veterinario.setIdade(stoi(campo[4]));
					veterinario.setTipo_sanguineo(campo[5]);
					veterinario.setFator_RH(campo[6][0]);
					veterinario.setEspecialidade(campo[7]);
					veterinario.setCRMV(campo[8]);

					try{					
						(*veterinarios).insert(pair<int, Veterinario>(veterinario.getId(), veterinario) );
					}catch (int e)
					{
						cout << "Erro ao armazenar o veterinario acessado no arquivo" << '\n';
						return 0;
					}

				}		
				cout <<endl;	
			}			
		}else{
			cout << "Error: Arquivo impossível de ser lido";
		}
		arquivo.close();
		return 1;
	}catch (int e)
	{
		cout << "Uma exceção ocorreu: " << e << '\n';
		return 0;
	}

}

/**
 * @brief Faz o carregamento dos dados em stream dos animais
 * @param[*animais] ponteiro para mapa de animais
 * @return valores booleanos para indicar se a operação deu certo ou não
*/
bool carregar_animais(map <int, Animal> * animais){

	try
	{
		ifstream arquivo;/*!< Arquivo a ser lido */
		arquivo.open("data/animal.csv");/*!< Abertura de arquivo*/
		
		string linha;
		string quebralinha;
		vector <string> campo;
		if(arquivo.is_open()){
			while(getline(arquivo, linha)){
				campo.clear();
				istringstream iss(linha);
				while(getline(iss, quebralinha, ';')){
					campo.push_back(quebralinha);
				}	

				Animal animal;
				animal.setId(stoi(campo[0]));
				animal.setClasse(campo[1]);
				animal.setNome(campo[2]);
				animal.setNome_cientifico(campo[3]);
				animal.setSexo(campo[4][0]);
				animal.setTamanho(stoi(campo[5]));
				animal.setDieta(campo[6]);
				animal.setId_veterinario(stoi(campo[7]));
				animal.setId_tratador(stoi(campo[8]));
				animal.setNome_batismo(campo[9]);
												
				try{					
					(*animais).insert(pair<int, Animal>(animal.getId(), animal) );
				}catch (int e)
				{
					cout << "Erro ao armazenar o Animal acessado no arquivo" << '\n';
					return 0;
				}
				
			}			
		}else{
			cout << "Error: Arquivo animal.csv impossível de ser lido";
		}
		arquivo.close();
		return 1;
	}catch (int e)
	{
		cout << "Uma exceção ocorreu: " << e << '\n';
		return 0;
	}
}

/**
 * @brief Faz a descarga dos dados em stream dos funcionarios
 * @param[*tratadores] ponteiro para mapa de tratadores
 * @param[*veterinarios] ponteiro para mapa de veterinarios
 * @return valores booleanos para indicar se a operaçãoo deu certo ou não
*/
bool descarregar_funcionarios(map <int, Tratador> tratadores, map <int, Veterinario> veterinarios){
	try
	{
		ofstream arquivo;
		arquivo.open("data/funcionario.csv");
		if(arquivo.is_open()){
			try{
				map<int, Tratador>::iterator itt;
				for (itt = (tratadores).begin(); itt != (tratadores).end(); ++itt)
					arquivo << itt->second;
				
				
				map<int, Veterinario>::iterator itv;
				for (itv = (veterinarios).begin(); itv != (veterinarios).end(); ++itv)
					arquivo << itv->second;
				
				
			}catch (int e){
				cout <<e<<endl;
			}
		}else{
			cout << "Error: Arquivo não permitiu escrita.";
		}
		arquivo.close();
		return 1;
	}catch (int e)
	{
		cout << "Uma exceção ocorreu: " << e << '\n';
		return 0;
	}
}

/**
 * @brief Faz a descarga dos dados em stream dos animais
 * @param[*animais] ponteiro para mapa de animais
 * @return valores booleanos para indicar se a operação deu certo ou não
*/
bool descarregar_animais(map <int, Animal> animais, string arquivo_escrita){
	try
	{
		ofstream arquivo;
		arquivo.open(arquivo_escrita);
		if(arquivo.is_open()){
			try{
				map<int, Animal>::iterator ita;
				for (ita = (animais).begin(); ita != (animais).end(); ++ita)
					arquivo << ita->second;
				
			}catch (int e){
				cout <<e<<endl;
			}
		}else{
			cout << "Error: Arquivo com animais não permitiu escrita.";
		}
		arquivo.close();
		return 1;
	}catch (int e)
	{
		cout << "Uma exceção ocorreu: " << e << '\n';
		return 0;
	}
}