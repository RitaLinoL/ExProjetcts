/**
 * @file  Funcionario.cpp
 * @brief Arquivo com as implementações das classes Funcionario, Veterinario e Tratador
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#include "../includes/Funcionario.h" /*Inclui o arquivo Funcionario.h*/
#include <iostream> /*Inclui a biblioteca padrão do C++*/


using std::cout;
using std::cin;

/**
 * @brief Construtor padrão da classe funcionario
 * @return
*/
Funcionario::Funcionario(){
	id =(-1);
	nome = " ";
	funcao = " ";
	CPF = " ";
	idade = (-1);
	tipo_sanguineo= " ";
	fator_RH= ' ';
	especialidade = " ";	
}

/**
 * @brief Construtor parametrizado simplista da classe funcionario
 * @return
*/
Funcionario::Funcionario(string funcao_p){
	id = (-1);
	nome = " ";
	funcao = funcao_p;
	CPF = " ";
	idade = (-1);
	tipo_sanguineo= " ";
	fator_RH= ' ';
	especialidade = " ";	
}

/**
 * @brief Construtor parametrizado completo da classe funcionario
 * @return
*/
Funcionario::Funcionario(int id_p, string nome_p, string funcao_p, string CPF_p, int idade_p, string tipo_sanguineo_p, char fator_RH_p, string especialidade_p):
	id(id_p), nome(nome_p), funcao(funcao_p), CPF(CPF_p), idade(idade_p), tipo_sanguineo(tipo_sanguineo_p), fator_RH(fator_RH_p), especialidade(especialidade_p) {}

/**
 * @brief Destrutor da classe funcionario
 * @return
*/
Funcionario::~Funcionario(){
	
}	

/**
 * @brief Método para alterar o ID do funcionario
 * @return
*/
void Funcionario::setId(int id_p){
	id = id_p;
}
/**
 * @brief Método para alterar o nome do funcionario
 * @return
*/
void Funcionario::setNome(string nome_p){
	nome = nome_p;
}
/**
 * @brief Método para alterar o CPF do funcionario
 * @return
*/
void Funcionario::setCPF(string CPF_p){
	CPF = CPF_p;
}
/**
 * @brief Método para alterar a idade do funcionario
 * @return
*/
void Funcionario::setIdade(int idade_p){
	idade = idade_p;
}
/**
 * @brief Método para alterar o tipo sanguineo do funcionario
 * @return
*/
void Funcionario::setTipo_sanguineo(string tipo_sanguineo_p){
	tipo_sanguineo = tipo_sanguineo_p;
}
/**
 * @brief Método para alterar o fator RH do funcionario
 * @return
*/
void Funcionario::setFator_RH(char fator_RH_p){
	fator_RH = fator_RH_p;
}
/**
 * @brief Método para alterar a especialidade do funcionario
 * @return
*/
void Funcionario::setEspecialidade(string especialidade_p){
	especialidade = especialidade_p;
}

/**
 * @brief Método para acessar o ID do funcionario
 * @return atributo ID
*/
int Funcionario::getId(){
	return id;
}
/**
 * @brief Método para acessar o nome do funcionario
 * @return atributo nome
*/
string Funcionario::getNome(){
	return nome;
}
/**
 * @brief Método para acessar o CPF do funcionario
 * @return atributo CPF
*/
string Funcionario::getCPF(){
	return CPF;
}
/**
 * @brief Método para acessar a idade do funcionario
 * @return atributo idade
*/
int Funcionario::getIdade(){
	return idade;
}
/**
 * @brief Método para acessar o tipo sanguineo do funcionario
 * @return atributo tipo_sanguineo
*/
string Funcionario::getTipo_sanguineo(){
	return tipo_sanguineo;
}
/**
 * @brief Método para acessar o fator RH do funcionario
 * @return atributo fator_RH 
*/
char Funcionario::getFator_RH(){
	return fator_RH;
}
/**
 * @brief Método para acessar a especialidade do funcionario
 * @return atributo especialidade
*/
string Funcionario::getEspecialidade(){
	return especialidade;
}


