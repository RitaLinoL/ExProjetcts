/**
 * @file  Tratador.cpp
 * @brief Arquivo com as implementações das classes Funcionario, Veterinario e Tratador
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#include "../includes/Tratador.h" /*Inclui o arquivo Funcionario.h*/
#include <iostream> /*Inclui a biblioteca padrão do C++*/


using std::cout;
using std::cin;

/**
 * @brief Construtor padrão de tratador
 * @return 
*/
Tratador::Tratador(){
	nivel_seguranca = (-1);
}

/**
 * @brief Construtor parametrizado de tratador
 * @return 
*/
Tratador::Tratador(int id_p, string nome_p, string funcao_p, string CPF_p, int idade_p, string tipo_sanguineo_p, char fator_RH_p, string especialidade_p,  int nivel_seguranca_p):
	Funcionario(id_p, nome_p, funcao_p, CPF_p, idade_p, tipo_sanguineo_p, fator_RH_p, especialidade_p), nivel_seguranca(nivel_seguranca_p) {}


/**
 * @brief Destrutor de tratador
 * @return 
*/
Tratador::~Tratador(){

}

/**
 * @brief Método para alterar o nivel de segurança
 * @return 
*/
void Tratador::setNivel_seguranca(int nivel_seguranca_p){	
	nivel_seguranca = nivel_seguranca_p;
}

/**
 * @brief Método para acessar o nivel de segurança
 * @return 
*/
int Tratador::getNivel_seguranca(){
	return nivel_seguranca;
}
/**
 * @brief Método para acessar a função
 * @return 
*/
string Tratador::getFuncao(){
	return "Tratador";
}

/**
 * @brief Sobrecarga do operador de inserção (<<)
 * @param[o] variável para a extração dos dados
 * @param[t] variável tratador da qual os dados serão inseridos
 * @return valores do cout(o)
*/
std::ostream& operator<<(std::ostream &o, Tratador const t){
    o << t.id << ";" << t.nome << ";" << t.CPF << ";" << t.idade << ";" << t.tipo_sanguineo << ";" << t.fator_RH << ";" << t.especialidade << ";" << t.nivel_seguranca << endl;
    return o;
}
/**
 * @brief Sobrecarga do operador de extração (>>)
 * @param[i] variável para a extração dos dados
 * @param[t] variável tratador da qual os dados serão inseridos
 * @return valores do cin(i)
*/
std::istream& operator>>(std::istream &i, Tratador &t){
	cin.ignore();
	cout << "informe os dados do tratador: " << endl;
	
	cout << "Nome: ";
	getline(i, t.nome);

	cout << "CPF: ";
	i >> t.CPF;

	cout << "Idade: ";
	i >> t.idade;

	cout << "Tipo Sanguineo (A, B, AB, O): ";
	i >> t.tipo_sanguineo;

	cout << "Fator RH (+, -): ";
	i >> t.fator_RH;

	cin.ignore();
	cout << "Especialidade: ";
	getline(i, t.especialidade);

	cout << "Nivel de segurança (0, 1 ou 2): ";
	i >> t.nivel_seguranca;

	return i;
}

/**
 * @brief Sobrecarga do operador de inserçao em stream (<<)
 * @param[o] variável para a inserçao de dados
 * @param[a] variável tratadorpara inserir os dados
 * @return valores do cout(o)
*/
std::ofstream& operator<<(std::ofstream &o, Tratador const t){
    o << t.id <<";"<<"Tratador"<< ";" << t.nome << ";" << t.CPF << ";" << t.idade << ";" << t.tipo_sanguineo << ";" << t.fator_RH << ";" << t.especialidade << ";" <<";"<< t.nivel_seguranca<<";"<<"\n";
    return o;
}