/**
 * @file  crud.cpp
 * @brief Arquivo com a implementação de funções para Criar, Remover, Atualizar e Deletar objetos. Além disso, realiza consultas.
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior, $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#include "../includes/crud.h" /*Inclui a o arquivo crud.h*/
#include <map> /*Inclui o TAD map*/

using namespace std; 

/**
 * @brief Método de adição de funcionario
 * faz uso de "adicionar_veterinario" e "adicionar_tratador"
 * @return 
*/
void adicionar_funcionario(map <int, Tratador> * tratadores, map <int, Veterinario> * veterinarios){
	int tipo_funcionario;

	cout << "Escolha a função: " << endl;
	cout << "1 - Veterinário" << endl;
	cout << "2 - Tratador" << endl;

	cout << "digite sua opção: ";
	cin >> tipo_funcionario;

	switch(tipo_funcionario){
		case 1:
			//adicionar_veterinario(map <int, Veterinario> *veterinarios);
			{
				Veterinario veterinario;
				veterinario.setId(gerarId<Veterinario>(*veterinarios));
				cin >> veterinario;						
				veterinarios->insert(pair<int, Veterinario> (veterinario.getId(), veterinario));
			}
			break;

		case 2:
			//adicionar_tratador(map <int, Tratador> *tratadores);
			{
				Tratador tratador;
				tratador.setId(gerarId<Tratador>(*tratadores));

				cin >> tratador;					
				tratadores->insert(pair<int, Tratador> (tratador.getId(), tratador));
			}
			break;
	};
	
}

/**
 * @brief Método de adição de veterinario
 * @return
*/
/*void adicionar_veterinario(map <int, Veterinario> *veterinarios){
	Veterinario veterinario;

	cin >> veterinario;

}*/

/**
 * @brief Método de adição de tratador
 * @return
*/
/*void adicionar_tratador(map <int, Tratador> *tratadores){
	Tratador tratador;

	cin >> tratador;
					
	tratadores.insert(pair<int, Tratador> (tratador.getId(), tratador));
	
}*/
/**
 * @brief Método de adição de animal
 * @return
*/
void adicionar_animal(map <int, Animal> *animais){
	int opcao_animal;
	cout << "Qual o tipo de animal a ser adicionado?" << endl;
	cout << "1 - Mamifero" << endl;
	cout << "2 - Anfibio" << endl;
	cout << "3 - Reptil" << endl;
	cout << "4 - Ave" << endl;

	cout << "Sua escolha: ";
	cin >> opcao_animal;

	switch(opcao_animal){
		case 1:
			//adicionar_mamifero(map <int, Animal> *animais);
			{
				Mamifero mamifero;
				mamifero.setId(gerarId<Animal>(*animais));
				cin >> mamifero;
				animais->insert(pair<int, Mamifero> (mamifero.getId(), mamifero));
			}
			break;
		case 2: 
			//adicionar_anfibio(map <int, Animal> *animais);
			{
				Anfibio anfibio;
				anfibio.setId(gerarId<Animal>(*animais));
				cin >> anfibio;
				animais->insert(pair<int, Anfibio> (anfibio.getId(), anfibio));				
			}
			break;
		case 3:
			//adicionar_reptil(map <int, Animal> *animais);
			{
				Reptil reptil;
				reptil.setId(gerarId<Animal>(*animais));
				cin >> reptil;
				animais->insert(pair<int, Reptil> (reptil.getId(), reptil));
			}
			break;
		case 4:
			//adicionar_ave(map <int, Animal> *animais);
			{
				Ave ave;
				ave.setId(gerarId<Animal>(*animais));
				cin >> ave;
				animais->insert(pair<int, Ave> (ave.getId(), ave));
			}
			break;
	};
}
/**
 * @brief Método de adição de mamifero
 * @return
*/
/*void adicionar_mamifero(map <int, Animal> *animais){
	Mamifero mamifero;
	cin >> mamifero;
	animais.insert(pair<int, Mamifero> (mamifero.getId(), mamifero));

	int tipo_natureza;
	cout << "Qual a naturezado animal?" << endl;
	cout << "1 - Nativo" << endl;
	cout << "2 - Exotico" << endl;

	cout << "Sua escolha: ";
	cin >>  tipo_natureza;

	switch(tipo_natureza){
		case 1:
			MamiferoNativo mamifero_nativo;
			cin >> mamifero_nativo;
			(*animais).insert(pair<int, MamiferoNativo> (mamifero_nativo.getId(), mamifero_nativo));
			break;
		case 2:
			MamiferoExotico mamifero_exotico;
			cin >> mamifero_exotico;
			(*animais).insert(pair<int, MamiferoExotico> (mamifero_exotico.getId(), mamifero_exotico));
			break;
	}
}*/
/**
 * @brief Método de adição de anfibio
 * @return
*/
/*void adicionar_anfibio(map <int, Animal> *animais){
	Anfibio anfibio;
	cin >> anfibio;
	animais.insert(pair<int, Anfibio> (anfibio.getId(), anfibio));

	int tipo_natureza;
	cout << "Qual a naturezado animal?" << endl;
	cout << "1 - Nativo" << endl;
	cout << "2 - Exotico" << endl;

	cout << "Sua escolha: ";
	cin >>  tipo_natureza;

	switch(tipo_natureza){
		case 1:
			AnfibioNativo anfibio_nativo;
			cin >> anfibio_nativo;
			(*animais).insert(pair<int, AnfibioNativo> (anfibio_nativo.getId(), anfibio_nativo));
			break;
		case 2:
			AnfibioExotico anfibio_exotico;
			cin >> anfibio_exotico;
			(*animais).insert(pair<int, AnfibioExotico> (anfibio_exotico.getId(), anfibio_exotico));
			break;
	}
}*/
/**
 * @brief Método de adição de reptil
 * @return
*/
/*void adicionar_reptil(map <int, Animal> *animais){
	Reptil reptil;
	cin >> reptil;
	animais.insert(pair<int, Reptil> (reptil.getId(), reptil));

	int tipo_natureza;
	cout << "Qual a naturezado animal?" << endl;
	cout << "1 - Nativo" << endl;
	cout << "2 - Exotico" << endl;

	cout << "Sua escolha: ";
	cin >>  tipo_natureza;

	switch(tipo_natureza){
		case 1:
			ReptilNativo reptil_nativo;
			cin >> reptil_nativo;
			(*animais).insert(pair<int, ReptilNativo> (reptil_nativo.getId(), reptil_nativo));
			break;
		case 2:
			ReptilExotico reptil_exotico;
			cin >> reptil_exotico;
			(*animais).insert(pair<int, ReptilExotico> (reptil_exotico.getId(), reptil_exotico));
			break;
	}
}*/
/**
 * @brief Método de adição de ave
 * @return
*/
/*void adicionar_ave(map <int, Animal> *animais){
	Ave ave;
	cin >> ave;
	animais.insert(pair<int, Ave> (ave.getId(), ave));

	int tipo_natureza;
	cout << "Qual a naturezado animal?" << endl;
	cout << "1 - Nativo" << endl;
	cout << "2 - Exotico" << endl;

	cout << "Sua escolha: ";
	cin >>  tipo_natureza;

	switch(tipo_natureza){
		case 1:
			AveNativo ave_nativo;
			cin >> ave_nativo;
			(*animais).insert(pair<int, AveNativo> (ave_nativo.getId(), ave_nativo));
			break;
		case 2:
			AveExotico ave_exotico;
			cin << ave_exotico;
			(*animais).insert(pair<int, AveExotico> (ave_exotico.getId(), ave_exotico));
			break;
	}
}*/

/**
* @brief Sobrecarga de método consultar para consultar animais relacionados a determinado funcionário
* @return void
*/
void consultar(int id_funcionario, map <int, Animal> animais){
	for (auto it = (animais).begin(); it != (animais).end(); ++it){
		if(it -> second.getId_veterinario() == id_funcionario || it -> second.getId_tratador() == id_funcionario ){
			cout << it->second << endl;
		}
	}
		
}

void consultar_classe(map <int, Animal> animais, string classe){
	for (auto it = (animais).begin(); it != (animais).end(); ++it){
		if(it -> second.getClasse() == classe){
			cout << it -> second <<endl;
		}
	}
}




