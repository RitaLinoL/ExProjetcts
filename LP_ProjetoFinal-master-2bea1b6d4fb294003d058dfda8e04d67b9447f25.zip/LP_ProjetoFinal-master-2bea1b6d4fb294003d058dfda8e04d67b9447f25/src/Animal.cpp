/**
 * @file  Animal.cpp
 * @brief Arquivo com as implementações das classes de Animal, AnimalSilvestre, AnimalNativo e AnimalExotico
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#include "../includes/Animal.h" /*inclui o arquivo Animal.h*/

/**
 * @brief Construtor padrão da classe Animal
 * @return
*/
Animal::Animal(){
	id = (-1);
	classe = " ";
	nome = " " ;
	nome_cientifico = " ";
	sexo = ' ';
	tamanho = 0.00;
	dieta = " ";
	id_veterinario = (-1);
	id_tratador = (-1);
	nome_batismo = " ";
}

/**
 * @brief Construtor parametrizado da classe Animal
 * @return
*/
Animal::Animal(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p):
	id(id_p), classe(classe_p), nome(nome_p), nome_cientifico(nome_cientifico_p), sexo(sexo_p), tamanho(tamanho_p), dieta(dieta_p), id_veterinario(id_veterinario_p), id_tratador(id_tratador_p), nome_batismo(nome_batismo_p) {}

//Destrutor da classe Animal
Animal::~Animal(){

}

/**
 * @brief Método para alterar o atributo id
 * @return
*/
void Animal::setId(int id_p){
	id = id_p;
}
/**
 * @brief Método para alterar o atributo classe
 * @return
*/
void Animal::setClasse(string classe_p){
	classe = classe_p;
}
/**
 * @brief Método para alterar o atributo nome
 * @return
*/
void Animal::setNome(string nome_p){
	nome = nome_p;
}
/**
 * @brief Método para alterar o atributo nome_cientifico
 * @return
*/
void Animal::setNome_cientifico(string nome_cientifico_p){
	nome_cientifico = nome_cientifico_p;
}
/**
 * @brief Método para alterar o atributo sexo
 * @return
*/
void Animal::setSexo(char sexo_p){
	sexo = sexo_p;
}
/**
 * @brief Método para alterar o atributo tamanho
 * @return
*/
void Animal::setTamanho(double tamanho_p){
	tamanho = tamanho_p;
}
/**
 * @brief Método para alterar o atributo dieta
 * @return
*/
void Animal::setDieta(string dieta_p){
	dieta = dieta_p;
}
/**
 * @brief Método para alterar o atributo id_veterinario
 * @return
*/
void Animal::setId_veterinario(int id_veterinario_p){
	id_veterinario = id_veterinario_p;
}
/**
 * @brief Método para alterar o atributo id_tratador
 * @return
*/
void Animal::setId_tratador(int id_tratador_p){
	id_tratador = id_tratador_p;
}
/**
 * @brief Método para alterar o atributo nome_batismo
 * @return
*/
void Animal::setNome_batismo(string nome_batismo_p){
	nome_batismo = nome_batismo_p;
}

/**
 * @brief Método para acessar o atributo id
 * @return id
*/
int Animal::getId(){
	return id;
}
/**
 * @brief Método para acessar o atributo nome
 * @return nome
*/

string Animal::getNome(){
	return nome;
}
/**
 * @brief Método para acessar o atributo nome_cientifico
 * @return nome_cientifico
*/
string Animal::getNome_cientifico(){
	return nome_cientifico;
}
/**
 * @brief Método para acessar o atributo sexo
 * @return sexo
*/
char Animal::getSexo(){
	return sexo;
}
/**
 * @brief Método para acessar o atributo tamanho
 * @return tamanho
*/
double Animal::getTamanho(){
	return tamanho;
}
/**
 * @brief Método para acessar o atributo dieta
 * @return dieta
*/
string Animal::getDieta(){
	return dieta;
}
/**
 * @brief Método para acessar o atributo id_veterinario
 * @return id_veterinario
*/
int Animal::getId_veterinario(){
	return id_veterinario;
}

/**
 * @brief Método para acessar o atributo classe
 * @return classe
*/
string Animal::getClasse(){
	return classe;
}

/**
 * @brief Método para acessar o atributo id_tratador
 * @return id_tratador
*/
int Animal::getId_tratador(){
	return id_tratador;
}
/**
 * @brief Método para acessar o atributo nome_batismo
 * @return nome_batismo
*/
string Animal::getNome_batismo(){
	return nome_batismo;
}
/**
 * @brief Sobrecarga do operador de inserçao (<<)
 * @param[o] variável para a inserçao de dados
 * @param[a] variável animal para inserir os dados
 * @return valores do cout(o)
*/
std::ostream& operator<<(ostream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo <<";"<< endl;
	return o;
}
/**
 * @brief Sobrecarga do operador de inserçao em streams(<<)
 * @param[o] variável para a inserçao de dados em stream
 * @param[a] variável animal para inserir os dados
 * @return valores do cout(o)
*/
std::ofstream& operator<<(std::ofstream &o, Animal const a){
    o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo <<";"<< endl;
    return o;
}
/**
 * @brief Sobrecarga do operador de extraçao (>>)
 * @param[i] variável para a extraçao de dados
 * @param[a] variável animal para armazenar os dados
 * @return valores do cin(i)
*/
std::istream& operator>>(istream &i, Animal &a){
	cin.ignore();
	cout << "Insira as informações do animal: " << endl;
	cout << "Nome: ";
	getline(i, a.nome);

	cout << "nome cientifico: ";
	getline(i, a.nome_cientifico);


	cout << "sexo: ";
	i >> a.sexo;

	cout << "tamanho: ";
	i >> a.tamanho;

	cin.ignore();
	cout << "dieta: ";
	//i >> a.dieta;
	getline(i, a.dieta);

	cout << "id do veterinario: ";
	i >> a.id_veterinario;

	cout << "id do tratador: ";
	i >> a.id_tratador;

	cin.ignore();
	cout << "nome de batismo: ";
	getline(i, a.nome_batismo);

	return i;
}

/**
 * @brief Construtor padrão da classe AnimalSilvestre
 * @return
*/
AnimalSilvestre::AnimalSilvestre(){
	autorizacao_ibama = " ";
}

/**
 * @brief Construtor parametrizado da classe AnimalSilvestre
 * @return
*/
AnimalSilvestre::AnimalSilvestre(string aut_ibama_p):
	autorizacao_ibama(aut_ibama_p) {}


//Destrutor da classe AnimalSilvestre
AnimalSilvestre::~AnimalSilvestre(){

}

/**
 * @brief Método para alterar o atributo autorizacao_ibama
 * @return
*/
void AnimalSilvestre::setAutorizacao_ibama(string aut_ibama_p){
	autorizacao_ibama = aut_ibama_p;
}
/**
 * @brief Método para acessar o atributo autorizacao_ibama
 * @return autorizacao_ibama
*/
string AnimalSilvestre::getAutorizacao_ibama(){
	return autorizacao_ibama;
}


/**
 * @brief Construtor padrão da classe AnimalExotico
 * @return
*/
AnimalExotico::AnimalExotico(){
	pais_origem = " ";
}

/**
 * @brief Construtor parametrizado da classe AnimalExotico
 * @return
*/
AnimalExotico::AnimalExotico(string aut_ibama_p, string pais_origem_p):
	AnimalSilvestre(aut_ibama_p), pais_origem(pais_origem_p) {}

//Destrutor da classe AnimalExotico
AnimalExotico::~AnimalExotico(){

}	

/**
 * @brief Método para alterar o atributo pais_origem
 * @return
*/
void AnimalExotico::setPais_origem(string pais_origem_p){
	pais_origem = pais_origem_p;
}

/**
 * @brief Método para acessar o atributo pais_origem
 * @return pais_origem
*/
string AnimalExotico::getPais_origem(){
	return pais_origem;
}


/**
 * @brief Construtor padrão da classe AnimalNativo
 * @return
*/
AnimalNativo::AnimalNativo(){
	uf_origem = " ";
	autorizacao = " ";
}

/**
 * @brief Construtor parametrizado da classe AnimalNativo
 * @return
*/
AnimalNativo::AnimalNativo(string aut_ibama_p, string uf_origem_p, string autorizacao_p):
	AnimalSilvestre(aut_ibama_p), uf_origem(uf_origem_p), autorizacao(autorizacao_p) {}

//Destrutor da classe AnimalNativo
AnimalNativo::~AnimalNativo(){

}	

/**
 * @brief Método para alterar o atributo uf_origem
 * @return
*/
void AnimalNativo::setUF_origem(string uf_origem_p){
	uf_origem = uf_origem_p;
}
/**
 * @brief Método para alterar o atributo autorizacao
 * @return
*/
void AnimalNativo::setAutorizacao(string autorizacao_p){
	autorizacao = autorizacao_p;
}

/**
 * @brief Método para acessar o atributo uf_origem
 * @return uf_origem
*/
string AnimalNativo::getUF_origem(){
	return uf_origem;
}
/**
 * @brief Método para acessar o atributo autorizacao
 * @return autorizacao
*/
string AnimalNativo::getAutorizacao(){
	return autorizacao;
}
