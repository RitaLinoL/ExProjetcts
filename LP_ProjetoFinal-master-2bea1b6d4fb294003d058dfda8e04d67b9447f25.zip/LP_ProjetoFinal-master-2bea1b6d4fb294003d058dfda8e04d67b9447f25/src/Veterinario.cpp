#include "../includes/Veterinario.h" /*Inclui o arquivo Funcionario.h*/
#include <iostream> /*Inclui a biblioteca padrão do C++*/


using std::cout;
using std::cin;

/**
 * @brief Construtor padrão de veterinario
 * @return
*/
Veterinario::Veterinario(){
	CRMV = " ";
}

/**
 * @brief Construtor parametrizado de veterinario
 * @return
*/
Veterinario::Veterinario(int id_p, string nome_p, string funcao_p, string CPF_p, int idade_p, string tipo_sanguineo_p, char fator_RH_p, string especialidade_p,  string CRMV_p):
	Funcionario(id_p, nome_p, funcao_p, CPF_p, idade_p, tipo_sanguineo_p, fator_RH_p, especialidade_p), CRMV(CRMV_p) {}
/**
 * @brief Destrutor de veterinario
 * @return
*/
Veterinario::~Veterinario(){
	
}

/**
 * @brief Método para alterar a CRMV do veterinário
 * @return 
*/
void Veterinario::setCRMV(string CRMV_p){
	CRMV = CRMV_p;
}

/**
 * @brief Método para acessar a CRMV do veterinário
 * @return 
*/
string Veterinario::getCRMV(){
	return CRMV;
}
/**
 * @brief Método para acessar a funcao 
 * @return 
*/
string Veterinario::getFuncao(){
	return "Veterinario";
}

/**
 * @brief Sobrecarga do operador de inserção (<<)
 * @param[o] variável para a inserção dos dados
 * @param[v] variável veterinario da qual os dados serão inseridos
 * @return valores do cout(o)
*/
std::ostream& operator<<(std::ostream &o, Veterinario const v){
    o << v.id << ";" << v.nome << ";" << v.CPF << ";" << v.idade << ";" << v.tipo_sanguineo << ";" << v.fator_RH << ";" << v.especialidade << ";" << v.CRMV << endl;
    return o;
}
/**
 * @brief Sobrecarga do operador de extração (>>)
 * @param[i] variável para a extração dos dados
 * @param[v] variável veterinario da qual os dados serão inseridos
 * @return valores do cin(i)
*/

std::istream& operator>>(std::istream &i, Veterinario &v){
	cin.ignore();
	cout << "informe os dados do veterinario: " << endl;
	cout << "Nome: ";
	getline(i, v.nome);

	cout << "CPF: ";
	i >> v.CPF;

	cout << "Idade: ";
	i >> v.idade;

	cout << "Tipo Snaguineo (A, B, AB, O): ";
	i >> v.tipo_sanguineo;

	cout << "Fator RH (+, -): ";
	i >> v.fator_RH;

	cin.ignore();
	cout << "Especialidade: ";
	getline(i, v.especialidade);

	//cin.ignore();
	cout << "Código CRMV: ";
	getline(i, v.CRMV);

	return i;
}

/**
 * @brief Sobrecarga do operador de inserçao em stream (<<)
 * @param[o] variável para a inserçao de dados
 * @param[v] variável veterinario para inserir os dados
 * @return valores do cout(o)
*/

std::ofstream& operator<<(std::ofstream &o, Veterinario const v){
    o << v.id <<";"<<"Veterinario"<< ";" << v.nome << ";" << v.CPF << ";" << v.idade << ";" << v.tipo_sanguineo << ";" << v.fator_RH << ";" << v.especialidade << ";" << v.CRMV << ";"<<";"<<"\n";
    return o;
}