/**
 * @file  Anfibio.cpp
 * @brief Arquivo com as implementações das classes de Anfibio, AnfibioExotico e AnfibioNativo
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#include "../includes/Anfibio.h" /*Inclui o arquivo Anfibio.h*/

/**
 * @brief Construtor padrao da classe Anfibio
 * @return
*/
Anfibio::Anfibio(){
	total_mudas = 0;
	ultima_muda.setDia(1);
	ultima_muda.setMes(1);
	ultima_muda.setAno(1900);
	classe = "Amphibia";
}

/**
 * @brief Construtor parametrizado da classe Anfibio
 * @return
*/
Anfibio::Anfibio(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, int total_mudas_p, int dia_p, int mes_p, int ano_p):
	Animal(id_p, classe_p, nome_p, nome_cientifico_p, sexo_p, tamanho_p, dieta_p, id_veterinario_p, id_tratador_p, nome_batismo_p), total_mudas(total_mudas_p), ultima_muda(dia_p, mes_p, ano_p) {}

//Destrutor da classe Anfibio
Anfibio::~Anfibio(){

}

/**
 * @brief Método para acessar o atributo classe
 * @return classe
*/
string Anfibio::getClasse(){
	return "Amphibia";
}
/**
 * @brief Método para alterar o atributo total_mudas
 * @return
*/
void Anfibio::setTotal_mudas(int total_mudas_p){
	total_mudas = total_mudas_p;
}
/**
 * @brief Método para alterar o atributo ultima_muda
 * @return
*/
void Anfibio::setUltima_muda(int dia_p, int mes_p, int ano_p){
	ultima_muda.setDia(dia_p);
	ultima_muda.setMes(mes_p);
	ultima_muda.setAno(ano_p);
}

/**
 * @brief Método para acessar o atributo total_mudas
 * @return total_mudas
*/
int Anfibio::getTotal_mudas(){
	return total_mudas;
}
/**
 * @brief Método para acessar o atributo ultima_muda
 * @return ultima_muda
*/
Data Anfibio::getUltima_muda(){
	return Data(ultima_muda.getDia(), ultima_muda.getMes(), ultima_muda.getAno());
}

/**
 * @brief Construtor padrao da classe AnfibioExotico
 * @return 
*/
AnfibioExotico::AnfibioExotico(){

}

/**
 * @brief Construtor parametrizado da classe AnfibioExotico
 * @return 
*/
AnfibioExotico::AnfibioExotico(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, int total_mudas_p, int dia_p, int mes_p, int ano_p, string aut_ibama_p, string pais_origem_p):
Anfibio(id_p, classe_p, nome_p, nome_cientifico_p, sexo_p, tamanho_p, dieta_p, id_veterinario_p, id_tratador_p, nome_batismo_p, total_mudas_p, dia_p, mes_p, ano_p), AnimalExotico(aut_ibama_p, pais_origem_p) {}

//Destrutor da classe Anfibio Exótico
AnfibioExotico::~AnfibioExotico(){

}
/**
 * @brief Sobrecarga do operador de extraçao (>>)
 * @param[i] variável para a extraçao de dados
 * @param[a] variável animal para armazenar os dados
 * @return valores do cin(i)
*/
/*std::istream& operator>>(istream &i, Animal &a){
	cin.ignore();
	cout << "Insira as informações do animal: " << endl;
	cout << "Nome: ";
	getline(i, a.nome);

	cout << "id: ";
	i >> a.id;

	cout << "nome cientifico: ";
	i >> a.nome_cientifico;

	cout << "sexo: ";
	i >> a.sexo;

	cout << "tamanho: ";
	i >> a.tamanho;

	cout << "dieta: ";
	i >> a.dieta;

	cout << "id do veterinario: ";
	i >> a.id_veterinario;

	cout << "id do tratador: ";
	i >> a.id_tratador;
	
	cin.ignore();
	cout << "nome de batismo: ";
	getline(i, a.nome_batismo);

	//cout << "autorizacao do ibama: ";
	//getline(i, a.aut_ibama);

	//cout << "país de origem: ";
	//getline(i, a.pais_origem);

	return i;
}*/

/**
 * @brief Sobrecarga do operador de inserção (<<)
 * @param[o] variável para a inserção dos dados
 * @param[a] variável animal da qual os dados serão inseridos
 * @return valores do cout(o)
*/
/*std::ostream& operator<<(ostream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo << endl;
	return o;
}*/
/**
 * @brief Sobrecarga do operador de inserção em stream(<<)
 * @param[o] variável para a inserção dos dados em stream
 * @param[a] variável animal da qual os dados serão inseridos
 * @return valores do cout(o)
*/
/*std::ofstream& operator<<(ofstream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo << endl;
	return o;
}*/

/**
 * @brief Construtor padrao da classe AnfibioNativo
 * @return 
*/
AnfibioNativo::AnfibioNativo(){

}

/**
 * @brief Construtor parametrizado da classe AnfibioNativo
 * @return 
*/
AnfibioNativo::AnfibioNativo(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, int total_mudas_p, int dia_p, int mes_p, int ano_p, string aut_ibama_p, string uf_origem_p, string autorizacao_p):
	Anfibio(id_p, classe_p, nome_p, nome_cientifico_p, sexo_p, tamanho_p, dieta_p, id_veterinario_p, id_tratador_p, nome_batismo_p, total_mudas_p, dia_p, mes_p, ano_p), AnimalNativo(aut_ibama_p, uf_origem_p, autorizacao_p) {}


//Destrutor da classe AnfibioNativo
AnfibioNativo::~AnfibioNativo(){
	
}
/**
 * @brief Sobrecarga do operador de extraçao (>>)
 * @param[i] variável para a extraçao de dados
 * @param[a] variável animal para armazenar os dados
 * @return valores do cin(i)
*/
/*std::istream& operator>>(istream &i, Animal &a){
	cin.ignore();
	cout << "Insira as informações do animal: " << endl;
	cout << "Nome: ";
	getline(i, a.nome);

	cout << "id: ";
	i >> a.id;

	cout << "nome cientifico: ";
	i >> a.nome_cientifico;

	cout << "sexo: ";
	i >> a.sexo;

	cout << "tamanho: ";
	i >> a.tamanho;

	cout << "dieta: ";
	i >> a.dieta;

	cout << "id do veterinario: ";
	i >> a.id_veterinario;

	cout << "id do tratador: ";
	i >> a.id_tratador;
	
	cin.ignore();
	cout << "nome de batismo: ";
	getline(i, a.nome_batismo);

	cout << "autorizacao do ibama: ";
	getline(i, a.aut_ibama);

	cout << "uf de origem: ";
	getline(i, a.uf_origem);

	cout << "autorizacao: ";
	getline(i, a.autorizacao);

	return i;
}*/
/**
 * @brief Sobrecarga do operador de inserção (<<)
 * @param[o] variável para a inserção dos dados
 * @param[a] variável animal da qual os dados serão inseridos
 * @return valores do cout(o)
*/
/*std::ostream& operator<<(ostream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo << endl;
	return o;
}*/
/**
 * @brief Sobrecarga do operador de inserção em stream(<<)
 * @param[o] variável para a inserção dos dados em stream
 * @param[a] variável animal da qual os dados serão inseridos
 * @return valores do cout(o)
*/
/*std::ofstream& operator<<(ofstream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo << endl;
	return o;
}*/