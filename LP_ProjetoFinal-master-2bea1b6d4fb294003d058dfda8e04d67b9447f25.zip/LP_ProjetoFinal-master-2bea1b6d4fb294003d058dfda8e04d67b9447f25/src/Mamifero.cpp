/**
 * @file  Mamifero.cpp
 * @brief Arquivo com as implementações das classes de Mamifero, Mamifero Nativo e Mamifero Exótico
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#include "../includes/Mamifero.h" /*Inclui o arquivo Mamifero.h*/

/**
 * @brief Construtor padrao da classe Mamifero
 * @return
*/
Mamifero::Mamifero(){
	cor_pelo = " ";
	classe = "Mammalia";
}

/**
 * @brief Construtor parametrizado da classe Mamifero
 * @return
*/
Mamifero::Mamifero(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, string cor_pelo_p):
	Animal(id_p, classe_p, nome_p, nome_cientifico_p, sexo_p, tamanho_p, dieta_p, id_veterinario_p, id_tratador_p, nome_batismo_p), cor_pelo(cor_pelo_p) {}

//Destrutor da classe Mamifero
Mamifero::~Mamifero(){

}

/**
 * @brief Método para alterar o atributo cor_pelo
 * @return
*/
void Mamifero::setCor_pelo(string cor_pelo_p){
	cor_pelo = cor_pelo_p;
}

/**
 * @brief Método para acessar o atributo cor_pelo
 * @return cor_pelo
*/
string Mamifero::getCor_pelo(){
	return cor_pelo;
}
/**
 * @brief Método para acessar o atributo classe
 * @return classe
*/
string Mamifero::getClasse(){
	return "Mammalia";
}

/**
 * @brief Construtor padrao da classe Mamifero Exótico
 * @return
*/
MamiferoExotico::MamiferoExotico(){

}

/**
 * @brief Construtor parametrizado da classe Mamifero Exótico
 * @return
*/
MamiferoExotico::MamiferoExotico(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, string cor_pelo_p, string aut_ibama_p, string pais_origem_p):
	Mamifero(id_p, classe_p, nome_p, nome_cientifico_p, sexo_p, tamanho_p, dieta_p, id_veterinario_p, id_tratador_p, nome_batismo_p, cor_pelo_p), AnimalExotico(aut_ibama_p, pais_origem_p) {}

//Destrutor da classe Mamifero Exótico
MamiferoExotico::~MamiferoExotico(){

}
/**
 * @brief Sobrecarga do operador de extraçao (>>)
 * @param[i] variável para a extraçao de dados
 * @param[a] variável animal para armazenar os dados
 * @return valores do cin(i)
*/
/*std::istream& operator>>(istream &i, Animal &a){
		cin.ignore();
	cout << "Insira as informações do animal: " << endl;
	cout << "Nome: ";
	getline(i, a.nome);

	cout << "id: ";
	i >> a.id;

	cout << "nome cientifico: ";
	i >> a.nome_cientifico;

	cout << "sexo: ";
	i >> a.sexo;

	cout << "tamanho: ";
	i >> a.tamanho;

	cout << "dieta: ";
	i >> a.dieta;

	cout << "id do veterinario: ";
	i >> a.id_veterinario;

	cout << "id do tratador: ";
	i >> a.id_tratador;
	
	//cout << "cor do pelo: ";
	//i >> a.cor_pelo;

	cin.ignore();
	cout << "nome de batismo: ";
	getline(i, a.nome_batismo);

	//cout << "autorizacao do ibama: ";
	//getline(i, a.aut_ibama);

	//cout << "país de origem: ";
	//getline(i, a.pais_origem);

	return i;
}*/
/**
 * @brief Sobrecarga do operador de inserção (<<)
 * @param[o] variável para a inserção dos dados
 * @param[a] variável animal da qual os dados serão inseridos
 * @return valores do cout(o)
*/
/*std::ostream& operator<<(ostream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo << endl;
	return o;
}*/
/**
 * @brief Sobrecarga do operador de inserção em stream(<<)
 * @param[o] variável para a inserção dos dados em stream
 * @param[a] variável animal da qual os dados serão inseridos
 * @return valores do cout(o)
*/
/*std::ofstream& operator<<(ofstream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo << endl;
	return o;
}*/

/**
 * @brief Construtor padrao da classe Mamifero Nativo
 * @return
*/
MamiferoNativo::MamiferoNativo(){

}

/**
 * @brief Construtor parametrizado da classe Mamifero Nativo
 * @return
*/
MamiferoNativo::MamiferoNativo(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, string cor_pelo_p, string aut_ibama_p, string uf_origem_p, string autorizacao_p):
	Mamifero(id_p, classe_p, nome_p, nome_cientifico_p, sexo_p, tamanho_p, dieta_p, id_veterinario_p, id_tratador_p, nome_batismo_p, cor_pelo_p), AnimalNativo(aut_ibama_p, uf_origem_p, autorizacao_p) {}

//Destrutor da classe Mamifero Nativo
MamiferoNativo::~MamiferoNativo(){

}
/**
 * @brief Sobrecarga do operador de extraçao (>>)
 * @param[i] variável para a extraçao de dados
 * @param[a] variável animal para armazenar os dados
 * @return valores do cin(i)
*/
/*std::istream& operator>>(istream &i, Animal &a){
		cin.ignore();
	cout << "Insira as informações do animal: " << endl;
	cout << "Nome: ";
	getline(i, a.nome);

	cout << "id: ";
	i >> a.id;

	cout << "nome cientifico: ";
	i >> a.nome_cientifico;

	cout << "sexo: ";
	i >> a.sexo;

	cout << "tamanho: ";
	i >> a.tamanho;

	cout << "dieta: ";
	i >> a.dieta;

	cout << "id do veterinario: ";
	i >> a.id_veterinario;

	cout << "id do tratador: ";
	i >> a.id_tratador;
	
	cout << "cor do pelo: ";
	i >> a.cor_pelo;

	cin.ignore();
	cout << "nome de batismo: ";
	getline(i, a.nome_batismo);

	cout << "autorizacao do ibama: ";
	getline(i, a.aut_ibama);

	cout << "uf de origem: ";
	getline(i, a.uf_origem);

	cout << "autorizacao: ";
	getline(i, a.autorizacao);

	return i;
}*/
/**
 * @brief Sobrecarga do operador de inserção (<<)
 * @param[o] variável para a inserção dos dados
 * @param[a] variável animal da qual os dados serão inseridos
 * @return valores do cout(o)
*/
/*std::ostream& operator<<(ostream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo << endl;
	return o;
}*/
/**
 * @brief Sobrecarga do operador de inserção em stream(<<)
 * @param[o] variável para a inserção dos dados em stream
 * @param[a] variável animal da qual os dados serão inseridos
 * @return valores do cout(o)
*/
/*std::ofstream& operator<<(ofstream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo << endl;
	return o; 
}*/
