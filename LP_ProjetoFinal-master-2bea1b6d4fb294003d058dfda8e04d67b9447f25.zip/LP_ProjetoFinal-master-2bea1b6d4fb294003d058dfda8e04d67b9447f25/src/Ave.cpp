/**
 * @file  Ave.cpp
 * @brief Arquivo com as implementações das classes de Ave, Ave Nativa e Ave Exótica
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#include "../includes/Ave.h" /*Inclui o arquivo Ave.h*/

/**
 * @brief Construtor padrao da classe Ave
 * @return
*/
Ave::Ave(){
	tamanho_bico_cm = 0.00;
	envergadura_asas = 0.00;
	classe = "Aves";
}

/**
 * @brief Construtor parametrizado da classe Ave
 * @return
*/
Ave::Ave(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, double tamanho_bico_cm_p, double envergadura_asas_p):
	Animal(id_p, classe_p, nome_p, nome_cientifico_p, sexo_p, tamanho_p, dieta_p, id_veterinario_p, id_tratador_p, nome_batismo_p), tamanho_bico_cm(tamanho_bico_cm_p), envergadura_asas(envergadura_asas_p) {}


//Destrutor da classe Ave
Ave::~Ave(){

}

/**
 * @brief Método para alterar o atributo tamanho_bico_cm
 * @return
*/
void Ave::setTamanho_bico_cm(double tamanho_bico_cm_p){
	tamanho_bico_cm = tamanho_bico_cm_p;
}
/**
 * @brief Método para alterar o atributo envergadura_asas
 * @return
*/
void Ave::setEnvergadura_asas(double envergadura_asas_p){
	envergadura_asas = envergadura_asas_p;
}

/**
 * @brief Método para acessar o atributo tamanho_bico_cm
 * @return tamanho_bico_cm
*/
double Ave::getTamanho_bico_cm(){
	return tamanho_bico_cm;
}
/**
 * @brief Método para alterar o atributo envergadura_asas
 * @return envergadura_asas
*/
double Ave::getEnvergadura_asas(){
	return envergadura_asas;
}
/**
 * @brief Método para alterar o atributo classe
 * @return classe
*/
string Ave::getClasse(){
	return "Aves";
}

/**
 * @brief Construtor padrao da classe Ave Exótica
 * @return
*/
AveExotico::AveExotico(){

}

/**
 * @brief Construtor parametrizado da classe Ave Exótica
 * @return
*/
AveExotico::AveExotico(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, double tamanho_bico_cm_p, double envergadura_asas_p, string aut_ibama_p, string pais_origem_p):
	Ave(id_p, classe_p, nome_p, nome_cientifico_p, sexo_p, tamanho_p, dieta_p, id_veterinario_p, id_tratador_p, nome_batismo_p, tamanho_bico_cm_p, envergadura_asas_p), AnimalExotico(aut_ibama_p, pais_origem_p) {}

//Destrutor da classe Ave Exótica
AveExotico::~AveExotico(){
	
}	
/**
 * @brief Sobrecarga do operador de extraçao (>>)
 * @param[i] variável para a extraçao de dados
 * @param[a] variável animal para armazenar os dados
 * @return valores do cin(i)
*/
/*std::istream& operator>>(istream &i, Animal &a){
	cin.ignore();
	cout << "Insira as informações do animal: " << endl;
	cout << "Nome: ";
	getline(i, a.nome);

	cout << "id: ";
	i >> a.id;

	cout << "nome cientifico: ";
	i >> a.nome_cientifico;

	cout << "sexo: ";
	i >> a.sexo;

	cout << "tamanho: ";
	i >> a.tamanho;

	cout << "dieta: ";
	i >> a.dieta;

	cout << "id do veterinario: ";
	i >> a.id_veterinario;

	cout << "id do tratador: ";
	i >> a.id_tratador;
	
	//cout << "tamanho do bico: ";
	//i >> a.tamanho_bico_cm;

	//cout << "envergadura das asas: ";
	//i >> a.envergadura_asas;

	cin.ignore();
	cout << "nome de batismo: ";
	getline(i, a.nome_batismo);

	//cout << "autorizacao do ibama: ";
	//getline(i, a.aut_ibama);

	//cout << "país de origem: ";
	//getline(i, a.pais_origem);

	return i;
}*/
/**
 * @brief Sobrecarga do operador de inserção (<<)
 * @param[o] variável para a inserção dos dados
 * @param[a] variável animal da qual os dados serão inseridos
 * @return valores do cout(o)
*/
/*std::ostream& operator<<(ostream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo << endl;
	return o;
}*/
/**
 * @brief Sobrecarga do operador de inserção em stream(<<)
 * @param[o] variável para a inserção dos dados em stream
 * @param[a] variável animal da qual os dados serão inseridos
 * @return valores do cout(o)
*/
/*std::ofstream& operator<<(ofstream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo << endl;
	return o;
}*/
/**
 * @brief Construtor padrao da classe Ave Nativa
 * @return
*/
AveNativo::AveNativo(){

}

/**
 * @brief Construtor parametrizado da classe Ave Nativa
 * @return
*/
AveNativo::AveNativo(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, double tamanho_bico_cm_p, double envergadura_asas_p, string aut_ibama_p, string uf_origem_p, string autorizacao_p):
	Ave(id_p, classe_p, nome_p, nome_cientifico_p, sexo_p, tamanho_p, dieta_p, id_veterinario_p, id_tratador_p, nome_batismo_p, tamanho_bico_cm_p, envergadura_asas_p), AnimalNativo(aut_ibama_p, uf_origem_p, autorizacao_p) {}

//Destrutor da classe Ave Nativa
AveNativo::~AveNativo(){
	
}	
/**
 * @brief Sobrecarga do operador de extraçao (>>)
 * @param[i] variável para a extraçao de dados
 * @param[a] variável animal para armazenar os dados
 * @return valores do cin(i)
*/
/*std::istream& operator>>(istream &i, Animal &a){
	cin.ignore();
	cout << "Insira as informações do animal: " << endl;
	cout << "Nome: ";
	getline(i, a.nome);

	cout << "id: ";
	i >> a.id;

	cout << "nome cientifico: ";
	i >> a.nome_cientifico;

	cout << "sexo: ";
	i >> a.sexo;

	cout << "tamanho: ";
	i >> a.tamanho;

	cout << "dieta: ";
	i >> a.dieta;

	cout << "id do veterinario: ";
	i >> a.id_veterinario;

	cout << "id do tratador: ";
	i >> a.id_tratador;
	
	cout << "tamanho do bico: ";
	i >> a.tamanho_bico_cm;

	cout << "envergadura das asas: ";
	i >> a.envergadura_asas;

	cin.ignore();
	cout << "nome de batismo: ";
	getline(i, a.nome_batismo);

	cout << "autorizacao do ibama: ";
	getline(i, a.aut_ibama);

	cout << "uf de origem: ";
	getline(i, a.uf_origem);

	cout << "autorizacao: ";
	getline(i, a.autorizacao);

	return i;
}*/
/**
 * @brief Sobrecarga do operador de inserção (<<)
 * @param[o] variável para a inserção dos dados
 * @param[a] variável animal da qual os dados serão inseridos
 * @return valores do cout(o)
*/
/*std::ostream& operator<<(ostream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo << endl;
	return o;
}*/
/**
 * @brief Sobrecarga do operador de inserção em stream(<<)
 * @param[o] variável para a inserção dos dados em stream
 * @param[a] variável animal da qual os dados serão inseridos
 * @return valores do cout(o)
*/
/*std::ofstream& operator<<(ofstream &o, Animal const a){
	o << a.id << ";" << a.classe << ";" << a.nome << ";" << a.nome_cientifico << ";" << a.sexo << ";" << a.tamanho << ";" << a.dieta << ";" << a.id_veterinario << ";" << a.id_tratador << ";" << a.nome_batismo << endl;
	return o; 
}*/