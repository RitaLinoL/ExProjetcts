/**
 * @file  Mamifero.h
 * @brief Arquivo com as implementações das classes de Mamifero, Mamifero Nativo e Mamifero Exótico
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/


#include "Animal.h" /*Inclui o arquivo Animal.h*/

using namespace std; /*Usa o espaço de nomes padrao*/

#ifndef MAMIFERO_H /*Verifica se a variável MAMIFERO_H não foi definida*/
#define MAMIFERO_H /*Define a variável MAMIFERO_H*/

class Mamifero : public Animal{
	protected:
		string cor_pelo;
	public:
		Mamifero(); /*Construtor padrao da classe*/
		Mamifero(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, string cor_pelo_p); /*Construtor parametrizado da classe*/
		~Mamifero(); /*Destrutor da classe*/
		/**
		 * @brief Método para alterar o atributo cor_pelo
		 * @return
		*/
		void setCor_pelo(string cor_pelo_p);
		/**
		 * @brief Método para acessar o atributo cor_pelo
		 * @return cor_pelo
		*/
		string getCor_pelo();
		/**
		 * @brief Método para acessar o atributo classe
		 * @return classe
		*/
		string getClasse();
};

#endif


#ifndef MAMIFERO_EXOTICO_H /*Verifica se a variável MAMIFERO_EXOTICO_H não foi definida*/
#define MAMIFERO_EXOTICO_H /*Define a variável MAMIFERO_EXOTICO_H*/

class MamiferoExotico : public Mamifero, AnimalExotico{
	public:
		MamiferoExotico(); /*Construtor padrao da classe*/
		MamiferoExotico(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, string cor_pelo_p, string aut_ibama_p, string pais_origem_p); /*Construtor parametrizado da classe*/
		~MamiferoExotico(); /*Destrutor da classe*/
		/**
 		 * @brief Sobrecarga do operador de extraçao (>>)
 		 * @param[i] variável para a extraçao de dados
 		 * @param[a] variável animal para armazenar os dados
 		 * @return valores do cin(i)
		*/
		//friend istream& operator>>(istream &i, Animal &a);
		/**
		 * @brief Sobrecarga do operador de inserção (<<)
		 * @param[o] variável para a inserção dos dados
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ostream& operator<<(ostream &o, Animal const a);
		/**
		 * @brief Sobrecarga do operador de inserção em stream(<<)
		 * @param[o] variável para a inserção dos dados em stream
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ofstream& operator<<(ofstream &o, Animal const a);
};

#endif


#ifndef MAMIFERO_NATIVO_H /*Verifica se a variável MAMIFERO_NATIVO_H não foi definida*/
#define MAMIFERO_NATIVO_H /*Define a variável MAMIFERO_NATIVO_H*/

class MamiferoNativo : public Mamifero, AnimalNativo{
	public:
		MamiferoNativo(); /*Construtor padrao da classe*/
		MamiferoNativo(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, string cor_pelo_p, string aut_ibama_p, string uf_origem_p, string autorizacao_p); /*Construtor parametrizado da classe*/
		~MamiferoNativo(); /*Destrutor da classe*/
		/**
 		 * @brief Sobrecarga do operador de extraçao (>>)
 		 * @param[i] variável para a extraçao de dados
 		 * @param[a] variável animal para armazenar os dados
 		 * @return valores do cin(i)
		*/
		//friend istream& operator>>(istream &i, Animal &a);
		/**
		 * @brief Sobrecarga do operador de inserção (<<)
		 * @param[o] variável para a inserção dos dados
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ostream& operator<<(ostream &o, Animal const a);
		/**
		 * @brief Sobrecarga do operador de inserção em stream(<<)
		 * @param[o] variável para a inserção dos dados em stream
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ofstream& operator<<(ofstream &o, Animal const a);
};

#endif