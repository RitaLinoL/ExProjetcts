/**
 * @file  leitura_escrita.h
 * @brief Arquivo com as funções de leitura e escrita em streams 
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#ifndef LEITURA_ESCRITA_H
#define LEITURA_ESCRITA_H

#include <fstream> /*Inclui a biblioteca fstream para manipulação de arquivos*/
#include <iostream> /*Inclui a biblioteca padrão do C++*/
#include <sstream> /*Inclui a biblioteca sstream para manipulação de strings em streams*/
#include <map> /*Inclui o TAD map*/
#include <vector> /*Inclui o TAD vector*/
#include <string> /*Inclui a biblioteca string*/
#include "Tratador.h" /*Inclui o arquivo Funcionario.h*/
#include "Veterinario.h" /*Inclui o arquivo Funcionario.h*/

#include "Animal.h" /*Inclui o arquivo Animal.h*/

/**
 * @brief Faz o carregamento dos dados em stream dos tratadores e veterinarios
 * @param[*tratadores] ponteiro para mapa de tratadores
 * @param[*veterinarios] ponteiro para mapa de veterinarios
 * @return valores booleanos para indicar se a operação deu certo ou não
*/
bool carregar_funcionarios(map <int, Tratador> * tratadores, map <int, Veterinario> * veterinarios);
/**
 * @brief Faz o carregamento dos dados em stream dos animais
 * @param[*animais] ponteiro para mapa de animais
 * @return valores booleanos para indicar se a operação deu certo ou não
*/
bool carregar_animais(map <int, Animal> * animais);
/**
 * @brief Faz a descarga dos dados em stream dos funcionarios
 * @param[*tratadores] ponteiro para mapa de tratadores
 * @param[*veterinarios] ponteiro para mapa de veterinarios
 * @return valores booleanos para indicar se a operação deu certo ou não
*/
bool descarregar_funcionarios(map <int, Tratador> tratadores, map <int, Veterinario> veterinarios);
/**
 * @brief Faz a descarga dos dados em stream dos animais
 * @param[animais] ponteiro para mapa de animais
 * @param[arquivo_escrita] localização/nome do arquivo de escrita
 * @return valores booleanos para indicar se a operação deu certo ou não
*/
bool descarregar_animais(map <int, Animal> animais, string arquivo_escrita);

#endif
