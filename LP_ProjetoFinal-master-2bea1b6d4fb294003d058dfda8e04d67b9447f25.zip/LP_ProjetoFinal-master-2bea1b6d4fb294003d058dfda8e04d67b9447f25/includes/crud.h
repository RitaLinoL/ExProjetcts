/**
 * @file  crud.h
 * @brief Arquivo com a implementação de funções para Criar, Remover, Atualizar e Deletar objetos. Além disso, realiza consultas.
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior, $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#ifndef CRUD_H /*Verifica se a variável CRUD_H não foi definida*/
#define CRUD_H /*Define a variável CRUD_H*/

#include <iostream> /*Inclui a biblioteca padrão do C++*/
#include "Animal.h"
#include "Mamifero.h"
#include "Reptil.h"
#include "Ave.h"
#include "Anfibio.h"
#include "Tratador.h"
#include "Veterinario.h"

#include <map>
#include <vector> /*Inclui o TAD vector*/

using namespace std;
/**
* @brief Método de para gerar ids de acordo com a quantidade de elementos no map
*param[map <int, T>  ts] Dicionario que pode receber qualquer dicionario de objeto com chave inteira
* @return void
*/
template < typename T>
int gerarId(map <int, T>  ts){
	int id = -1;
	int quant = ts.size();
	do{
		srand(time(NULL));
		id = 2 + rand()%quant;
		for (auto it = (ts).begin(); it != (ts).end(); ++it){
			if(id == it -> first){
				id = -4;
			}
		}
	}while(id < 0);
	return id;
}


/**
* @brief Método de adição de funcionario
* @return void
*/
void adicionar_funcionario(map <int,Tratador> * tratadores, map <int,Veterinario> * veterinarios); 

/**
* @brief Método de adição de animal
*@param[map <int, Animal> *animais] dicionário com chave inteira e valor Animal
* @return
*/
void adicionar_animal(map <int, Animal> *animais);
/**
* @brief Método de consultar animais, veterinairos e tratadores usando templates
* @return void
*/
template < typename T>
void consultar(map<int, T> ts){
	for (auto it = (ts).begin(); it != (ts).end(); ++it)
		cout << it->first << " - " << it->second << endl;	
} 

template < typename T>
void consultar(map<int, T> ts, string nome){
	for (auto it = (ts).begin(); it != (ts).end(); ++it){
		if(it->second.getNome() == nome){
			cout << it -> second <<endl;
		}
		
	}
		
}

/**
* @brief Sobrecarga de método consultar para consultar animais relacionados a determinado funcionário
* @return void
*/
void consultar(int id_funcionario, map <int, Animal> animais);

/**
* @brief Sobrecarga de método consultar para consultar animais por classe
* @return void
*/
void consultar_classe(map <int, Animal> animais, string classe);


/**
* @brief Método de deletar animais e funcionarios
* @return void
*/
template < typename T>
void remover(map <int, T> * ts){
    int id =-1;
	do{
		cout << "Digite o id : "<<endl;
		for (auto it = (*ts).begin(); it != (*ts).end(); ++it){
			cout <<"Id: "<<it -> first<<" - Nome: "<<it->second.getNome() << endl;
		}
		cin >> id;
	}while(!(*ts).erase(id));	
}



#endif