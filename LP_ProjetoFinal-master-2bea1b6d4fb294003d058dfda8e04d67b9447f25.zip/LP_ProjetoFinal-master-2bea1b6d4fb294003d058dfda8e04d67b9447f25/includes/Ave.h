/**
 * @file  Ave.h
 * @brief Arquivo com as implementações das classes de Ave, Ave Nativa e Ave Exótica
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#include "Animal.h" /*Inclui o arquivo Animal.h*/

using namespace std; /*Usa o espaço de nomes padrao*/

#ifndef AVE_H /*Verifica se a variável AVE_H não foi definida*/
#define AVE_H /*Define a variável AVE_H*/

class Ave : public Animal{
	protected:
		double tamanho_bico_cm;
		double envergadura_asas;
	public:
		Ave(); /*Construtor padrao da classe*/
		Ave(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, double tamanho_bico_cm_p, double envergadura_asas_p); /*Construtor parametrizado da classe*/
		~Ave(); /*Destrutor da classe*/
		/**
		 * @brief Método para alterar o atributo tamanho_bico_cm
		 * @return
		*/
		void setTamanho_bico_cm(double tamanho_bico_cm_p);
		/**
		 * @brief Método para alterar o atributo envergadura_asas
		 * @return
		*/
		void setEnvergadura_asas(double envergadura_asas_p);
		/**
		 * @brief Método para acessar o atributo tamanho_bico_cm
		 * @return tamanho_bico_cm
		*/
		double getTamanho_bico_cm();
		/**
		 * @brief Método para acessar o atributo envergadura_asas
		 * @return envergadura_asas
		*/
		double getEnvergadura_asas();
		/**
		 * @brief Método para acessar o atributo classe
		 * @return classe
		*/
		string getClasse();
};

#endif


#ifndef AVE_EXOTICO_H /*Verifica se a variável AVE_EXOTICO_H não foi definida*/
#define AVE_EXOTICO_H /*Define a variável AVE_EXOTICO_H*/

class AveExotico : public Ave, AnimalExotico{
	public:
		AveExotico(); /*Construtor padrao da classe*/
		AveExotico(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, double tamanho_bico_cm_p, double envergadura_asas_p, string aut_ibama_p, string pais_origem_p); /*Construtor parametrizado da classe*/
		~AveExotico(); /*Destrutor da classe*/
		/**
 		 * @brief Sobrecarga do operador de extraçao (>>)
 		 * @param[i] variável para a extraçao de dados
 		 * @param[a] variável animal para armazenar os dados
 		 * @return valores do cin(i)
		*/
		//friend istream& operator>>(istream &i, Animal &a);
		/**
		 * @brief Sobrecarga do operador de inserção (<<)
		 * @param[o] variável para a inserção dos dados
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ostream& operator<<(ostream &o, Animal const a);
		/**
		 * @brief Sobrecarga do operador de inserção em stream(<<)
		 * @param[o] variável para a inserção dos dados em stream
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ofstream& operator<<(ofstream &o, Animal const a);

};

#endif

#ifndef AVE_NATIVO_H /*Verifica se a variável AVE_NATIVO_H não foi definida*/
#define AVE_NATIVO_H /*Define a variável AVE_NATIVO_H*/

class AveNativo : public Ave, AnimalNativo{
	public:
		AveNativo(); /*Construtor padrao da classe*/
		AveNativo(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, double tamanho_bico_cm_p, double envergadura_asas_p, string aut_ibama_p, string uf_origem_p, string autorizacao_p); /*Construtor parametrizado da classe*/
		~AveNativo(); /*Destrutor da classe*/
		/**
 		 * @brief Sobrecarga do operador de extraçao (>>)
 		 * @param[i] variável para a extraçao de dados
 		 * @param[a] variável animal para armazenar os dados
 		 * @return valores do cin(i)
		*/
		//friend istream& operator>>(istream &i, Animal &a);
		/**
		 * @brief Sobrecarga do operador de inserção (<<)
		 * @param[o] variável para a inserção dos dados
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ostream& operator<<(ostream &o, Animal const a);
		/**
		 * @brief Sobrecarga do operador de inserção em stream(<<)
		 * @param[o] variável para a inserção dos dados em stream
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ofstream& operator<<(ofstream &o, Animal const a);
};

#endif