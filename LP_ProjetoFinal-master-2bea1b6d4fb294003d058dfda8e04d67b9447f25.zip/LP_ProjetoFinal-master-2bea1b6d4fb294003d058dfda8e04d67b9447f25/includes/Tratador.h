
#ifndef TRATADOR_H /*Verifica se a variável TRATADOR_H não foi definida*/
#define TRATADOR_H /*Define a variável TRATADOR_H*/

using namespace std;

#include "Funcionario.h"
#include <cstdlib>
#include <string> /*Inclui o arquivo string*/
#include <iostream> /*Inclui a biblioteca padrão do C++*/
#include <istream> /*Inclui a biblioteca padrão do C++*/
#include <ostream> /*Inclui a biblioteca ostream*/
#include <fstream> /*Inclui a biblioteca fstream*/


class Tratador : public Funcionario
{
	private:
		int nivel_seguranca;
	public:
		Tratador(); /*Construtor padrao da classe*/
		Tratador(int id_p, string nome_p, string funcao_p, string CPF_p, int idade_p, string tipo_sanguineo_p, char fator_RH_p, string especialidade_p, int nivel_seguranca_p); /*Construtor parametrizado da classe*/
		~Tratador(); /*Destrutor da classe*/
		/**
		 * @brief Método para alterar o atributo nivel_seguranca
		 * @return 
		*/
		void setNivel_seguranca(int nivel_seguranca_p);
		/**
		 * @brief Método para acessar o atributo nivel_seguranca
		 * @return atributo nivel_seguranca
		*/
	   	int getNivel_seguranca();
	   	/**
		 * @brief Método para acessar a funcao
		 * @return atributo funcao
		*/
	   	string getFuncao();
	   	/**
		 * @brief Sobrecarga do operador de inserção (<<)
		 * @param[o] variável para a extração dos dados
		 * @param[t] variável tratador da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		friend std::ostream& operator<<(std::ostream &o, Tratador const t);
		/**
		 * @brief Sobrecarga do operador de extração (>>)
		 * @param[i] variável para a extração dos dados
		 * @param[t] variável tratador da qual os dados serão inseridos
		 * @return valores do cin(i)
		*/
		friend std::istream& operator>>(std::istream &i, Tratador &t);
		/**
		 * @brief Sobrecarga do operador de inserção stream (<<)
		 * @param[o] variável para a inserção dos dados em stream
		 * @param[t] variável tratador da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		friend std::ofstream& operator<<(std::ofstream &o, Tratador const t);
};

#endif