/**
 * @file  Funcionario.h
 * @brief Arquivo com as implementações das classes Funcionario, Veterinario e Tratador
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#ifndef FUNCIONARIO_H /*Verifica se a variável FUNCIONARIO_H não foi definida*/
#define FUNCIONARIO_H /*Define a variável FUNCIONARIO_H*/
#include <cstdlib>
#include <string> /*Inclui o arquivo string*/
#include <iostream> /*Inclui a biblioteca padrão do C++*/
#include <ostream> /*Inclui a biblioteca ostream*/
#include <fstream> /*Inclui a biblioteca fstream*/

using namespace std; /*Usa o espaço de nomes padrão*/

class Funcionario
{
	protected:
		int id;
		string nome;
		string funcao;
		string CPF;
		int idade;
	    string tipo_sanguineo;
		char fator_RH;
		string especialidade;
	public:
		Funcionario(); /*Construtor padrão*/
		Funcionario(string funcao_p); /*Construtor parametrizado simplista*/
		Funcionario(int id_p, string nome_p, string funcao_p, string CPF_p, int idade_p, string tipo_sanguineo_p, char fator_RH_p, string especialidade_p); /*Construtor parametrizado completo*/
		~Funcionario();	/*Destrutor da classe*/
		/**
		 * @brief Método para alterar o atributo id
		 * @return 
		*/
		void setId(int id_p);
		/**
		 * @brief Método para alterar o atributo nome
		 * @return 
		*/
		void setNome(string nome_p);
		/**
		 * @brief Método para alterar o atributo CPF
		 * @return 
		*/
		void setCPF(string CPF_p);
		/**
		 * @brief Método para alterar o atributo idade
		 * @return 
		*/
		void setIdade(int idade_p);
		/**
		 * @brief Método para alterar o atributo tipo_sanguineo
		 * @return 
		*/
		void setTipo_sanguineo(string tipo_sanguineo_p);
		/**
		 * @brief Método para alterar o atributo fator_RH
		 * @return 
		*/
		void setFator_RH(char fator_RH_p);
		/**
		 * @brief Método para alterar o atributo especialidade
		 * @return 
		*/
		void setEspecialidade(string especialidade_p);
		/**
		 * @brief Método para acessar o atributo id
		 * @return atributo id
		*/
		int getId();
		/**
		 * @brief Método para acessar o atributo nome
		 * @return atributo nome
		*/
		string getNome();
		/**
		 * @brief Método para acessar o atributo função
		 * @return atributo função
		*/
		virtual string getFuncao() = 0;
		/**
		 * @brief Método para acessar o atributo CPF
		 * @return atributo CPF
		*/
		string getCPF();
		/**
		 * @brief Método para acessar o atributo idade
		 * @return atributo idade
		*/
		int getIdade();
		/**
		 * @brief Método para acessar o atributo tipo_sanguineo
		 * @return atributo tipo_sanguineo
		*/
		string getTipo_sanguineo();
		/**
		 * @brief Método para acessar o atributo fator_RH
		 * @return atributo fator_RH
		*/
		char getFator_RH();
		/**
		 * @brief Método para acessar o atributo especialidade
		 * @return atributo especialidade
		*/
		string getEspecialidade();

};

#endif


