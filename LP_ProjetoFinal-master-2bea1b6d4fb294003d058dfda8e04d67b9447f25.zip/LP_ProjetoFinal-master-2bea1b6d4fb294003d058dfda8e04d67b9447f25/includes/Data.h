/**
 * @file  crud.cpp
 * @brief Descrição do arquivo
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com
 *
*/

#ifndef DATA_H
#define DATA_H

using namespace std;

//Classe Data, seus atributos e métodos
class Data
{
      private:
            int dia;
            int mes;
            int ano;
      public:
      
            Data();
            Data(int d, int m, int a);
            ~Data();
            void setData(int d, int m, int a);
            Data getData();
            int getDia();
            int getMes();
            int getAno();
            void setDia(int d);
            void setMes(int m);
            void setAno(int a);
            Data operator-(Data &p);
            friend std::ostream& operator<<(std::ostream &o, Data const d);
            friend bool operator==(Data const d1, Data const d2);

};

#endif
