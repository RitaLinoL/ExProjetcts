/**
 * @file  Reptil.h
 * @brief Arquivo com as implementações das classes de Reptil, Reptil Nativo e Reptil Exótico
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#include "Animal.h" /*Inclui o arquivo Animal.h*/

using namespace std; /*Usa o espaço de nomes padrao*/

#ifndef REPTIL_H /*Verifica se a variável REPTIL_H não foi definida*/
#define REPTIL_H /*Define a variável REPTIL_H*/

class Reptil : public Animal{
	protected:
		bool venenoso;
		string tipo_veneno;
	public:
		Reptil(); /*Construtor padrao da classe*/
		Reptil(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, bool venenoso_p, string tipo_veneno_p); /*Construtor parametrizado da classe*/
		~Reptil(); /*Destrutor da classe*/
		/**
		 * @brief Método para alterar o atributo venenoso
		 * @return
		*/
		void setVenenoso(bool venenoso_p);
		/**
		 * @brief Método para alterar o atributo tipo_veneno
		 * @return
		*/
		void setTipo_veneno(string tipo_veneno_p);
		/**
		 * @brief Método para acessar o atributo venenoso
		 * @return venenoso
		*/
		bool getVenenoso();
		/**
		 * @brief Método para acessar o atributo tipo_veneno
		 * @return tipo_veneno
		*/
		string getTipo_veneno();
		/**
		 * @brief Método para acessar o atributo classe
		 * @return classe
		*/
		string getClasse();
};
#endif


#ifndef REPTIL_EXOTICO_H /*verifica se a variável REPTIL_EXOTICO_H não foi definida*/
#define REPTIL_EXOTICO_H /*Define a variável REPTIL_EXOTICO_H*/

class ReptilExotico : public Reptil, AnimalExotico{
	public:
		ReptilExotico(); /*Construtor padrao da classe*/
		ReptilExotico(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, bool venenoso_p, string tipo_veneno_p, string aut_ibama_p, string pais_origem_p); /*Construtor parametrizado da classe*/
		~ReptilExotico(); /*Destrutor da classe*/
		/**
 		 * @brief Sobrecarga do operador de extraçao (>>)
 		 * @param[i] variável para a extraçao de dados
 		 * @param[a] variável animal para armazenar os dados
 		 * @return valores do cin(i)
		*/
		//friend istream& operator>>(istream &i, Animal &a);
		/**
		 * @brief Sobrecarga do operador de inserção (<<)
		 * @param[o] variável para a inserção dos dados
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ostream& operator<<(ostream &o, Animal const a);
		/**
		 * @brief Sobrecarga do operador de inserção em stream(<<)
		 * @param[o] variável para a inserção dos dados em stream
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ofstream& operator<<(ofstream &o, Animal const a);
};
#endif


#ifndef REPTIL_NATIVO_H /*Verifica se a variável REPTIL_NATIVO_H não foi definida*/
#define REPTIL_NATIVO_H /*Define a variável REPTIL_NATIVO_H*/

class ReptilNativo : public Reptil, AnimalNativo{	
	public:
		ReptilNativo(); /*Construtor padrao da classe*/
		ReptilNativo(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, bool venenoso_p, string tipo_veneno_p, string aut_ibama_p, string uf_origem_p, string autorizacao_p); /*Construtor parametrizado da classe*/
		~ReptilNativo(); /*Destrutor da classe*/
		/**
 		 * @brief Sobrecarga do operador de extraçao (>>)
 		 * @param[i] variável para a extraçao de dados
 		 * @param[a] variável animal para armazenar os dados
 		 * @return valores do cin(i)
		*/
		//friend istream& operator>>(istream &i, Animal &a);
		/**
		 * @brief Sobrecarga do operador de inserção (<<)
		 * @param[o] variável para a inserção dos dados
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ostream& operator<<(ostream &o, Animal const a);
		/**
		 * @brief Sobrecarga do operador de inserção em stream(<<)
		 * @param[o] variável para a inserção dos dados em stream
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ofstream& operator<<(ofstream &o, Animal const a);
};

#endif