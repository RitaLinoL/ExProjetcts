/**
 * @file  Anfibio.h
 * @brief Arquivo com as implementações das classes de Anfibio, Anfibio Exótico e Anfibio Nativo
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versão: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#include "Animal.h" /*Inclui o arquivo Animal.h*/
#include "Data.h" /*Inclui o arquivo Data.h*/

using namespace std; /*Usa o espaço de nomes padrão*/

#ifndef ANFIBIO_H /*Verifica se a variável ANFIBIO_H foi definida*/
#define ANFIBIO_H /*Define a variável ANFIBIO_H*/

class Anfibio : public Animal{
	protected:
		int total_mudas;
		Data ultima_muda;
	public:
		Anfibio(); /*Construtor padrão da classe*/
		Anfibio(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, int total_mudas_p, int dia_p, int mes_p, int ano_p); /*Construtor parametrizado da classe*/
		~Anfibio(); /*Destrutor da classe*/
		/**
		 * @brief Método para acessar o atributo classe
		 * @return classe
		*/
		string getClasse();
		/**
		 * @brief Método para alterar o atributo total_mudas
		 * @return 
		*/
		void setTotal_mudas(int total_mudas_p);
		/**
		 * @brief Método para alterar o atributo ultima_muda
		 * @return 
		*/
		void setUltima_muda(int dia_p, int mes_p, int ano_p);
		/**
		 * @brief Método para acessar o atributo total_mudas
		 * @return total_mudas
		*/ 
		int getTotal_mudas();
		/**
		 * @brief Método para acessar o atributo ultima_muda
		 * @return ultima_muda
		*/
		Data getUltima_muda();

};
#endif


#ifndef ANFIBIO_EXOTICO_H /*Verifica se a variável ANFIBIO_EXOTICO_H foi definida*/
#define ANFIBIO_EXOTICO_H /*Define a variável ANFIBIO_EXOTICO_H*/

class AnfibioExotico : public Anfibio, AnimalExotico{
	public:
		AnfibioExotico(); /*Construtor padrao da classe*/
		AnfibioExotico(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, int total_mudas_p, int dia_p, int mes_p, int ano_p, string aut_ibama_p, string pais_origem_p); /*Construtor parametrizado da classe*/
		~AnfibioExotico(); /*Destrutor da classe*/
		/**
 		 * @brief Sobrecarga do operador de extraçao (>>)
 		 * @param[i] variável para a extraçao de dados
 		 * @param[a] variável animal para armazenar os dados
 		 * @return valores do cin(i)
		*/
		//friend istream& operator>>(istream &i, Animal &a);
		/**
		 * @brief Sobrecarga do operador de inserção (<<)
		 * @param[o] variável para a inserção dos dados
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ostream& operator<<(ostream &o, Animal const a);
		/**
		 * @brief Sobrecarga do operador de inserção em stream(<<)
		 * @param[o] variável para a inserção dos dados em stream
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ofstream& operator<<(ofstream &o, Animal const a);

};
#endif


#ifndef ANFIBIO_NATIVO_H /*Verifica se a variável ANFIBIO_NATIVO_H foi definida*/
#define ANFIBIO_NATIVO_H /*Define a variável ANFIBIO_NATIVO_H*/

class AnfibioNativo : public Anfibio, AnimalNativo{
	public:
		AnfibioNativo(); /*Construtor padrao da classe*/
		AnfibioNativo(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p, int total_mudas_p, int dia_p, int mes_p, int ano_p, string aut_ibama_p, string uf_origem_p, string autorizacao_p); /*Construtor parametrizado da classe*/
		~AnfibioNativo(); /*Destrutor da classe*/
		/**
 		 * @brief Sobrecarga do operador de extraçao (>>)
 		 * @param[i] variável para a extraçao de dados
 		 * @param[a] variável animal para armazenar os dados
 		 * @return valores do cin(i)
		*/
		//friend istream& operator>>(istream &i, Animal &a);
		/**
		 * @brief Sobrecarga do operador de inserção (<<)
		 * @param[o] variável para a inserção dos dados
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ostream& operator<<(ostream &o, Animal const a);
		/**
		 * @brief Sobrecarga do operador de inserção em stream(<<)
		 * @param[o] variável para a inserção dos dados em stream
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		//friend ofstream& operator<<(ofstream &o, Animal const a);
};

#endif
