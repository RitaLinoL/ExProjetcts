/**
 * @file  Animal.h
 * @brief Arquivo com as implementações das classes de Animal, Animal Silvestre e Animal Exótico
 * @author $Autor: Rita de Cássia Lino Lopes, José Lúcio da Silva Júnior $
 * \version $Versao: 2.0 $
 * \date $Data: 2019/05/14 17:51:00 $
 * Contact: rita_lino@outlook.com, dragaolucio@gmail.com
 *
*/

#include <iostream> /*Inclui a biblioteca padrão do C++*/
#include <string> /*Inclui a biblioteca string*/
#include "Funcionario.h" /*Inclui o arquivo Funcionario.h*/
#include <fstream> /*Inclui a bilbioteca fstream*/

using namespace std; /*Uso do espaço de nomes padrão*/

#ifndef ANIMAL_H /*Verifica se a variavel ANIMAL_H nao foi definida*/
#define ANIMAL_H /*Define a variavel ANIMAL_H*/

class Animal{
	protected:
		int id;
		string classe;
		string nome;
		string nome_cientifico;
		char sexo;
		double tamanho;
		string dieta;
		int id_veterinario;
		int id_tratador;
		string nome_batismo;
	public:
		Animal(); /*Construtor padrao da classe*/
		Animal(int id_p, string classe_p, string nome_p, string nome_cientifico_p, char sexo_p, double tamanho_p, string dieta_p, int id_veterinario_p, int id_tratador_p, string nome_batismo_p);/*Construtor parametrizado da classe*/
		~Animal(); /*Destrutor da classe*/
		/**
		 * @brief Metodo para alterar o atributo id
		 * @return
		*/
		void setId(int id_p);
		/**
		 * @brief Metodo para alterar o atributo nome_cientifico
		 * @return
		*/
		void setNome_cientifico(string nome_cientifico_p);
		/**
		 * @brief Metodo para alterar o atributo sexo
		 * @return
		*/
		void setSexo(char sexo_p);
		/**
		 * @brief Metodo para alterar o atributo tamanho
		 * @return
		*/
		void setTamanho(double tamanho_p);
		/**
		 * @brief Metodo para alterar o atributo dieta
		 * @return
		*/
		void setDieta(string dieta_p);
		/**
		 * @brief Metodo para alterar o atributo nome
		 * @return
		*/
		void setNome(string nome_p);
		/**
		 * @brief Metodo para alterar o atributo id_veterinario
		 * @return
		*/
		void setId_veterinario(int id_veterinario_p);
		/**
		 * @brief Metodo para alterar o atributo id_tratador
		 * @return
		*/
		void setId_tratador(int id_tratador_p);
		/**
		 * @brief Metodo para alterar o atributo nome_batismo
		 * @return
		*/
		void setNome_batismo(string nome_batismo_p);
		/**
		 * @brief Metodo para acessar o atributo id
		 * @return id
		*/
		int getId();
		/**
		 * @brief Metodo para acessar o atributo classe
		 * @return classe
		*/
		string getClasse();
		/**
		 * @brief Metodo para alterar o atributo classe
		 * @return 
		*/
		void setClasse(string classe_p);
		/**
		 * @brief Metodo para acessar o atributo nome_cientifico
		 * @return nome_cientifico
		*/
		string getNome_cientifico();
		/**
		 * @brief Metodo para acessar o atributo nome
		 * @return nome
		*/
		string getNome();
		/**
		 * @brief Metodo para acessar o atributo sexo
		 * @return sexo
		*/
		char getSexo();
		/**
		 * @brief Metodo para acessar o atributo tamanho
		 * @return tamanho
		*/
		double getTamanho();
		/**
		 * @brief Metodo para acessar o atributo dieta
		 * @return dieta
		*/
		string getDieta();
		/**
		 * @brief Metodo para acessar o atributo id_veterinario
		 * @return id_veterinario
		*/		
		int getId_veterinario();
		/**
		 * @brief Metodo para acessar o atributo id_tratador
		 * @return id_tratador
		*/
		int getId_tratador();
		/**
		 * @brief Metodo para acessar o atributo nome_batismo
		 * @return nome_batismo
		*/
		string getNome_batismo();
		/**
 		 * @brief Sobrecarga do operador de extração (>>)
 		 * @param[i] variável para a extração de dados
 		 * @param[a] variável animal para armazenar os dados
 		 * @return valores do cin(i)
		*/
	

		friend istream& operator>>(istream &i, Animal &a);
		/**
		 * @brief Sobrecarga do operador de inserção (<<)
		 * @param[o] variável para a inserção dos dados
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		friend ostream& operator<<(ostream &o, Animal const a);
		/**
		 * @brief Sobrecarga do operador de inserção em stream(<<)
		 * @param[o] variável para a inserção dos dados em stream
		 * @param[a] variável animal da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		friend ofstream& operator<<(ofstream &o, Animal const a);
};

#endif


#ifndef ANIMAL_SILVESTRE_H /*Verifica se a variavel ANIMAL_SILVESTRE_H não foi definida*/
#define ANIMAL_SILVESTRE_H /*Define a variavel ANIMAL_SILVESTRE_H*/

class AnimalSilvestre{
	protected:
		string autorizacao_ibama;
		
	public:
		AnimalSilvestre(); /*Construtro padrão da classe*/
		AnimalSilvestre(string aut_ibama_p); /*Construtor parametrizado da classe*/
		~AnimalSilvestre(); /*Destrutor da classe*/
		/**
		 * @brief Metodo para alterar o atributo autorizacao_ibama
		 * @return 
		*/
		void setAutorizacao_ibama(string aut_ibama_p);
		/**
		 * @brief Metodo para acessar o atributo autorizacao_ibama
		 * @return autorizacao_ibama
		*/
		string getAutorizacao_ibama();
};

#endif


#ifndef ANIMAL_EXOTICO_H /*Verifica se a variavel ANIMAL_EXOTICO_H não foi definida*/
#define ANIMAL_EXOTICO_H /*Define a variavel ANIMAL_EXOTICO_H*/

class AnimalExotico : public AnimalSilvestre{
	protected:
		string pais_origem;
	public:
		AnimalExotico(); /*Construtor padrão da classe*/
		AnimalExotico(string aut_ibama_p, string pais_origem_p); /*Construtor parametrizado da classe*/
		~AnimalExotico(); /*Destrutor da classe*/
		/**
		 * @brief Metodo para alterar o atributo pais_origem
		 * @return 
		*/
		void setPais_origem(string pais_origem_p);
		/**
		 * @brief Metodo para acessar o atributo pais_origem
		 * @return pais_origem
		*/
		string getPais_origem();
};

#endif


#ifndef ANIMAL_NATIVO_H /*Verifica se a variavel ANIMAL_NATIVO_H nao foi definida*/
#define ANIMAL_NATIVO_H /*Define a variavel ANIMAL_NATIVO_H*/

class AnimalNativo : public AnimalSilvestre{
	protected:
		string uf_origem;
		string autorizacao;
	public:
		AnimalNativo(); /*Construtor padrao da classe*/
		AnimalNativo(string aut_ibama_p, string uf_origem_p, string autorizacao_p); /*Construtor parametrizado da classe*/
		~AnimalNativo(); /*Destrutor da classe*/
		/**
		 * @brief Metodo para alterar o atributo uf_origem
		 * @return 
		*/
		void setUF_origem(string uf_origem_p);
		/**
		 * @brief Metodo para alterar o atributo autorizacao
		 * @return 
		*/
		void setAutorizacao(string autorizacao_p);
		/**
		 * @brief Metodo para acessar o atributo uf_origem
		 * @return uf_origem
		*/
		string getUF_origem();
		/**
		 * @brief Metodo para acessar o atributo autorizacao
		 * @return autorizacao
		*/
		string getAutorizacao();
};

#endif

