
#ifndef VETERINARIO_H /*Verifica se a variável VETERINARIO_H não foi definida*/
#define VETERINARIO_H /*Define a variável VETERINARIO_H*/
using namespace std;

#include "Funcionario.h"
#include <cstdlib>
#include <string> /*Inclui o arquivo string*/
#include <iostream> /*Inclui a biblioteca padrão do C++*/
#include <istream> /*Inclui a biblioteca padrão do C++*/
#include <ostream> /*Inclui a biblioteca ostream*/
#include <fstream> /*Inclui a biblioteca fstream*/

class Veterinario : public Funcionario
{
	private:
		string CRMV;
	public:
		Veterinario(); /*Construtor padrão da classe*/
		Veterinario(int id_p, string nome_p, string funcao_p, string CPF_p, int idade_p, string tipo_sanguineo_p, char fator_RH_p, string especialidade_p, string CRMV_p); /*Construtor parametrizado da classe*/
		~Veterinario(); /*Destrutor da classe*/
		/**
		 * @brief Método para acessar o atributo funcao
		 * @return atributo funcao
		*/
		string getFuncao();
		/**
		 * @brief Método para alterar o atributo CRMV
		 * @return 
		*/
		void setCRMV(string CRMV_p);
		/**
		 * @brief Método para acessar o atributo CRMV
		 * @return atributo CRMV
		*/
		string getCRMV();
		/**
		 * @brief Sobrecarga do operador de inserção (<<)
		 * @param[o] variável para a inserção dos dados
		 * @param[v] variável veterinario da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		friend std::ostream& operator<<(std::ostream &o, Veterinario const v);
		/**
		 * @brief Sobrecarga do operador de extração (>>)
		 * @param[i] variável para a extração dos dados
		 * @param[v] variável veterinario da qual os dados serão inseridos
		 * @return valores do cin(i)
		*/
		friend std::istream& operator>>(std::istream &i, Veterinario &v);
		/**
		 * @brief Sobrecarga do operador de inserção em stream (<<)
		 * @param[o] variável para a inserção dos dados em stream
		 * @param[v] variável veterinario da qual os dados serão inseridos
		 * @return valores do cout(o)
		*/
		friend std::ofstream& operator<<(std::ofstream &o, Veterinario const v);

};

#endif