 /*TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#config-web-app */
 // Configurações da aplicação web
 var firebaseConfig = {
     apiKey: "AIzaSyAtugnquMPm1CYZwALrkoNCvIP1mskEvkM",
     authDomain: "avaliaulaweb.firebaseapp.com",
     databaseURL: "https://avaliaulaweb.firebaseio.com",
     projectId: "avaliaulaweb",
     storageBucket: "avaliaulaweb.appspot.com",
     messagingSenderId: "182981949533",
     appId: "1:182981949533:web:f3f0a543f433cb9a"
 };

 // Initialize Firebase
 firebase.initializeApp(firebaseConfig);

 //Funções de leitura
 function carregar_avaliacao(doc, id_tabela, aluno, RFID) {

     tabela_avaliacao = doc.getElementById(id_tabela);
     corpo = doc.createElement("tbody");




     var avaliacoes = firebase.database().ref('turmai').child("avaliacao");


     // Loop through users in order with the forEach() method. The callback
     // provided to forEach() will be called synchronously with a DataSnapshot
     // for each child:
     var query = firebase.database().ref('turmai').child("avaliacao");
     query.once("value").then(function(snapshot) {
             snapshot.forEach(function(childSnapshot) {
                 // key will be "ada" the first time and "alan" the second time
                 var data = childSnapshot.key;
                 var tema = childSnapshot.child("tema").val();
                 var respondida = childSnapshot.child("resposta").child("topicoi").hasChild("-3");

                 console.log(respondida);


                 tr_table = doc.createElement("tr");

                 td_tema = doc.createElement("td");
                 td_tema.id = "tema_" + data;
                 td_data = doc.createElement("td");
                 td_data.id = "data_" + data;
                 td_tema.class = "tm-product-name";
                 td_icons = doc.createElement("td");
                 td_icons.id = "icons_" + data;

                 td_icons.innerHTML = "<a href='#' class='tm-product-delete-link'>    <i class='fas fa-chart-area  tm-product-delete-icon'></i> </a>";
                 if (!respondida && aluno) {
                  td_icons.innerHTML = td_icons.innerHTML + "<a href='avaliacao_aluno.html?data=" + data + "&RFID='"+RFID+" class='tm-product-delete-link'> <i class='far fa-arrow-alt-circle-right  tm-product-delete-icon'></i> </a>";
                 }else if(!aluno){
                    td_icons.innerHTML = td_icons.innerHTML + "<a href='' class='tm-product-delete-link'> <i class='far fa-arrow-alt-circle-right  tm-product-delete-icon'></i> </a>";
                 }
                 
                 td_data.innerHTML = data;
                 td_tema.innerHTML = tema;

                 tr_table.appendChild(td_tema);
                 tr_table.appendChild(td_data);
                 tr_table.appendChild(td_icons);

                 corpo.appendChild(tr_table);



             });
         });

     tabela_avaliacao.appendChild(corpo);
 }

 function carregar_descricao_avaliacao(doc, data) {
    var query = firebase.database().ref('turmai').child("avaliacao").child(data).child("pergunta");
    query.once("value").then(function(snapshot) {
            snapshot.forEach(function(childSnapshot) {
                // key will be "ada" the first time and "alan" the second time
                var topico = childSnapshot.key;
                var descricao = childSnapshot.val();
                doc.getElementById(topico+"_descricao").innerHTML = descricao;
            });
        });
}





 //Funções de adição
 function addAvaliacao(doc) {
     tema = doc.getElementById("tema").value;
     data = doc.getElementById("data").value;
     topicoi = doc.getElementById("topicoi").value;
     topicoii = doc.getElementById("topicoii").value;
     topicoiii = doc.getElementById("topicoiii").value;
     topicoiv = doc.getElementById("topicoiv").value;
     topicov = doc.getElementById("topicov").value;

     novaAvaliacao = {
         "data": data,
         "tema": tema,
         "pergunta": {
             "topicoi": topicoi,
             "topicoii": topicoii,
             "topicoiii": topicoiii,
             "topicoiv": topicoiv,
             "topicov": topicov
         },
         "resposta": {
             "topicoi": {
                 "-3": "-1"
             },
             "topicoii": {
                 "-3": "-1"
             },
             "topicoiii": {
                 "-3": "-1"
             },
             "topicoiv": {
                 "-3": "-1"
             },
             "topicov": {
                 "-3": "-1"
             }
         }
     };

     firebase.database().ref("turmai").child('/avaliacao/' + data + '/').set(novaAvaliacao);

 }


 function addResposta(doc, RFID, data){
  RFID = RFID.replace(/[%20]/gi,' ');//tirar o espaço
  

  topicoi = doc.getElementById("topicoi").value;
  topicoii = doc.getElementById("topicoii").value;
  topicoiii = doc.getElementById("topicoiii").value;
  topicoiv = doc.getElementById("topicoiv").value;
  topicov = doc.getElementById("topicov").value;


  firebase.database().ref("turmai").child('/avaliacao/' + data + '/resposta/topicoi/'+RFID).set(topicoi);
  firebase.database().ref("turmai").child('/avaliacao/' + data + '/resposta/topicoii/'+RFID).set(topicoii);
  firebase.database().ref("turmai").child('/avaliacao/' + data + '/resposta/topicoiii/'+RFID).set(topicoiii);
  firebase.database().ref("turmai").child('/avaliacao/' + data + '/resposta/topicoiv/'+RFID).set(topicoiv);
  firebase.database().ref("turmai").child('/avaliacao/' + data + '/resposta/topicov/'+RFID).set(topicov);


  var query = firebase.database().ref('turmai').child("avaliacao").child(data).child("resposta");
     query.once("value").then(function(snapshot) {
             snapshot.forEach(function(childSnapshot) {
                 // key will be "ada" the first time and "alan" the second time
                 var topico = childSnapshot.key;
                 console.log(topico);  
                 var filhoNulo= childSnapshot.hasChild("-3"); 
                 console.log(filhoNulo);
                 if (filhoNulo) {
                    firebase.database().ref("turmai").child('/avaliacao/' + data + '/resposta/'+topico+'/-3/').remove();
                 }

             });
         });

 }




 //Funções de exclusão


 //Funções de atualização




 //Função auxiliar
 // função pra ler url em busca de variável
 function encontrar_var(parameter) {
     var loc = location.search.substring(1, location.search.length);
     var param_value = false;
     var params = loc.split("&");
     for (i = 0; i < params.length; i++) {
         param_name = params[i].substring(0, params[i].indexOf('='));
         if (param_name == parameter) {
             param_value = params[i].substring(params[i].indexOf('=') + 1)
         }
     }
     if (param_value) {
        console.log(param_value);
        return param_value;
     } else {}
 }


 function media(soma,quant){
    
    
    console.log(media);
    console.log(typeof(media));
    return media;
 }

 function calcular_media(topico, data){
    var soma =0.0;
    var quant =0.0;
    var media = 0.0;
   
    let x = firebase.database().ref('turmai').child("avaliacao").child(data).child("resposta").child(topico).once("value").then(function(snapshot) {
           return snapshot;
    });


    x.then(
        function( snapshot ){
            snapshot.forEach(function(childSnapshot) {
                // key will be "ada" the first time and "alan" the second time
                valor = parseFloat(childSnapshot.val());
                soma += valor;
                quant++;
            });
        
            media = soma/quant;
            
            return media;
        }, 
        function(){
            media =0;
            return media;
        }
    ); 

 }

 




 /* Definindo a referência com a qual trabalharemos: "text"
 var textRef = firebase.database().ref('turmai').child("avaliacao").child("2019-06-14").child("data");


 // "Escutando" toda e qualquer alteração da chave "text"
 textRef.on('value', function(snapshot) {
     // Escrevendo o que foi recebido em tempo real no nosso campo de texto
     document.getElementById('bigText').value = snapshot.val();
 });

 // Também criando uma função para que o que digitarmos seja enviado ao Firebase
 function writeText(text) {
     var content = {};
     content['/bigText/'] = text;
     return firebase.database().ref().update(content);
 }*/