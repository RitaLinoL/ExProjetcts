import time
import Adafruit_ADS1x15
import thingspeak
from gpiozero import LED
adc = Adafruit_ADS1x15.ADS1115()
led = LED(21)
GAIN = 1
cont = 0
consumoM = 0.0
cont2 = 0
consumoH = 0.0
print('| {0:>6} | {1:>6} |'.format(*range(2)))
print('-' * 37)
#time.sleep(15)
while True:
    values = [0]*2
    for i in range(2):
        values[i] = adc.read_adc(i, gain=GAIN, data_rate=860)

    print('| {0:>6} | {1:>6.3f} |'.format(values[0],(values[1]*(4.096/32767))))
    led.on()
    
    if values[0] < 16000:
        cont +=1
    if cont == 4:
        cont = 0
        cont2 += 1
        #Consumo em Kw/min
        consumoM +=  (12.0*(1.0/60.0))/1000.0
    #if cont2 == 60:
     #   consumoH += consumoM
      #  consumoM = 0
    print('| Kw/min={0:>0.6f}Kw | Kw/h={1:>0.6f}Kw |'.format(consumoM, consumoH)) 
    #ch = thingspeak.Channel(id=727458, write_Key='INFV98AHFHZFX6SQ')
    #print(ch.get({'results':5})
    #var = {'field1':consumoM}
    #ch.update({'field5':consumoM})
    time.sleep(0.005)
    led.off()
