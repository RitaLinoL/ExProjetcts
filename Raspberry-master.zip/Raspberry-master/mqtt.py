import paho.mqtt.client as mqtt
from struct import pack
from random import randint
from time import sleep

AREA_ID = 10
SENSOR_ID = 500
SENSOR_ID20 = 200

tt = "area/%d/sensor/%s/temperatura" % (AREA_ID,SENSOR_ID)
uu = "area/%d/sensor/%s/umidade" % (AREA_ID,SENSOR_ID)
tt20 = "area/%d/sensor/%s/temperatura" % (AREA_ID,SENSOR_ID20)

client = mqtt.Client(client_id = 'NODE:%d-%d' % (AREA_ID,SENSOR_ID), protocol = mqtt.MQTTv31)
client2 = mqtt.Client(client_id = 'NODE:%d-%d' % (AREA_ID,SENSOR_ID20), protocol = mqtt.MQTTv31)

client.connect("iot.eclipse.org", 1883)
client2.connect("iot.eclipse.org", 1883)
while True:
    t = randint(0,50)
    payload = pack(">H",t)
    client.publish(tt,payload,qos=0)
    print tt + "/" + str(t)
    client2.publish(tt20,payload,qos=0)
    print tt20 + "/" + str(t+5)
    u = randint(0,100)
    payload = pack(">H",u)
    client.publish(uu,payload,qos=0)
    print uu + "/" + str(u)
    sleep(5)
