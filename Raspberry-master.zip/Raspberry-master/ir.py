import RPi.GPIO as GPIO


PIN = 24

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(PIN, GPIO.IN)
GPIO.setup(PIN, GPIO.OUT)

if GPIO.input(PIN) == 0:
         GPIO.output(PIN, GPIO.HIGH)
     else:
              GPIO.output(PIN, GPIO.LOW)
