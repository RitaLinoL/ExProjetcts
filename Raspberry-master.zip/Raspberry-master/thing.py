import thingspeak
import time
ch = thingspeak.Channel(id=727458,write_key='INFV98AHFHZFX6SQ')
print(ch.get({'results':2}))

ch.update({'fild1':10})
time.sleep(15)
#ch.update({'fild2':20})
#time.sleep(15)
ch.update({'filde1':30})
time.sleep(15)
#ch.update({'filde2':40})

