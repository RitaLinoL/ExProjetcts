#exemplo traduzido do site https://learn.adafruit.com/raspberry-pi-analog-to-digital-converters/ads1015-slash-ads1115

import time

# Import the ADS1x15 module.
import Adafruit_ADS1x15


# Escolha um ganho de 1 para ler valores de 0 a 4.09V.
# Ou escolha ganhos diferentes dependendo das voltagens lidas:
#  - 2/3 = +/-6.144V
#  -   1 = +/-4.096V
#  -   2 = +/-2.048V
#  -   4 = +/-1.024V
#  -   8 = +/-0.512V
#  -  16 = +/-0.256V
#GAIN = 16

#exemplo traduzido do site https://learn.adafruit.com/raspberry-pi-analog-to-digital-converters/ads1015-slash-ads1115


# Cria uma instancia do ads 1115.
adc = Adafruit_ADS1x15.ADS1115()

# e possivel mudar o endereco I2C do chip, caso necessario. O default eh (0x48)
#adc = Adafruit_ADS1x15.ADS1015(address=0x49, bus=1)

# Escolha um ganho de 1 para ler valores de 0 a 4.09V.
# Ou escolha ganhos diferentes dependendo das voltagens lidas:
#  - 2/3 = +/-6.144V
#  -   1 = +/-4.096V
#  -   2 = +/-2.048V
#  -   4 = +/-1.024V
#  -   8 = +/-0.512V
#  -  16 = +/-0.256V
GAIN = 1


print('Reading ADS1x15 values, press Ctrl-C to quit...')

# Imprimir os canais em colunas
print('| {0:>6} | {1:>6} | {2:>6} | {3:>6} |'.format(*range(4)))
print('-' * 37)
# Main loop.
while True:
        # Le todos os canais em uma lista
    values = [0]*4
    for i in range(4):
                            # Le os valores usando o ganho escolhido
        values[i] = adc.read_adc(i, gain=GAIN)
                                            # tambem e possivel usar o parametro data_rate, para mudar a taxa de
                                                    # amostragem. Cada chip tem valores diferentes para taxas de amostragem
                                                            # e preciso chegar o datasheet para verificar quais valores sao aceitos
                                                                    # values[i] = adc.read_adc(i, gain=GAIN, data_rate=128)
                                                                            # Os valores serao de 12 ou 16 bits dependendo do chip
                                                                                    # ADC (ADS1015 = 12-bit, ADS1115 = 16-bit).
                                                                                        # Imprime os valores na tabela.
    print('| {0:>6} | {1:>6} | {2:>6} | {3:>6} |'.format(*values))
                                                                                                # Espera 0.5 segundos.
    
    time.sleep(0.0000001)

