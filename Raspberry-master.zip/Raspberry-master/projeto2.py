import Adafruit_DHT
import Adafruit_ADS1x15
import thingspeak
import time
import ifaddr
from gpiozero import LED

sensor = Adafruit_DHT.DHT11
adc = Adafruit_ADS1x15.ADS1115()
led = LED(21)
pin = 22
GAIN = 2/3

cont = 0
cont2 = 0
soma = 0.0

som =0.0
consumo = 0.0
consumoAr = 0.0
consumoTo = 0.0
atividade = 0.0

#ruido calculado por minuto
ruido = 0.0
ip_wlan0=""

print('                          | {0:>6} | {1:>6} |'.format(*range(2)))
print('-' * 37)

humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)
#time.sleep(15)
while True:
   
    #Find IP
    adapters = ifaddr.get_adapters() 
    for adapter in adapters:
        for ip in adapter.ips: 
            if adapter.nice_name == "wlan0":
                ip_wlan0 = ''+ip.ip
                break

    try:
        values = [0]*4
        for i in range(4):
            values[i] = adc.read_adc(i, gain=GAIN, data_rate=860)

        if temperature <= 25:
            consumoAr += ((2318.0*(1.0/60.0))/1000.0)

        if values[0] < 15000:
            consumo += ((24.0*32.0*(1.0/60.0))/1000.0)/4
            atividade = 1
        else:
            atividade = 0
        consumoTo = consumo+consumoAr
        
        som = (values[1] * (4.096/32767))

        if cont < 4:
            soma += som
            cont+=1
            ruido = 0
        else:
            ruido = soma/4
            soma = 0
            cont = 0 


        #if humidity is not None and temperature is not None: 
        print('| Temp={0:0.1f}*C | Humidity={1:0.1f}% | Luz={2:>6} |  Som={3:>6.3f} | Consumo={4:>0.3}Kw |'.format(temperature, humidity, values[0], som ,consumoTo))
        
        # Channel (num. do canal, '<token de escrita>')
        ch = thingspeak.Channel(id=727458, write_key ='INFV98AHFHZFX6SQ')
        print(ch.get({'results':2}))
        values[1] = (values[1]*(4.096/32767))
        var = {'field1':temperature, 'field2':humidity, 'field3':values[0], 'field4':som, 'field5':consumoTo, 'field6': atividade, 'field7':ruido, 'field8':ip_wlan0}
        ch.update(var)
        led.on()
        time.sleep(15)
        led.off()
    except IOError:
        print("Sem internet!!!")
        time.sleep(15)
                                                                                                                               
                                                                                                                                       
                                                                                      

