from gpiozero import LED
from time import sleep

led = LED(17)
led2 = LED(18)
led3 = LED(16)

while True:
	led.on()
        led3.on()
        led2.on()
        sleep(1)
        led.off()
        sleep(1)
        led2.off()
        sleep(1)
        led3.off()
        sleep(1)
