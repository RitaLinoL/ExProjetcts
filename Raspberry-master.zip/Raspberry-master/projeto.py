import Adafruit_DHT
import Adafruit_ADS1x15
import thingspeak
import time 

from gpiozero import LED

sensor = Adafruit_DHT.DHT11
adc = Adafruit_ADS1x15.ADS1115()
led = LED(21)
pin = 22 
GAIN = 2/3

print('                          | {0:>6} | {1:>6} |'.format(*range(2)))
print('-' * 37)

humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)
    
while True: 
    values = [0]*4
    for i in range(4):
        values[i] = adc.read_adc(i, gain=GAIN, data_rate=860)
    
    
    
    #if humidity is not None and temperature is not None: 
    #print('| Temp={0:0.1f}*C | Humidity={1:0.1f}% | Luz={2:>6} |  Som={3:>6.3f} |'.format(temperature, humidity, values[0], (values[1]*(4.096/32767))))
    #time.sleep(0.00005)

    # Channel (num. do canal, '<token de escrita>')
    ch = thingspeak.Channel(id=744416, write_key ='LFENYH4Q7JN682QJ')
    print(ch.get({'results':2}))
    # update({'campo' : valor})
    var = {'field1':temperature, 'field2':humidity, 'field3':values[0], 'field4': (values[1]*(4.096/32767))}
    ch.update(var)
    led.on()
    time.sleep(15)
    led.off()
    
