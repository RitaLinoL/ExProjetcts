#include <stdio.h>
void func()
{

}


void main(){
  
}