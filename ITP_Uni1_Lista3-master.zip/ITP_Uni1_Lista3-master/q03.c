#include <stdio.h>
#include <time.h>
#include <stdlib.h>


int func( int min, int max)
{
    int num;
    srand( (unsigned)time(NULL) );
    num = min + (rand() % max);
    return num;
}

