#include <stdio.h>

//q02
int arredondar(float val)
{
    int num;
    float resto;
    num =(int)val;
    resto =(float)val - num;

    if(resto>=0.5){
        num += 1;
    }
    return num;
}

//a
int arredonda10(int val)
{
    int num= 0;
    float resto;
    resto = val % 10;
    if(resto >=5){
        num = val + (10-resto);
    }else{
        num = val - resto;
    }

    return num;
}


//b(
void main(){
    printf("%i\n", arredondar(0.7));
    printf("%i\n", arredondar(0.4));
    printf("%i\n", arredondar(15.5));
    printf("%i\n", arredondar(16.8));

    printf("%i\n", arredonda10(15));
    printf("%i\n", arredonda10(21));
    printf("%i\n", arredonda10(25));
    printf("%i\n", arredonda10(31));
}