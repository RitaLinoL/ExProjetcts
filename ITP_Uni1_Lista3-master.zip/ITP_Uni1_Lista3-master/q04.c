#include <stdio.h>
#include <stdlib.h>

//a
int func( int n1, int n2)
{
    if((n1%n2 == 0 ) || (n2%n1 == 0)){
        return 1;
    }else{
        return 0;
    }
    
}

//b
void main()
{   
    for(int i = 0; i<10; i++)
    {
        printf("%d \n", func(rand(),rand()));
    }
   
}