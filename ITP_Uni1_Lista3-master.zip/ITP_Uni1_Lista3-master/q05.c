#include <stdio.h>
void func( int l, char fill)
{

    for(int i =0; i<l; i++){
        for(int j =0; j<l; j++){


        }
        printf("\n");
    }
}


void main(){
    printf("%d\n", func(1));
}