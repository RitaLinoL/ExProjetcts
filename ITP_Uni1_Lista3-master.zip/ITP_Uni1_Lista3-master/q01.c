#include <stdio.h>
int func( int i )
{
    printf ("Valor de I %d ", i);
    return i + 20;
}
void main(){
    printf("%d\n", func(1));
}