#include <stdio.h>
int primo(int n)
{
    int d=0;
    for(int i = 2; i<n ; i++){
        if(n%i ==0){
          d++;  
        }
    }
    
    if(!(d)){
        return 1;
    }else{
        return 0;
    }
}

int perfeito(int n)
{
    int soma = 0;
    for(int i = 1; i<n ; i++){
        if(n%i == 0){
          soma += i; 
        }
    }
    if(soma == n){
        return 1;
    }else{
        return 0;
    }
}


void main(){

    for(int i =3; i<1000000; i++){
        if((primo(i)) && (perfeito(i))){
            printf("%d \n", i);
        }
        
    }
  
}