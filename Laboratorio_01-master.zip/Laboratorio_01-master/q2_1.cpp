#include <iostream>
#include <cstdlib>
#include <cmath>

using namespace std;
# define PI           3.14159265358979323846  /* pi */

//Função para cálculo de denominadores que usam o fatorial
int fatorial(int x){
    if(x == 1)
        return 1;
    return x * fatorial(x-1);
}

//Função para cálculo aproximado do seno utilizando a série de Taylor
float seno(float x){
    float sen = 0;
    sen = x - ((pow(x,3))/fatorial(3)) + ((pow(x,5)) / fatorial(5));
    return sen;
}

//Função para cálculo aproximado do cosseno utilizando a série de Taylor
float cosseno(float x){
    float cos = 0;
    cos = 1 - ((pow(x,2))/fatorial(2)) + ((pow(x,4)) / fatorial(4));
    return cos;
}


int main(int argc, char const *argv[])
{
    cout << "Qual o valor do angulo (radianos)?"<< endl;
    float x = 0;
    cin >> x;//Entrada do ângulo a ser calculado.    


    //Transformando de rad para graus para usar nas funções da biblioteca cmath
    float x_graus = 180 * x / PI;
    cout << x<<endl;
    cout << x_graus<<endl;


    cout << seno(x)<<endl;
    cout << sin(x_graus)<<endl;

    cout << cosseno(x)<<endl;
    cout << cos(x_graus)<<endl;

    return 0;
}