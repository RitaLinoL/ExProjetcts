#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


typedef struct matriz{
    int mat [50][50];
    int l,c;
}Matriz;

int mat_mult(int m1l, int m1c,int m2l, int m2c, float m1[m1l][m1c], float m2[m1l][m1c]
float m_ret[m1l][m2c], int *m_retc, int *m_retl){

}

void main(){
    int n,m;
    scanf("%i",&n);
    scanf("%i",&m);

    int mat[n][m];
     int mat2[n][m];

    for(int i =0; i<n;i++){
        for(int j = 0; j<m;j++){
            mat[i][j] = rand() %100;
            mat2[i][j] = rand() %100;
        }
    }

   

}