#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


typedef struct matriz{
    int mat [50][50];
    int l,c;
}Matriz;

void funcao_matsum(int l, int c, int mat[l][c], int mat2[l][c], Matriz *matsum){
    (*matsum).l = l;
    (*matsum).c = c;
    for(int i =0; i<l;i++){
        for(int j = 0; j<c;j++){
            (*matsum).mat[i][j] = mat[i][j] + mat2[i][j];
        }
    }
}

void funcao_matsub(int l, int c, int mat[l][c], int mat2[l][c], Matriz *matsub){
    (*matsub).l = l;
    (*matsub).c = c;
    for(int i =0; i<l;i++){
        for(int j = 0; j<c;j++){
            (*matsub).mat[i][j] = mat[i][j] - mat2[i][j];
        }
    }
}

void main(){
    int n,m;
    scanf("%i",&n);
    scanf("%i",&m);

    int mat[n][m];
     int mat2[n][m];

    for(int i =0; i<n;i++){
        for(int j = 0; j<m;j++){
            mat[i][j] = rand() %100;
            mat2[i][j] = rand() %100;
        }
    }

    Matriz matriz_sum;
   funcao_matsum(n,m, mat, mat2, &matriz_sum);
    for(int i =0; i<(matriz_sum.l);i++){
        for(int j = 0; j<(matriz_sum.c);j++){
           printf("%i \n", matriz_sum.mat[i][j]);
        }
    }


    Matriz matriz_sub;
   funcao_matsub(n,m, mat, mat2, &matriz_sub);
    for(int i =0; i<(matriz_sub.l);i++){
        for(int j = 0; j<(matriz_sub.c);j++){
           printf("%i \n", matriz_sub.mat[i][j]);
        }
    }
   

}