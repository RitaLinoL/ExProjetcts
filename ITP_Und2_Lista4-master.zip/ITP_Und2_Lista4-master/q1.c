#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>




void main(){
    int n,m;
    scanf("%i",&n);
    scanf("%i",&m);

    int mat[n][m];

    for(int i =0; i<n;i++){
        for(int j = 0; j<m;j++){
            mat[i][j] = rand() %100;
        }
    }
     
   int mat2[n][m];
     for(int i =0; i<n;i++){
        for(int j = 0; j<m;j++){
        }
    }

    int matsum[n][m];
    for(int i =0; i<n;i++){
        for(int j = 0; j<m;j++){
            matsum[i][j] = mat[i][j] + mat2[i][j];
        }
    }
    for(int i =0; i<n;i++){
        for(int j = 0; j<m;j++){
           printf("%i \n", matsum[i][j]);
        }
    }

    int matsub[n][m];
    for(int i =0; i<n;i++){
        for(int j = 0; j<m;j++){
            matsub[i][j] = mat[i][j] - mat2[i][j];
        }
    }
    for(int i =0; i<n;i++){
        for(int j = 0; j<m;j++){
           printf("%i \n", matsub[i][j]);
        }
    }
   

}